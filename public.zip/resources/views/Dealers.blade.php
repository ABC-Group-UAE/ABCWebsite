@extends('Layout.layout')

@section('content')

<div class="modal-wrapper">
    <div class="form-wrapper w-clearfix"><a href="index.html" class="close">X </a>
      <h2 class="heading-4 headinginnerpages">Have a chat with us</h2>
      <div class="w-form">
        <form id="email-form-4" name="email-form-4" data-name="Email Form 4"><input type="text" class="w-input" autofocus="true" maxlength="256" name="name" data-name="Name" placeholder="Enter Your name" id="name"><input type="email" class="w-input" autofocus="true" maxlength="256" name="email" data-name="Email" placeholder="Enter your mail id" id="email" required=""><input type="tel" class="w-input" autofocus="true" maxlength="256" name="PhNo" data-name="Ph No" placeholder="Enter Your mobile number" id="PhNo" required=""><input type="text" class="w-input" autofocus="true" maxlength="256" name="TypeofEnquiry" data-name="Typeof Enquiry" placeholder="Enter type of enquiry here" id="TypeofEnquiry" required=""><textarea data-name="Message" maxlength="5000" id="message" name="message" placeholder="type any message here" autofocus="true" class="textarea w-input"></textarea><input type="submit" value="Submit" data-wait="Please wait..." class="btnclass borderclass w-button"></form>
        <div class="w-form-done">
          <div>Thank you! Your submission has been received!</div>
        </div>
        <div class="w-form-fail">
          <div>Oops! Something went wrong while submitting the form.</div>
        </div>
      </div>
    </div>
  </div>

  <div class="dealers-image-section"></div>
  <div class="all-page-red-section w-clearfix">
    <div class="redsectioncontentdiv">
      <p class="paragraph-4">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat. Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc ut sem vitae risus tristique posuere.</p>
      <a href="#" class="know-more-link-block combotypocolour w-inline-block">
        <div class="buttonclass-knowmore combotypographycolor">
          <h3 class="know-more-heading">Know More</h3>
        </div>
      </a>
    </div>
  </div>
  <div id="dealer-div" class="herosection">
    <div class="main-section-container w-container">
      <h1 class="headinginnerpages">Our Trade Partners</h1>
      <div class="w-layout-grid dealers-list">
        <div>
          <div>
            <h3 class="dealer-heading">Heading</h3>
          </div>
          <div class="reddividerdiv"></div>
          <div class="category-image-div"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/FweAiP_1.svg" width="27" height="37" alt=""><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/9NaSBr_1.svg" width="27" height="37" alt=""><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Asset-2-1.svg" width="27" height="37" alt=""><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Asset-1-1.svg" width="27" height="37" alt=""></div>
          <div>
            <div class="text-block-19">This is some text inside of a div block.</div>
            <div class="text-block-20">This is some text inside of a div block.</div>
            <div class="text-block-21">This is some text inside of a div block.</div>
            <div class="text-block-22">This is some text inside of a div block.</div>
            <div class="text-block-23">This is some text inside of a div block.</div>
          </div>
        </div>
        <div>
          <div>
            <h3 class="dealer-heading">Heading</h3>
          </div>
          <div class="reddividerdiv"></div>
          <div class="category-image-div"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/FweAiP_1.svg" width="27" height="37" alt=""><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/9NaSBr_1.svg" width="27" height="37" alt=""><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Asset-2-1.svg" width="27" height="37" alt=""><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Asset-1-1.svg" width="27" height="37" alt=""></div>
          <div>
            <div class="text-block-19">This is some text inside of a div block.</div>
            <div class="text-block-20">This is some text inside of a div block.</div>
            <div class="text-block-21">This is some text inside of a div block.</div>
            <div class="text-block-22">This is some text inside of a div block.</div>
            <div class="text-block-23">This is some text inside of a div block.</div>
          </div>
        </div>
        <div>
          <div>
            <h3 class="dealer-heading">Heading</h3>
          </div>
          <div class="reddividerdiv"></div>
          <div class="category-image-div"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/FweAiP_1.svg" width="27" height="37" alt=""><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/9NaSBr_1.svg" width="27" height="37" alt=""><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Asset-2-1.svg" width="27" height="37" alt=""><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Asset-1-1.svg" width="27" height="37" alt=""></div>
          <div>
            <div class="text-block-19">This is some text inside of a div block.</div>
            <div class="text-block-20">This is some text inside of a div block.</div>
            <div class="text-block-21">This is some text inside of a div block.</div>
            <div class="text-block-22">This is some text inside of a div block.</div>
            <div class="text-block-23">This is some text inside of a div block.</div>
          </div>
        </div>
        <div>
          <div>
            <h3 class="dealer-heading">Heading</h3>
          </div>
          <div class="reddividerdiv"></div>
          <div class="category-image-div"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/FweAiP_1.svg" width="27" height="37" alt=""><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/9NaSBr_1.svg" width="27" height="37" alt=""><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Asset-2-1.svg" width="27" height="37" alt=""><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Asset-1-1.svg" width="27" height="37" alt=""></div>
          <div>
            <div class="text-block-19">This is some text inside of a div block.</div>
            <div class="text-block-20">This is some text inside of a div block.</div>
            <div class="text-block-21">This is some text inside of a div block.</div>
            <div class="text-block-22">This is some text inside of a div block.</div>
            <div class="text-block-23">This is some text inside of a div block.</div>
          </div>
        </div>
        <div>
          <div>
            <h3 class="dealer-heading">Heading</h3>
          </div>
          <div class="reddividerdiv"></div>
          <div class="category-image-div"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/FweAiP_1.svg" width="27" height="37" alt=""><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/9NaSBr_1.svg" width="27" height="37" alt=""><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Asset-2-1.svg" width="27" height="37" alt=""><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Asset-1-1.svg" width="27" height="37" alt=""></div>
          <div>
            <div class="text-block-19">This is some text inside of a div block.</div>
            <div class="text-block-20">This is some text inside of a div block.</div>
            <div class="text-block-21">This is some text inside of a div block.</div>
            <div class="text-block-22">This is some text inside of a div block.</div>
            <div class="text-block-23">This is some text inside of a div block.</div>
          </div>
        </div>
        <div>
          <div>
            <h3 class="dealer-heading">Heading</h3>
          </div>
          <div class="reddividerdiv"></div>
          <div class="category-image-div"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/FweAiP_1.svg" width="27" height="37" alt=""><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/9NaSBr_1.svg" width="27" height="37" alt=""><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Asset-2-1.svg" width="27" height="37" alt=""><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Asset-1-1.svg" width="27" height="37" alt=""></div>
          <div>
            <div class="text-block-19">This is some text inside of a div block.</div>
            <div class="text-block-20">This is some text inside of a div block.</div>
            <div class="text-block-21">This is some text inside of a div block.</div>
            <div class="text-block-22">This is some text inside of a div block.</div>
            <div class="text-block-23">This is some text inside of a div block.</div>
          </div>
        </div>
      </div><a data-w-id="f4ad95d5-c326-c74c-9c95-2bf910f7ba37" href="#" class="buttonclass w-button">Contact us For Dealership</a></div>
  </div>


@endsection