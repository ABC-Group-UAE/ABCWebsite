@extends('Layout.layout')
@section('content')
<div class="careerimagesection">
    <div class="container-15 w-container">
      <h1 class="mainheading">Join Our Team</h1>
    </div>
</div>
  <div class="career-hero-section">
    <div class="career-container w-container">
      <div class="form-block-2 w-form">
        @php
        if(isset($message1)){
          @endphp
          <span style="color:#d7d5d5">{{$message1}}</span>
          @php
        }
        @endphp
        <form id="email-form" name="email-form" data-name="Email Form" class="form-2" action="file_upload" method="post" enctype="multipart/form-data">
            @csrf
            <label for="Candidate-Name" class="field-label">Name</label>
            
            <input type="text" class=" w-input" maxlength="256" name="Candidate_Name" data-name="Candidate Name" placeholder="Enter Your Name Here" id="Candidate_Name" required="" >
            @error('Candidate_Name')
              <span style="color:red"> {{$message}}</span><br>
            @enderror
            <label for="Candidate_mailid">Email Address</label>
            <input type="email" class=" w-input" maxlength="256" name="Candidate_mailid" data-name="Candidate_mailid" placeholder="Enter your mail Address" id="Candidate_mailid" required="" >
            @error('Candidate_mailid')
              <span style="color:red"> {{$message}}</span><br>
            @enderror
            <label for="jobPosition">Job Position you are looking for</label>
            <input type="text" class=" w-input" maxlength="256" name="jobPosition" data-name="jobPosition" placeholder="Enter the job role you are looking for" id="jobPosition" required="" >
            @error('jobPosition')
              <span style="color:red"> {{$message}}</span><br>
            @enderror
            <label for="coverletter">Cover Letter</label>
            <textarea required="" maxlength="5000" id="coverletter" name="coverletter" data-name="coverletter" placeholder="Type your cover letter" class=" w-input"></textarea>
            @error('coverletter')
              <span style="color:red"> {{$message}}</span><br>
            @enderror
            <!-- <form action="file_upload" method="post" enctype="multipart/form-data"> -->
              @csrf
              <input type="file" name="resume" id="resume" style="margin-botton:10px;" required="">
              <!-- <button type="submit">fileUpload</button> -->
            <!-- </form> -->
            @error('resume')
              <span style="color:red"> {{$message}}</span><br>
            @enderror
            <br>
            <input type="submit" value="Submit" data-wait="Please wait..." class="submit-button-2 w-button">
        
          </form>
        <div class="w-form-done">
          <div>Thank you! Your submission has been received!</div>
        </div>
        <div class="w-form-fail">
          <div>Oops! Something went wrong while submitting the form.</div>
        </div>
      </div>
    </div>
  </div>
  
  @endsection