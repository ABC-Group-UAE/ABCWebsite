
@extends('Layout.layout')

@section('content')
<?php header('Access-Control-Allow-Origin: *'); ?>
<div class="catalogue-img-container w-container">
    <h1 class="mainheading">Catalogues</h1>
</div>   
<div class="main-hero-section">
<div class="wrapper">
    @if(!empty($catalogues))    
         @foreach($catalogues as $catalogueA)
             @if($catalogueA->count())
                    
                        <div class="title-div">
                            <h1 class="headinginnerpages">
                                <?php
                                    $category ="";
                                ?>
                                @foreach($catalogueA as $catinfo)
                                <?php 
                                    $category = $catinfo->Categories->Category_Name;
                                    break;
                                ?>
                                @endforeach
                                {{ $category }}
                            </h1>

                            <div class="reddividerdiv combo-length"></div>
                        </div>
                    <div class="w-layout-grid catalogue-list">
                        @foreach($catalogueA as $catinfo)
                            <div class="image-wrapper" style="background:url('https://abccontentbucket.s3.me-south-1.amazonaws.com/images/{{$catinfo->frontCover }}');">
                            <div data-w-id="a205876a-3abe-3966-05c9-60f617972b67"  href="#" class="item-overlay w-inline-block">
                                <div style="-webkit-transform:translate3d(0, 0PX, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);-moz-transform:translate3d(0, 0PX, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);-ms-transform:translate3d(0, 0PX, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);transform:translate3d(0, 0PX, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);" class="downloadbuttonclass">
                                <a href="https://abccontentbucket.s3.me-south-1.amazonaws.com/Catalogues/{{$catinfo->pdfPath}}"  target="_blank" style="text-decoration:none;"><div class="text-block-24">View</div></a> 
                                </div>
                                <div   style="-webkit-transform:translate3d(0, 0PX, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);-moz-transform:translate3d(0, 0PX, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);-ms-transform:translate3d(0, 0PX, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);transform:translate3d(0, 0PX, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);" class="downloadbuttonclass">
                                <a href="javascript:downloadPdfFile('{{$catinfo->pdfPath}}')" style="text-decoration:none;"><div class="text-block-24">Download</div></a>
                                </div>
                            </div>
                            <div class="content-image" style="background:url('https://abccontentbucket.s3.me-south-1.amazonaws.com/images/{{$catinfo->frontCover }}');"></div>
                            </div>
                        @endforeach
                    </div>
                @endif
            @endforeach
    @endif
       
        
</div>        
</div>
<!-- {{route('catalogue.download',$catinfo->pdfPath)}} -->
<script>
function downloadPdfFile(filename){
   console.log("Inside download pdf function");
   
//    $.ajax({
//       const invocation = new XMLHttpRequest();
//       const url = 'https://abccontentbucket.s3.me-south-1.amazonaws.com/Catalogues/'+filename;
//       invocation.open('GET', url, true);
//       invocation.withCredentials = true;
//       invocation.onreadystatechange = handler;
//       invocation.send(); 
//         xhrFields: {
//             responseType: 'blob',
//             withCredentials: true
//         },
//         success: function (data) {
//             var a = document.createElement('a');
//             var url = window.URL.createObjectURL(data);
//             a.href = url;
//             a.download = filename+'.pdf';
//             document.body.append(a);
//             a.click();
//             a.remove();
//             window.URL.revokeObjectURL(url);
//         }
//     });


    $.ajax({
        url: 'https://abccontentbucket.s3.me-south-1.amazonaws.com/Catalogues/'+filename,
        method: 'GET',
        crossDomain : true,
        xhrFields: {
            responseType: 'blob',
            withCredentials: true
        },
        success: function (data) {
            var a = document.createElement('a');
            var url = window.URL.createObjectURL(data);
            a.href = url;
            a.download = filename+'.pdf';
            document.body.append(a);
            a.click();
            a.remove();
            window.URL.revokeObjectURL(url);
        }
    });

}
</script>
@endsection

    