<br>
Thanks for your enquiry...
Greetings of the day!..
You have enquired about the following products.


<br>


Product Details <br>
@php
$i=0;
@endphp
@foreach($products as $product) 
@php
$i++;
@endphp
{{$i}}. </t>
Product ID : {{ $product->id }} <br>
Product Name: {{ $product->name }}                    <br>
Quantity : {{ $product->quantity }}                          <br>



@endforeach



Very soon our customer service associate will contact you through whatsapp or call and will provide details.  

<br>

Thank you <br>

Regards,<br>