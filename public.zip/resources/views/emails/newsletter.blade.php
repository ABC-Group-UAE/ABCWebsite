
<br>

Thank you For your subscription
<br>


** Email:** {{ $newsletter->SubscriberMailid }}  <br>








<br>

Thank you <br>

Regards,<br>
Abc Website


