
<br>

applicant details.
<br>


** Email:** {{ $career->Candidate_mailid }}  <br>

** Name:** {{ $career->Candidate_Name }}  <br>

** Job position:** {{ $career->jobPosition }} <br>



**Coverletter:**   {{ $career->coverletter }}  <br>



please check the attachment for further details..

<br>

Thank you <br>

Regards,<br>
Abc Website
