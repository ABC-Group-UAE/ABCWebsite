
<br>

This customer has enquired about dealership details
<br>
Customer detail is
<br>

** Email:** {{ $contact->customer_mailid }}  <br>

** Name:** {{ $contact->CustomerName }}  <br>

** Mobile Number:** {{ $contact->mobile }} <br>



**Type of enquiry:**   {{ $contact->type_of_enquiry }}  <br>
**Message: **   {{ $contact->message }}  <br>



Please contact this person...

<br>

Thank you <br>

Regards,<br>
Abc Website