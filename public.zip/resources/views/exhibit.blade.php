@extends('Layout.layout')


@section('content')
<div class="container-21 w-container">
    <h1 class="mainheading">Explore Our World</h1>
  </div>
  <div class="main-hero-section">
    <div class="special-product-container w-container">
      <div class="w-layout-grid special-product-list">
        <div class="specialproductdiiv"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/15.jpg" loading="lazy" width="800" height="590" alt="" class="special-product-img">
          <h6 class="product-heading">Heading</h6>
        </div>
        <div class="specialproductdiiv"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/13.jpg" loading="lazy" width="800" height="590" alt="" class="special-product-img">
          <h6 class="product-heading">Heading</h6>
        </div>
        <div class="specialproductdiiv"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/14.jpg" loading="lazy" width="800" height="590" alt="" class="special-product-img">
          <h6 class="product-heading">Heading</h6>
        </div>
        <div class="specialproductdiiv"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/17.jpg" loading="lazy" width="800" height="590" alt="" class="special-product-img">
          <h6 class="product-heading">Heading</h6>
        </div>
        <div class="specialproductdiiv"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/16.jpg" loading="lazy" width="800" height="590" alt="" class="special-product-img">
          <h6 class="product-heading">Heading</h6>
        </div>
        <div class="specialproductdiiv"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/11.jpg" loading="lazy" width="800" height="590" alt="" class="special-product-img">
          <h6 class="product-heading">Heading</h6>
        </div>
      </div>
    </div>
  </div>



@endsection