@extends('Layout.layout')
@section('content')
<div class="brand-section-image-container w-container">
    <h1 class="mainheading">Our Brands</h1>
  </div>
  <div class="main-section-container w-container">
    <div>
      <div class="content-div">
        <div id="w-node-f0723db6459d-75e1cb89" class="div-block-33"><img width="347" height="147" src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Becken.svg" alt="" class="brand-logo"></div>
        <div class="div-block-92">
          <p class="paragraph-content">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat. Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc ut sem vitae risus tristique posuere.</p>
          <div class="div-block-120"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Asset-2_3.svg" loading="lazy" height="30" alt=""><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/9NaSBr_3.svg" loading="lazy" height="30" alt=""><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Asset-1_3.svg" loading="lazy" alt=""></div>
        </div>
        <div id="w-node-f0723db645a2-75e1cb89" class="website-link-div"><a href="#">website</a>
          <div class="text-block-30">mail id</div>
        </div>
      </div>
      <div class="grey-divider-div"></div>
    </div>
    <div>
      <div class="content-div">
        <div id="w-node-45e52c48ecee-75e1cb89" class="div-block-33"><img width="347" height="147" src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Bathx.svg" alt="" class="brand-logo"></div>
        <div class="div-block-92">
          <p class="paragraph-content">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat. Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc ut sem vitae risus tristique posuere.</p>
          <div class="div-block-120"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/FweAiP_3.svg" loading="lazy" height="30" alt=""><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/9NaSBr_3.svg" loading="lazy" alt=""><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Asset-2_3.svg" loading="lazy" height="30" alt=""><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Asset-1_3.svg" loading="lazy" alt=""></div>
        </div>
        <div id="w-node-45e52c48ecf3-75e1cb89" class="website-link-div"><a href="#">website</a>
          <div class="text-block-30">mail id</div>
        </div>
      </div>
      <div class="grey-divider-div"></div>
    </div>
    <div>
      <div class="content-div">
        <div id="w-node-2e0b97334e06-75e1cb89" class="div-block-33"><img width="347" height="147" src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Inox.svg" alt="" class="brand-logo"></div>
        <div class="div-block-92">
          <p class="paragraph-content">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat. Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc ut sem vitae risus tristique posuere.</p>
          <div class="div-block-120"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Asset-4_3.svg" loading="lazy" height="30" alt=""><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/FweAiP_3.svg" loading="lazy" height="30" alt=""><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Asset-2_3.svg" loading="lazy" height="30" width="114" alt=""><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Asset-1_3.svg" loading="lazy" alt=""></div>
        </div>
        <div id="w-node-2e0b97334e0b-75e1cb89" class="website-link-div"><a href="#">website</a>
          <div class="text-block-31">mail id</div>
        </div>
      </div>
      <div class="grey-divider-div"></div>
    </div>
    <div>
      <div class="content-div">
        <div id="w-node-c92f705582e9-75e1cb89" class="div-block-33"><img width="347" height="147" src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Viceroy.svg" alt="" class="brand-logo"></div>
        <div class="div-block-92">
          <p class="paragraph-content">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat. Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc ut sem vitae risus tristique posuere.</p>
          <div class="div-block-120"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Asset-4_3.svg" loading="lazy" height="30" alt=""></div>
        </div>
        <div id="w-node-c92f705582ee-75e1cb89" class="website-link-div"><a href="#">website</a>
          <div class="text-block-30">mail id</div>
        </div>
      </div>
      <div class="grey-divider-div"></div>
    </div>
    <div>
      <div class="content-div">
        <div id="w-node-589620750d7e-75e1cb89" class="div-block-33"><img width="347" height="147" src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Deko.svg" alt="" class="brand-logo"></div>
        <div class="div-block-92">
          <p class="paragraph-content">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat. Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc ut sem vitae risus tristique posuere.</p>
          <div class="div-block-120"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Asset-4_3.svg" loading="lazy" height="30" alt=""></div>
        </div>
        <div id="w-node-913beba6d0e4-75e1cb89" class="website-link-div"><a href="#">website</a>
          <div class="text-block-30">mail id</div>
        </div>
      </div>
      <div class="grey-divider-div"></div>
    </div>
  </div>
  @endsection