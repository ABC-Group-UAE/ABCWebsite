@if(!empty($catalogues))
<div class="section-7">
    <div class="wrapper">

        
            @foreach($catalogues as $catalogueA)
                @if($catalogueA->count())

                        <div class="div-block-40">
                            <h1 class="headinginnerpages">
                            @if (isset($catalogueA[0])) 
                                {{ $catalogueA[0]->Categories->Category_Name  }}
                            @else
                                SanitaryWare
                            @endif
                            </h1>
                            <div class="reddividerdiv combo-length"></div>
                        </div>
                    <div class="w-layout-grid collection-list-8">
                        @foreach($catalogueA as $catinfo)
                        <!-- <input type="hidden" id="{{ $catinfo->catalogue_name }}" value="{{ $catinfo->id }}" > -->
                        <div class="image-wrapper" style="background:url(https://abccontentbucket.s3.me-south-1.amazonaws.com/images/{{$catinfo->PathVariable) }});">
                                <a data-w-id="b1745dc5-4810-a961-6ca0-42e0c98ae5d8" style="opacity:0" href="#" class="item-overlay w-inline-block">
                                    <div style="-webkit-transform:translate3d(0, 0PX, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);-moz-transform:translate3d(0, 0PX, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);-ms-transform:translate3d(0, 0PX, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);transform:translate3d(0, 0PX, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);opacity:0" class="downloadbuttonclass" id="view.{{$catinfo->id }}">
                                        <div class="text-block-24">
                                            <a href="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/{{$catinfo->PathVariable) }}"  target="_blank">
                                            View
                                            </a>
                                        </div>
                                    </div>
                                    <div style="-webkit-transform:translate3d(0, 0PX, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);-moz-transform:translate3d(0, 0PX, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);-ms-transform:translate3d(0, 0PX, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);transform:translate3d(0, 0PX, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);opacity:0" class="downloadbuttonclass" id="download.{{$catinfo->id }}">
                                    <div class="text-block-24">Download</div>
                                    </div>
                                </a>
                                <div class="content-image"  style="background:url(https://abccontentbucket.s3.me-south-1.amazonaws.com/images/{{$catinfo->PathVariable) }});"></div>
                            </div>
                        @endforeach
                    </div>


                @endif
            
            
            @endforeach
            
        
    </div>
</div>
@endif 