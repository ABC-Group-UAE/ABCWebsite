<!DOCTYPE html>
<!--  This site was created in Webflow. http://www.webflow.com  -->
<!--  Last Published: Tue Sep 15 2020 12:53:39 GMT+0000 (Coordinated Universal Time)  -->
<html data-wf-page="5f3cd9955420ff68d4ca7deb" data-wf-site="5f103f7e5224a5353e5ce1c7">
<head>
  <meta charset="utf-8">
  <title>Product Exploration</title>
  <meta content="Product Exploration" property="og:title">
  <meta content="Product Exploration" property="twitter:title">
  <meta content="width=device-width, initial-scale=1" name="viewport">
  <meta content="Webflow" name="generator">
  <link href="{{asset('css/normalize.css')}}" rel="stylesheet" type="text/css">
  <link href="{{asset('css/webflow.css')}}" rel="stylesheet" type="text/css">
  <link href="{{asset('css/abcgroupuae.webflow.css')}}" rel="stylesheet" type="text/css">
  <!-- [if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.min.js" type="text/javascript"></script><![endif] -->
  <script type="text/javascript">!function(o,c){var n=c.documentElement,t=" w-mod-";n.className+=t+"js",("ontouchstart"in o||o.DocumentTouch&&c instanceof DocumentTouch)&&(n.className+=t+"touch")}(window,document);</script>
  <link href="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/favicon.ico')}}" rel="shortcut icon" type="image/x-icon">
  <link href="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/webclip.png" rel="apple-touch-icon">
  <script src="http://code.jquery.com/jquery-1.11.3.min.js"></script>
  <script src="{{ asset('js/ranger.js') }}"></script>
<script src="{{ asset('js/jquery.min.js') }}"></script>
<script src="{{ asset('js/jquery-ui.min.js') }}"></script>
<link href="{{ asset('extra_css/ranger.css') }}" rel="stylesheet">
<link href="{{ asset('extra_css/jquery-ui.css') }}" rel="stylesheet">
<link href="{{ asset('css/bootstyle.css') }}" rel="stylesheet">
<link href='https://use.fontawesome.com/releases/v5.7.2/css/all.css'>
<script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js'></script>
<link href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css'>
<!-- <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script> -->
<script type='text/javascript' src='https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js'></script>

</head>
<body class="category-listing-div">
@include('Common.Header')
<link href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css' rel='stylesheet'>
                                <link href='https://use.fontawesome.com/releases/v5.7.2/css/all.css' rel='stylesheet'>
                                <style>


.wrapper {
    width: 50%;
    margin-top: 50px
}

@media(max-width:992px) {
    .wrapper {
        width: 100%
    }
}

.panel-heading {
    padding: 0;
    border: 0;
    padding: 9px 3px !important
}

.panel-title>a,
.panel-title>a:active {
    display: block;
    padding: 10px;
    color: #555;
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 1px;
    word-spacing: 3px;
    text-decoration: none
}

.panel-heading a:before {
    font-family: 'Glyphicons Halflings';
    content: "\e114";
    float: right;
    transition: all 0.5s
}

.panel-heading.active a:before {
    -webkit-transform: rotate(180deg);
    -moz-transform: rotate(180deg);
    transform: rotate(180deg)
}

.panel-default>.panel-heading {
    color: #282b2f;
    background-color: #ffffff !important;
    border-color: #d5d5d5
}

@keyframes click-wave {
    0% {
        height: 40px;
        width: 40px;
        opacity: 0.15;
        position: relative
    }

    100% {
        height: 200px;
        width: 200px;
        margin-left: -80px;
        margin-top: -80px;
        opacity: 0
    }
}

.option-input {
    -webkit-appearance: none;
    -moz-appearance: none;
    -ms-appearance: none;
    -o-appearance: none;
    appearance: none;
    position: relative;
    top: -8.66667px;
    right: 0;
    bottom: 0;
    left: 0;
    height: 24px;
    width: 24px;
    transition: all 0.15s ease-out 0s;
    background: #cbd1d8;
    border: none;
    color: #fff;
    cursor: pointer;
    display: inline-block;
    margin-right: 0.5rem;
    outline: none;
    position: relative;
    z-index: 1000
}

.option-input:hover {
    background: #9faab7
}

.option-input:checked {
    background: #2874ef
}

.option-input:checked::before {
    height: 24px;
    width: 24px;
    position: absolute;
    content: "\f111";
    font-family: "Font Awesome 5 Free";
    display: inline-block;
    font-size: 14.66667px;
    text-align: center;
    line-height: 26px
}

.option-input:checked::after {
    -webkit-animation: click-wave 0.15s;
    -moz-animation: click-wave 0.15s;
    animation: click-wave 0.15s;
    background: #E91E63;
    content: '';
    display: block;
    position: relative;
    z-index: 100
}

.option-input.radio {
    border-radius: 50%
}

.option-input.radio::after {
    border-radius: 50%
}

.checkbox input[type="checkbox"],
.checkbox-inline input[type="checkbox"] {
    float: left;
    margin-left: -4px !important;
    margin-top: 9px
}

input[type="checkbox"]:focus {
    outline: thin dotted #333;
    outline: 0px auto -webkit-focus-ring-color;
    outline-offset: 0px
}

.ml-10 {
    margin-left: 10px;
    font-size: 12px;
    color: #080808
}

.btn.btn-out {
    outline: 1px solid #fff;
    outline-offset: -5px
}

.btn {
    border-radius: 2px;
    text-transform: capitalize;
    font-size: 11px;
    padding: 10px 19px;
    cursor: pointer;
    color: #fff
}

.fa {
    font-size: 12px;
    color: #2874ef
}

.refine {
    padding: 0px 0px !important
}

.filters-text {
    background: #fff;
    border: 1px solid #d5d5d5;
    margin-bottom: 15px;
    padding: 12px
}

.filter-span {
    font-size: 17px;
    color: #2874ef
}
	
	
	.scrolling-wrapper {
		overflow-x: scroll;
		overflow-y: hidden;
		white-space: nowrap;
		-webkit-overflow-scrolling: touch;

	}
	::-webkit-scrollbar {
    width: 0px;  /* Remove scrollbar space */
    background: transparent;  /* Optional: just make scrollbar invisible */
    }  
	
	.card {
		display: inline-block;
		width:40%;
	}
	.button-3 {
		width:100%;
	}

	.button-3:small {
		border-top-style: solid;
		border-top-width: 1px;
		border-top-color: hsla(0, 2.52%, 7.15%, 1.00);
		border-right-style: solid;
		border-right-width: 1px;
		border-right-color: hsla(0, 2.52%, 7.15%, 1.00);
		border-bottom-style: solid;
		border-bottom-width: 1px;
		border-bottom-color: hsla(0, 2.52%, 7.15%, 1.00);
		border-left-style: solid;
		border-left-width: 1px;
		border-left-color: hsla(0, 2.52%, 7.15%, 1.00);
		border-top-left-radius: 14px;
		border-top-right-radius: 14px;
		border-bottom-left-radius: 14px;
		border-bottom-right-radius: 14px;
		background-color: @swatch_a30af6ce;
		color: hsla(0, 1.36%, 3.95%, 1.00);
	}

	.button-3:small_current {
		margin-top: 7px;
		margin-right: 20px;
		margin-left: 25px;
	}

	.button-3:tiny_current {
		margin-left: 0px;
	}

</style>






<?php
use App\Category;
?>

<?php
$SelectedCategory='ALL';
$SelectedSubCategory='ALL';
$SelectedSubSubCategory='ALL';
$categorycolor ="black";
if(!empty($selectedCatValue)){
	$SelectedCategory = $selectedCatValue;
}
if(!empty($selectedSubCatValue)){
	$SelectedSubCategory = $selectedSubCatValue;
}
if(!empty($selectedSubSubCatValue)){
	$SelectedSubSubCategory = $selectedSubSubCatValue;
}

?>
<form action="{{ route('Explore')}}" method="" id="Explore">
	{{csrf_field()}}
	<input type="hidden" id="selCategory" name="selCategory" value="{{$SelectedCategory}}">
	<input type="hidden" id="selSubCategory" name="selSubCategory" value="{{$SelectedSubCategory}}">
	<input type="hidden" id="selSubSubCategory" name="selSubSubCategory" value="{{$SelectedSubSubCategory}}">
	<input type="hidden" id="SelectedSUBCategories" name="SelectedSUBCategories" value="">
	<input type="hidden" id="SelectedBrands" name="SelectedBrands" value="">
	<input type="hidden" id="SelectedColours" name="SelectedColours" value="">
	<input type="hidden" id="min_price1" name="min_price1" value="0">
	<input type="hidden" id="max_price1" name="max_price1" value="6000">

	<div>
		<div class="product-container w-container " >
			
			
			 <div class="mobile-filter-div" > 
				<div class='snippet-body'  oncontextmenu='return false'>
				<div class="d-flex justify-content-center">
					<div class="wrapper center-block">
						<div class="filters-text">
							<span class="filter-span">Filters <small>(find product using filters below)</small></span>
							<span style="float:right;"><i class="fa fa-filter"></i></span>
						</div>
						<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
						@if( !($Categories->isEmpty()))
						@php
							$heading=0;
						@endphp
						@foreach($Categories as $Category)
						@php
							$heading++;
						@endphp
						<div class="panel panel-default">
								<div class="panel-heading" role="tab" id="heading{{$heading}}">
									<h4 class="panel-title"> <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse{{$heading}}" aria-expanded="false" aria-controls="collapse{{$heading}}"> {{$Category->Category_Name}} </a> </h4>
								</div>
								<div id="collapse{{$heading}}" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading{{$heading}}">
									@php
										$subCategories = Category::find($Category->Category_ID)->SubCategories;
									@endphp
									<div class="panel-body">
										@if( !($subCategories->isEmpty())) <!-- checking if sub category list empty -->
											@foreach($subCategories as $subCategory)
											<div class="checkbox"> <label> <input type="checkbox" class="option-input checkbox" name="category1"   value="{{$subCategory->Category_ID}}-{{$subCategory->Sub_Category_ID}}" onChange="updateCategory()"/> <span class="ml-10">{{$subCategory->Sub_Category_Name}}</span> </label> </div>
													@php
													$subSubCategories = $subCategory->SubSubCategories($subCategory->Category_ID,$subCategory->Sub_Category_ID);
													@endphp
													@if( !($subSubCategories->isEmpty()))  <!-- checking if sub sub category list empty -->
														@foreach($subSubCategories as $subSubCategory) 
															<div class="checkbox" style="margin-left: 10%"> <label> <input type="checkbox" class="option-input checkbox" name="category1"   value="{{$subSubCategory->Category_ID}}-{{$subSubCategory->Sub_Category_ID}}-{{$subSubCategory->Sub_Sub_Category_ID}}" onChange="updateCategory()"/> <span class="ml-10">{{$subSubCategory->Sub_Sub_Category_Name}}</span> </label> </div>
														@endforeach
													@endif
											@endforeach
										@endif
									</div>
								</div>
						</div>
						    @endforeach
						    @endif
						    @php
							$heading++;
						    @endphp
							<div class="panel panel-default">
								<div class="panel-heading" role="tab" id="heading{{$heading}}">
									<h4 class="panel-title"> <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse{{$heading}}" aria-expanded="false" aria-controls="collapse{{$heading}}"> Price </a> </h4>
								</div>
								<div id="collapse{{$heading}}" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading{{$heading}}">
									<div class="panel-body">
											<div class="filter-section-div"><h3 class="filter-main-heading">Price (AED)</h3></div><div class="pricechoosediv"><input type="number" name="min" id="min_price2" aria-label="min" class="text-field-4 w-input" value="0" onChange="updatePrice()"><span class="jsx-304923497 between">To</span><input type="number" name="max" id="max_price2" aria-label="max" class="text-field-4 w-input" value="6000" onChange="updatePrice()"></div>
										
									</div>
								</div>
							</div>
							@php
							$heading++;
						    @endphp
							<div class="panel panel-default">
								<div class="panel-heading" role="tab" id="heading{{$heading}}">
									<h4 class="panel-title"> <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse{{$heading}}" aria-expanded="false" aria-controls="collapse{{$heading}}"> Brand </a> </h4>
								</div>
								<div id="collapse{{$heading}}" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading{{$heading}}">
									<div class="panel-body">
									@if( (sizeof($Brands)>0))
									@foreach($Brands as $Branditem)
										<div class="checkbox"> <label> <input type="checkbox" class="option-input checkbox" name="Brands1" value="{{$Branditem->Brand_Name}}" onChange="updateBrand()" /> <span class="ml-10">{{$Branditem->Brand_Name}}</span> </label> </div>
										
									@endforeach
									@endif
									
									</div>
								</div>
							</div>
							@php
							$heading++;
						    @endphp
							<div class="panel panel-default">
								<div class="panel-heading" role="tab" id="heading{{$heading}}">
									<h4 class="panel-title"> <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse{{$heading}}" aria-expanded="false" aria-controls="collapse{{$heading}}"> Colours </a> </h4>
								</div>
								<div id="collapse{{$heading}}" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading{{$heading}}">
									<div class="panel-body">
									@if( (sizeof($colours)>0)) 
									@foreach($colours as $colouritem)
										<div class="checkbox"> <label> <input type="checkbox" class="option-input checkbox" name="colours1" value="{{$colouritem->colour}}" onChange="updateColour()" /> <span class="ml-10">{{$colouritem->colour}}</span> </label> </div>
									@endforeach
									@endif
									</div>
								</div>
							</div>
							
						</div>
						<div class="text-right refine"> <button class="btn btn-out btn-primary btn-square" id="apply" onClick ="fetchDataBasedOnMobileFilter()">Apply</button> </div>
						<div class="text-left refine"> <button class="btn btn-out btn-primary btn-square" id="resetButton" onClick ="reset()">Reset</button> </div>
					</div>
				</div>

				</div>				




				<div class="scrolling-wrapper">
					@if( !($Categories->isEmpty()))
					<select onChange="MobileFiltering('','Category',event)" id="selectionCat" class="card button-3 w-button">
						<option value="" >--Select Category --</option>
						@foreach($Categories as $Category)
						<option value="{{$Category->Category_ID}}" @php if(isset($SelectedCategory)) { 
                          if(strcmp($SelectedCategory ,$Category->Category_ID) == 0) 
                           { echo "selected=selected"; } }@endphp > {{$Category->Category_Name}}</option>

						
						@endforeach
					</select>
					@endif
					
					<div class="card">
						<button class="button-3 w-button" onClick="MobileFiltering('','Price',event)">price</button>
					</div>
					<div class="card">
						<button class="button-3 w-button" onClick="MobileFiltering('','Brand',event)">Brand</button>
					</div>
					<div class="card">
						<button class="button-3 w-button" onClick="MobileFiltering('','Colour',event)">Colour</button>
					</div>

				</div>
				<form id="mobileForm">
					{{csrf_field()}}
					<div class="filter-listing-div" id="MobileFilter">
						
						


					</div>
					<div><button onClick ="fetchDataBasedOnMobileFilter()" id="apply" style="display: none;" >Apply</button>
					<button onClick ="reset()" id="resetButton" style="display: none;" >Reset</button></div>
					
				</form>
				
				
			</div>
			<div class="desktop-filter-div">
				<div class="filter-section-div">
					<h3 class="filter-main-heading">Our Products</h3>
					<a href="#" onClick="fetchData('ALL')" aria-current="page" class="category-link w--current">All Products</a>

					@if( !($Categories->isEmpty()))  <!-- all category listing div  checking categories exist-->

					@foreach($Categories as $Category)<!-- category iterating loop   -->
					<div class="category-listing-div w-clearfix" >
						<a href="#"  onClick="fetchData('{{$Category->Category_ID}}')" aria-current="page" class="category-link w--current" id="{{$Category->Category_ID}}">{{$Category->Category_Name}}</a>

						@if($SelectedCategory == $Category->Category_ID)<!-- checking if selected category === this category -->
						<?php
						$categorycolor ="red";
				// if($Selected == $Category->Category_ID){
						$subCategories = Category::find($Category->Category_ID)->SubCategories;
				// $subCategories = $Categories->SubCategories;
				//dd($subCategories);
				//style="font-style:{{($SelectedCategory == $Category->Category_ID) ? 'red' : '' }} "
						?>

						@if( !($subCategories->isEmpty())) <!-- checking if sub category list empty -->


						@foreach($subCategories as $subCategory) <!-- looping sub categories -->
						<?php
				// if($Selected == $Category->Category_ID){
						$subSubCategories = $subCategory->SubSubCategories($subCategory->Category_ID,$subCategory->Sub_Category_ID);
				// $subCategories = $Categories->SubCategories;
				//dd($subCategory->Category_ID);
				//dd ($subCategory->Sub_Category_ID); 
				//dd($subSubCategories);
						?>
						@if($SelectedCategory == $subCategory->Category_ID)
						<div  style="margin-left: 10%;">
							<div style="display:flex"><input type="checkbox" @php if(isset($selectedSubCatValue)) { 
            if(strcmp($selectedSubCatValue ,$subCategory->Sub_Category_ID) == 0) 
            { echo "checked=checked"; }}@endphp name="category"  id="{{$subCategory->Category_ID}}-{{$subCategory->Sub_Category_ID}}" value="{{$subCategory->Category_ID}}-{{$subCategory->Sub_Category_ID}}" onChange="fetchDataBasedOnFilter('checkbox')" ><a  aria-current="page" class="category-link w--current">{{$subCategory->Sub_Category_Name}}</a></div>
							<!-- name="{{$subCategory->Category_ID}}-{{$subCategory->Sub_Category_ID}}" -->
							<!-- onClick="fetchDataCategory('{{$subCategory->Category_ID}}','{{$subCategory->Sub_Category_ID}}',{{$subCategories}})" -->

							@if( !($subSubCategories->isEmpty()))  <!-- checking if sub sub category list empty -->

							<div style="margin-left: 10%">
								@foreach($subSubCategories as $subSubCategory) <!-- looping sub sub categories -->

								<div style="display:flex"><input type="checkbox" @php if(isset($selectedSubSubCatValue) && isset($selectedSubCatValue)) { 
            if((strcmp($selectedSubSubCatValue ,$subSubCategory->Sub_Sub_Category_ID) == 0) && (strcmp($selectedSubCatValue ,$subCategory->Sub_Category_ID) == 0)) 
            { echo "checked=checked"; }}@endphp name="category" value="{{$subSubCategory->Category_ID}}-{{$subSubCategory->Sub_Category_ID}}-{{$subSubCategory->Sub_Sub_Category_ID}}" id="{{$subSubCategory->Category_ID}}-{{$subSubCategory->Sub_Category_ID}}-{{$subSubCategory->Sub_Sub_Category_ID}}" onChange="fetchDataBasedOnFilter('checkbox')" ><a  aria-current="page" class="category-link w--current">{{$subSubCategory->Sub_Sub_Category_Name}}</a></div>
								<!-- name="{{$subSubCategory->Category_ID}}-{{$subSubCategory->Sub_Category_ID}}-{{$subSubCategory->Sub_Sub_Category_ID}}" -->
								<!--  onClick="fetchDataSubCategory('{{$subSubCategory->Category_ID}}','{{$subSubCategory->Sub_Category_ID}}','{{$subSubCategory->Sub_Sub_Category_ID}}',{{$subSubCategories}})" --> 
								@endforeach <!--end of  looping sub sub categories -->
							</div> 

							@endif  <!-- end of if sub sub category list empty -->
						</div>
						@endif 
						@endforeach  <!-- end of looping sub categories -->
						@endif  <!--  close checking if sub category list empty -->

						@endif <!--  close of if selected category === this category -->

					</div>
					@endforeach <!-- end of vategory iterating loop -->
					@endif  <!-- all category listing div  close of category exist checking if -->

				</div>
				<div class="filter-section-div">
					<h3 class="filter-main-heading">Price Range</h3>
					<div>Select your Price Range:</div>
					<div id="slider-min" class="price-ranger" style="display:block">
						<!-- my price ranger code -->
						<div id="slider-range" class="price-filter-range" name="rangeInput">
						</div>  
						<input type="number" min=0 max="5900" oninput="validity.valid||(value='0');" id="min_price" class="price-range-field" />
						<input type="number" min=0 max="6000" oninput="validity.valid||(value='6000');" id="max_price" class="price-range-field" />
						<br>
						<div>
							<button class="price-range-search" id="price-range-submit" onClick="fetchDataBasedOnFilter('Button')">Search</button>
						</div>



						<div id="searchResults" class="search-results-block" ></div>

						<!-- end of price ranger code -->


					</div>

				</div>
				<div class="filter-section-div">
					<h3 class="filter-main-heading">Colour</h3>
					<!-- class="colour-filter-div" -->
					<?php
					$i=1;
					?>
					<div  >
						@if( (sizeof($colours)>0)) 
						
						<div class="colourlisting">
						@foreach($colours as $colouritem)
					
							<div class="colourdivflex"><input type="checkbox" name="colours" value="{{$colouritem->colour}}" onChange="fetchDataBasedOnFilter('checkbox')">{{$colouritem->colour}} </div>

							

						
						
						@endforeach
						</div>
						@endif

					</div>
				</div>
				<div class="filter-section-div">
					<h3 class="filter-main-heading">Our Brands</h3>
					@if( (sizeof($Brands)>0))
					@foreach($Brands as $Branditem)
					<div class="brand-filter-div"><input type="checkbox"  @php if(isset($selectedBrand)) { 

            if((strcmp($selectedBrand ,strtolower($Branditem->Brand_Name)) == 0)) 
            { echo "checked=checked"; }}@endphp name="Brands" value="{{$Branditem->Brand_Name}}" onChange="fetchDataBasedOnFilter('checkbox')">{{$Branditem->Brand_Name}}</div>
					@endforeach
					@endif

				</div>
			</div>

			@if( !($products->isEmpty()))
			<div class="w-layout-grid product-display-grid"  id ="productList">
				@foreach($products as $product)
				<div class="product-display-div">
					<div class="productlink-holding-div">
						<a href="{{ route('Product.description', $product->Product_id) }}" class="combocolorandavoidunderline w-inline-block">
							<div class="product-image-div"><img height="235" width="400" src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/{{$product->MainImage)}}" data-w-id="437c5c3e-61c4-24a8-550f-2bf0e3b35adc" alt="" class="product-image"></div>
							<div class="product-name combocolor">{{$product->product_name}}</div>
						</a>
					</div>
					<div class="fav-cart">
						<div class="fav" onClick=" return wishListAddition('{{$product->Product_id}}',event)" ><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/002-love.svg" width="22" height="22" alt="" class="favimage">
							<div class="like-text">Like</div>
						</div>
						<div class="addtocartbutton" onClick=" return CartAddition('{{$product->Product_id}}',event)"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Shoplist-Ikea-rzk-version.svg" width="19" height="19" alt="" class="cart-img">
							<div class="addtocarttext">Add To Cart</div>
						</div>
					</div>
				</div>
				@endforeach
			</div>

			@else
			<h1>No Products to display </h1>
			@endif
			<div id="main"></div>
		</div>

	</div>
</form>


<script>
	

	function MobileFiltering(selectedVal,Type,event)
	   {
			event.preventDefault();
			$("#MobileFilter").empty();
			var CatID ="";
			if(selectedVal == ""){
				CatID = $("#selectionCat option:selected").val();
			}else{
				CatID = selectedVal;
			}
			console.log("selectedvalue="+CatID);
			if(Type =="Price")
			{
				console.log("Inside Price selection");
				var priceDiv =	"<div class='filter-section-div'><h3 class='filter-main-heading'>Price (AED)</h3></div><div class='pricechoosediv'><input type='number' name='min' id='min_price2' aria-label='min' class='text-field-4 w-input' value='0' onChange='updatePrice()'><span class='jsx-304923497 between'>To</span><input type='number' name='max' id='max_price2' aria-label='max' class='text-field-4 w-input' value='6000' onChange='updatePrice()'></div>";
				$("#MobileFilter").append(priceDiv);
					var min_price = $('#min_price1').val();
					var max_price = $('#max_price1').val();

					$('#min_price2').val(min_price);
					$('#max_price2').val(max_price);

			}
			

			var url = "{{ route('Categories.Fetch') }}";
			var _token = '<?php echo csrf_token() ?>';
			//alert(url);
			$.ajax(
			{
				type: "get",
				url: url,
				data: {   

					selectedCat : CatID,
					Type:Type,
					_token  :_token
				},
				success:function(result,e){
					console.log(result);
					console.log(url);
					if(result.Type == "Category"){
						if(result.subCategories.length != 0){
							var subCategories = result.subCategories;
							var categoryName="";
							switch(subCategories[0].Category_ID){
								case 'C': categoryName = "Ceramics"; break;
								case 'S': categoryName = "SanitaryWares"; break;
								case 'A': categoryName = "Allied"; break;
								case 'Z': categoryName = "Accessories"; break;
								case 'K': categoryName = "Kitchen"; break;
								case 'M': categoryName = "Mixers"; break;
							}
							$("#MobileFilter").append("<div class='filter-section-div'><h3 class='filter-main-heading'>"+categoryName+"</h3></div>");
						}
						for( var subcat in subCategories){
							var subsubcategories = subCategories[subcat].SubsubCat;
							console.log(subsubcategories);
							var html ="";
							if(subsubcategories.length > 0){
								html = "<div  class='catlistinggrid'>";
								for(var subsubcat in subsubcategories){
									html += "<div class='subsubcategorylisting' ><input type='checkbox' name='category1' value='"+subsubcategories[subsubcat].Category_ID+"-"+subsubcategories[subsubcat].Sub_Category_ID+"-"+subsubcategories[subsubcat].Sub_Sub_Category_ID +"' id='"+subsubcategories[subsubcat].Category_ID+"-"+subsubcategories[subsubcat].Sub_Category_ID+"-"+subsubcategories[subsubcat].Sub_Sub_Category_ID +"'onChange='updateCategory()'  ><a  aria-current='page' class='link combolink'>"+subsubcategories[subsubcat].Sub_Sub_Category_Name+"</a></div>";
								}
								html +="</div>";
							}
							var CategoryDiv = "<div id='"+subCategories[subcat].Category_ID+"-"+subCategories[subcat].Sub_Category_ID+"'  class='subcatdiv'><div class='subcategorylisting'><input type='checkbox' name='category1'  id='"+subCategories[subcat].Category_ID+"-"+subCategories[subcat].Sub_Category_ID +"' value='"+subCategories[subcat].Category_ID+"-"+subCategories[subcat].Sub_Category_ID+"' onChange='updateCategory()' ><a  aria-current='page' class='link'>"+subCategories[subcat].Sub_Category_Name+"</a></div></div>";
							$("#MobileFilter").append(CategoryDiv);
							$("#"+subCategories[subcat].Category_ID+"-"+subCategories[subcat].Sub_Category_ID).append(html);

						}
						console.log($("#SelectedSUBCategories").val());
						console.log($("#SelectedColours").val());
						console.log($("#SelectedBrands").val());
						//////////////////////////////

						var category = $("#SelectedSUBCategories").val();
						checkboxchecking('category1',category);
						
						console.log($("#SelectedSUBCategories").val());
						console.log($("#SelectedColours").val());
						console.log($("#SelectedBrands").val());

						/////////////////////////////////

					}else if(result.Type=="Colour"){
						console.log(result.Type);
						var colourDiv ="<div class='filter-section-div'><h3 class='filter-main-heading'>Colour</h3><div>";
						var colours = result.Colours;
						var i=0;
						console.log(colours);
						if( result.Colours.length>0) {
							colourDiv+= "<div class='colourlisting'>";
							for(var colour in  colours){
								i++;
								// if(i%2 != 0){
								// 	colourDiv+= "<center><div class='brand-filter-div'>";
								// }
								colourDiv+="<div class='colourdivflex'><input type='checkbox' name='colours1' value="+colours[colour].colour+" onChange='updateColour()' ><span class='link combolink'>"+colours[colour].colour +"</span></div>";
								// if(i%2 == 0){
								// 	colourDiv+="</div></center>";
								// }
							}
							colourDiv+="</div>";

						}
						$("#MobileFilter").append(colourDiv);

						//////////////////////////////////////////////////////////////////////
						console.log($("#SelectedColours").val());
						var coloursss = $("#SelectedColours").val();
						checkboxchecking('colours1',coloursss);
						
						
						///////////////////////////////////////////////////////////////////////
					}else if(result.Type=="Brand"){
						var Brands = result.Brands;
						var brandDiv ="<div class='filter-section-div'><h3 class='filter-main-heading'>Our Brands</h3><div class='brandlistinggrid' >";
						if(result.Brands.length>0){
							for(var brand in Brands){
								brandDiv+="<div class='branddivflex'><input type='checkbox' name='Brands1'  value="+ Brands[brand].Brand_Name+" onChange='updateBrand()'><span class='link combolink'>"+Brands[brand].Brand_Name+"</span></div>";
							}
						}
						brandDiv+="</div></div>";
						$("#MobileFilter").append(brandDiv);
						////////////////////////////////////////////////////////////////
						var brandsss = $("#SelectedBrands").val();
						checkboxchecking('Brands1',brandsss);
				    	
						//////////////////////////////////////////////////////////////////

					}


				},
				error:function(result) {
					alert('error');
					console.log(result);
				}

			});
			$("#apply").show();
			$("#resetButton").show();


		}

		function checkboxchecking(checkboxname,value)
		{
			console.log("checkboxname = "+checkboxname);
			console.log("passed value = "+value);
			var values = value.split(",");
				console.log("values"+values);
				     	if(values.length > 1 ){
				     			var Checkboxes = document.getElementsByName(checkboxname);
				     			for(var cat in values){
									 console.log("length="+Checkboxes.length);
									 console.log("selected value ="+values[cat]);
				     					for (var i=0; i<Checkboxes.length; i++) {
				     						console.log("value"+Checkboxes[i].value);
				     						if (Checkboxes[i].value == values[cat]) {
												Checkboxes[i].checked = true;
												console.log("Marked as checked")
											 }
											//  else{
											// 			Checkboxes[i].checked = false;
											// 		 }
				     					}

				     			}


				     	}else if(values.length == 1 && values[0] != ""){
				     			var Checkboxes = document.getElementsByName(checkboxname);
				     			for(var cat in values){
				     					for (var i=0; i<Checkboxes.length; i++) {
				     								if (Checkboxes[i].value == values[cat]) {
														Checkboxes[i].checked = true;
													 }
													//  else{
													// 	Checkboxes[i].checked = false;
													//  }

				     					}

				     			}

				     	}
		}


		function fetchData(Selected){
			//alert($("#selCategory").val());
			if($("#selCategory").val() != "ALL"){
				var selCategory = $("#selCategory").val();
			}
			selCategory = selCategory
			$("#selCategory").val(Selected);
			//alert("Hi Inside Form submit function");
			
			//alert($("#selCategory").val());
			$("#Explore").submit();
		}
		
		
		function updatePrice(){
			var min_price = $('#min_price2').val();
			var max_price = $('#max_price2').val();

			$('#min_price1').val(min_price);
			$('#max_price1').val(max_price);
		}
		function fetchDataBasedOnFilter(type){


			event.preventDefault();
			//alert($("#selCategory").val());
			var selected = $("#selCategory").val();
			var checkboxes = document.getElementsByName("category");
			var categories = [];
			for (var i=0; i<checkboxes.length; i++) {
			     // And stick the checked ones onto an array...
			     if (checkboxes[i].checked) {
			     	//alert(checkboxes[i].value);
			     	categories.push(checkboxes[i].value);

			       // alert(checkboxes[i].value);
			   }
			}

			if(categories.length==0){
				categories.push("ALL");
			}
			 // alert(categories);
			 var colourcheckboxes = document.getElementsByName("colours");
			 var selColours = [];
			 for (var i=0; i<colourcheckboxes.length; i++) {
			     // And stick the checked ones onto an array...
			     if (colourcheckboxes[i].checked) {
			     	//alert(checkboxes[i].value);
			     	selColours.push(colourcheckboxes[i].value);

			       // alert(checkboxes[i].value);
			   }
			}
			  // if(selColours.length==0){
			  // 	selColours.push("ALL");
			  // }
			  var colourCount = selColours.length;
			 // alert(selColours.length);
			 // alert(selColours);
			 var brandcheckboxes = document.getElementsByName("Brands");
			 var selBrands = [];
			 for (var i=0; i<brandcheckboxes.length; i++) {
			     // And stick the checked ones onto an array...
			     if (brandcheckboxes[i].checked) {
			     	//alert(checkboxes[i].value);
			     	selBrands.push(brandcheckboxes[i].value);

			       // alert(checkboxes[i].value);
			   }
			}
			  // if(selBrands.length==0){
			  // 	selBrands.push("ALL");
			  // }
			  var brandCount = selBrands.length;
			 // alert(selBrands.length);
			 // alert(selBrands);
			 var min_price = $('#min_price').val();
			 var max_price = $('#max_price').val();

			 var url = "{{ route('Product.Fetch') }}";
			 var _token = '<?php echo csrf_token() ?>';
			//alert(url);
			$.ajax(

			{
				type: "post",
				url: url,
				data: {   
					categories:categories,
					selectedCat : selected,
					selColours : selColours,
					selBrands  :selBrands,
					min_price:min_price,
					max_price:max_price,
					colourCount : colourCount,
					brandCount  : brandCount,
					_token  :_token
				},
				success:function(result,e) {
					console.log(result)


					console.log(url);

					console.log(result.products);
		      				// console.log(result.message);
		      				// console.log(result.Sub_Category_ID);
		      				// console.log(result.Category_ID);
		      				var products =result.products;
		      				console.log(products.length);
		      				product_display(products);

		      			},
		      			error:function(result) {
		      				alert('error');
		      				console.log(result);

		      			}
		      		});

		}
		
		
		function CartAddition(productId,e)
		{

			event.preventDefault();

          //alert(productId +" and "+fromValue);
          var url = "{{ route('Cart.Add') }}";
          var _token = '<?php echo csrf_token() ?>';
           // alert(url);
           // alert(_token);
           $.ajax({
           	type: "post",
           	url: url,
           	data: {   
           		id: productId,
           		Quantity: 1,
           		_token  :_token
           	},
           	success:function(result,e) {
                   // alert(result.message+"and"+ result.count+"and"+ result.success );
                   console.log(result);
                   console.log(result.data);
                   console.log(result.message);
                   console.log(result.count);
                    if(result.count > 0){ //checking cart is empty or not.. if not empty
                      //if not empty
                      $("#cartCount").css('display','inline');
                      $("#cartCountText").text(result.count);

                  }else{
                      // if cart is empty
                      $("#cartCount").css('display','none');
                  }

                    // e.preventDefault();
                    
                  },//end of success function
                  error:function(result) {
                  	alert('error');
                  	console.log(result);

                  }
              });

       }

	   function wishListAddition(productId,e)
	   {
					event.preventDefault();
					var url = "{{ route('Favourite.Add') }}";
					var _token = '<?php echo csrf_token() ?>';
					// alert(url);
					// alert(_token);
					$.ajax({
						type: "post",
						url: url,
						data: {   
							id: productId,
							Quantity: 1,
							_token  :_token
						},
						success:function(result,e) {
							// alert(result.message+"and"+ result.count+"and"+ result.success );
							console.log(result);
							console.log(result.data);
							console.log(result.message);
							console.log(result.count);


							

								// e.preventDefault();
								
							},
							error:function(result) {
								alert('error');
								console.log(result);

							}
						});

        }


	   function product_display(products)
	     {
				$("#productList").empty();
				$( "#main" ).empty();
				if(products.length == 0){
					var $html = $("<h1>No Products to display</h1><br>");
					$( "#main" ).append( $html);
				}else{
					for (var product in products) {
						var url = "{{ route('Product.description', ':id') }}";
						url = url.replace(':id', products[product].Product_id);
						var carturl = "https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Shoplist-Ikea-rzk-version.svg";
						var likeurl = "https://abccontentbucket.s3.me-south-1.amazonaws.com/images/002-love.svg";
						var producturl =  "https://abccontentbucket.s3.me-south-1.amazonaws.com/images/:image') }}";
						producturl = producturl.replace(':image', products[product].MainImage);
						var $html = $("<div class='product-display-div'><div class='productlink-holding-div'><a href='"+ url +"' class='combocolorandavoidunderline w-inline-block'><div class='product-image-div'><img src='"+producturl+"' id='pro_pic"+products[product].Product_id+"' height='235' width='400'  data-w-id='437c5c3e-61c4-24a8-550f2bf0e3b35adc' alt='' class='product-image'></div><div class='product-name combocolor'>"+ products[product].product_name +"</div></a></div><div class='fav-cart'><div class='fav' onClick='wishListAddition(\""+ products[product].Product_id +"\",event)' ><img src='"+likeurl+"' width='22' height='22' alt='' class='favimage'><div class='like-text'>Like</div></div><div class='addtocartbutton' onClick='CartAddition(\""+ products[product].Product_id +"\",event)'><img src='"+carturl+"' width='19' height='19' alt='' class='cart-img'><div class='addtocarttext'>Add To Cart</div></div></div></div>");

						$( "#productList" ).append( $html);
					}
				}
         }
       function updateCategory(){
       						if(document.getElementsByName("category1").length != 0){ 
       						var selectedValues = "";
       				    // if($("#SelectedSUBCategories").val()!=""){
       				    // 	selectedValues = $("#SelectedSUBCategories").val()+","; 
						   // }
						//    if($(this).prop("checked") == false){
						// 		$(this).prop('checked', true);
            			// 	}else{
						// 		$(this).prop('checked', false);
						// 	}
       				    var checkboxes = document.getElementsByName("category1");
       				    var categories = [];
       				    for (var i=0; i<checkboxes.length; i++) {
						     // And stick the checked ones onto an array...
						     if (checkboxes[i].checked) {
						     	//alert(checkboxes[i].value);
						     	categories.push(checkboxes[i].value);

						       // alert(checkboxes[i].value);
						   }
						}

						if(categories.length==0){
							categories.push("ALL");
						}
						// selectedValues += categories;
						$("#SelectedSUBCategories").val(categories);
						
						 console.log($("#SelectedSUBCategories").val());
						// console.log($("#SelectedColours").val());
						// console.log($("#SelectedBrands").val());
					}
				} 
				function updateBrand(){
					if(document.getElementsByName("Brands1").length != 0){ 
						console.log("Inside updateBrand function");
						var selectedValues = "";
						
       				    
       				    var brandcheckboxes = document.getElementsByName("Brands1");
       				    var brands = [];
       				    for (var i=0; i<brandcheckboxes.length; i++) {
						     // And stick the checked ones onto an array...
						     if (brandcheckboxes[i].checked) {
						     	//alert(checkboxes[i].value);
						     	brands.push(brandcheckboxes[i].value);

						       // alert(checkboxes[i].value);
						    }
						}

						$("#SelectedBrands").val('');
						$("#SelectedBrands").val(brands);
						
						console.log($("#SelectedBrands").val());
					}
				}	
				function updateColour(){
					if(document.getElementsByName("colours1").length != 0){ 
						var selectedValues = "";
						
       				    var colourcheckboxes = document.getElementsByName("colours1");
       				    var colours = [];
       				    for (var i=0; i<colourcheckboxes.length; i++) {
						    
						     if (colourcheckboxes[i].checked) {
						     	
						     	colours.push(colourcheckboxes[i].value);

						      
						   }
						}
						$("#SelectedColours").val(colours);
						// console.log($("#SelectedSUBCategories").val());
						 console.log($("#SelectedColours").val());
						// console.log($("#SelectedBrands").val());
					}
				}
			function fetchDataBasedOnMobileFilter()
			{
					event.preventDefault();
					console.log("Hi inside filter function");
					var selBrands =[];
					var selColours =[];
					var categories =[];
					var min_price = 0;
					var max_price =6000;
					var str = $("#SelectedSUBCategories").val();
					var branddd = $("#SelectedBrands").val();
					var colourrr = $("#SelectedColours").val();
				    categories = str.split(",");
					selBrands = branddd.split(",");
					selColours = colourrr.split(",");
					var categorycount = categories.length;
					var colourCount = selColours.length;
					var brandCount = selBrands.length;
					
					min_price = $('#min_price1').val();
					max_price = $('#max_price1').val();
					console.log($("#SelectedSUBCategories").val());
					console.log($("#SelectedColours").val());
					console.log($("#SelectedBrands").val());
					if(colourCount == 1 && selColours[0] == "" ){
						colourCount =0;
					}
					if(brandCount == 1 && selBrands[0] == "" ){
						brandCount =0;
					}
					if(categorycount == 1 && categories[0] == "" ){

						categories[0]="ALL";
					}
					console.log(selBrands);
					console.log(selColours);

					console.log(categories);
					console.log($('#min_price1').val());
					console.log($('#max_price1').val());
					console.log("colourcount"+colourCount);
					console.log("brandCount"+brandCount);

					var url = "{{ route('Product.Fetch') }}";
					var _token = '<?php echo csrf_token() ?>';
							//alert(url);
							$.ajax(

							{
								type: "post",
								url: url,
								data: {   
									categories : categories,
									selectedCat : 'selected',
									selColours : selColours,
									selBrands  : selBrands,
									min_price : min_price,
									max_price : max_price,
									colourCount : colourCount,
									brandCount  : brandCount,
									_token  :_token
								},
								success:function(result,e) {
									console.log(result)


									console.log(url);

									console.log(result.products);
						      				// console.log(result.message);
						      				// console.log(result.Sub_Category_ID);
						      				// console.log(result.Category_ID);
						      				var products =result.products;
						      				console.log(products.length);
						      				product_display(products);

						      			},
						      			error:function(result) {
						      				alert('error');
						      				console.log(result);

						      			}
						    });
							console.log("Successfully executed");
							$("#MobileFilter").empty();
							// $("#apply").hide();
							// $("#resetButton").hide();


			}
			function reset(){
				$("#SelectedSUBCategories").val("");
				$("#SelectedBrands").val("");
				$("#SelectedColours").val("");
				$('#min_price1').val("0");
				$('#max_price1').val("6000");
				var categories =['ALL'];
				var selBrands=[];
				var selColours=[];
				var min_price=0;
				var max_price = 0;
				var colourCount =0;
				var brandCount = 0;
				var url = "{{ route('Product.Fetch') }}";
					var _token = '<?php echo csrf_token() ?>';
							//alert(url);
							$.ajax(

							{
								type: "post",
								url: url,
								data: {   
									categories : categories,
									selectedCat : 'selected',
									selColours : selColours,
									selBrands  : selBrands,
									min_price : min_price,
									max_price : max_price,
									colourCount : colourCount,
									brandCount  : brandCount,
									_token  :_token
								},
								success:function(result,e) {
									console.log(result)


									console.log(url);

									console.log(result.products);
						      				// console.log(result.message);
						      				// console.log(result.Sub_Category_ID);
						      				// console.log(result.Category_ID);
						      				var products =result.products;
						      				console.log(products.length);
						      				product_display(products);

						      			},
						      			error:function(result) {
						      				alert('error');
						      				console.log(result);

						      			}
						    });
							console.log("Successfully executed");
							$("#MobileFilter").empty();
							$("#apply").hide();
							$("#resetButton").hide();


			}
					</script>
					  <!-- <script src="https://d3e54v103j8qbb.cloudfront.net/js/jquery-3.5.1.min.dc5e7f18c8.js?site=5f103f7e5224a5353e5ce1c7" type="text/javascript" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script> -->
  <!-- <script src="{{asset('js/webflow.js')}}" type="text/javascript"></script> -->
  <!-- [if lte IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/placeholders/3.0.2/placeholders.min.js"></script><![endif] -->

	@include('Common.Footer')
</body>
</html>
