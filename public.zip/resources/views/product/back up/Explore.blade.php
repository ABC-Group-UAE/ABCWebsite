@extends('Layout.layout')
<style>
	.sf-rib-scroller {
		display: flex;
		width: 100%;
		align-items: center;
		height: 48px;
		min-height: 0;
		padding: 0;
		border-bottom: 2px solid #ddd;
		background-color: #fff;
		-ms-overflow-style: none;
	}
	.s-mobile-toolbar {
		min-height: 44px;
		padding-top: 6px;
		width: 100%;
		padding-bottom: 6px;
		background-color: #fff;
		border-bottom: 2px solid #ddd;
		transition: .2s linear;
	}
	.a-scroller-horizontal {
		overflow-y: hidden;
	}
	.a-scroller {
		width: 100%;
		height: 100%;
		overflow: auto;
		-webkit-overflow-scrolling: touch;
	}
	.ab-scroller {
		width: 10%;
		height: 100%;
		overflow: auto;
		-webkit-overflow-scrolling: touch;
	}
	* {
		-moz-box-sizing: border-box;
		/* -webkit-box-sizing: border-box; */
		/* box-sizing: border-box; */
	}

	.sf-rib-scroller::-webkit-scrollbar {
		display: none;
	}
	.sf-rib-scroller .sf-rib-element:first-child {
		padding-left: 8px;
	}
	.a-nowrap, .aok-nowrap {
		white-space: nowrap;
	}
	.a-section {
		margin-bottom: 1.3rem;
	}
	.a-spacing-none, .a-ws .a-ws-spacing-none {
		/* margin-bottom: 0!important; */
	}
	* {
		-moz-box-sizing: border-box;
		/* -webkit-box-sizing: border-box; */
		/* box-sizing: border-box; */
	}
	
	.scrolling-wrapper {
		overflow-x: scroll;
		overflow-y: hidden;
		white-space: nowrap;
		-webkit-overflow-scrolling: touch;

	}
	
	.card {
		display: inline-block;
		width:40%;
	}
	.button-3 {
		width:100%;
	}

	.button-3:small {
		border-top-style: solid;
		border-top-width: 1px;
		border-top-color: hsla(0, 2.52%, 7.15%, 1.00);
		border-right-style: solid;
		border-right-width: 1px;
		border-right-color: hsla(0, 2.52%, 7.15%, 1.00);
		border-bottom-style: solid;
		border-bottom-width: 1px;
		border-bottom-color: hsla(0, 2.52%, 7.15%, 1.00);
		border-left-style: solid;
		border-left-width: 1px;
		border-left-color: hsla(0, 2.52%, 7.15%, 1.00);
		border-top-left-radius: 14px;
		border-top-right-radius: 14px;
		border-bottom-left-radius: 14px;
		border-bottom-right-radius: 14px;
		background-color: @swatch_a30af6ce;
		color: hsla(0, 1.36%, 3.95%, 1.00);
	}

	.button-3:small_current {
		margin-top: 7px;
		margin-right: 20px;
		margin-left: 25px;
	}

	.button-3:tiny_current {
		margin-left: 0px;
	}

</style>


@section('content')
<script src="{{ asset('js/ranger.js') }}"></script>
<script src="{{ asset('js/jquery.min.js') }}"></script>
<script src="{{ asset('js/jquery-ui.min.js') }}"></script>
<link href="{{ asset('extra_css/ranger.css') }}" rel="stylesheet">
<link href="{{ asset('extra_css/jquery-ui.css') }}" rel="stylesheet">


<?php
use App\Category;
?>

<?php
$SelectedCategory='ALL';
$SelectedSubCategory='ALL';
$SelectedSubSubCategory='ALL';
$categorycolor ="black";
if(!empty($selectedCatValue)){
	$SelectedCategory = $selectedCatValue;
}
if(!empty($selectedSubCatValue)){
	$SelectedSubCategory = $selectedSubCatValue;
}
if(!empty($selectedSubSubCatValue)){
	$SelectedSubSubCategory = $selectedSubSubCatValue;
}

?>
<form action="{{ route('Explore')}}" method="" id="Explore">
	{{csrf_field()}}
	<input type="hidden" id="selCategory" name="selCategory" value="{{$SelectedCategory}}">
	<input type="hidden" id="selSubCategory" name="selSubCategory" value="{{$SelectedSubCategory}}">
	<input type="hidden" id="selSubSubCategory" name="selSubSubCategory" value="{{$SelectedSubSubCategory}}">
	<input type="hidden" id="SelectedSUBCategories" name="SelectedSUBCategories" value="">
	<input type="hidden" id="SelectedBrands" name="SelectedBrands" value="">
	<input type="hidden" id="SelectedColours" name="SelectedColours" value="">
	<input type="hidden" id="min_price1" name="min_price1" value="">
	<input type="hidden" id="max_price1" name="max_price1" value="">

	<div>
		<div class="product-container w-container " >
			
			
			<div class="mobile-filter-div">
				<div class="scrolling-wrapper">
					@if( !($Categories->isEmpty()))
					<select onchange="MobileFiltering('','Category',event)" id="selectionCat">
						<option value="" >--Select Category --</option>
						@foreach($Categories as $Category)
						<option value="{{$Category->Category_ID}}" @php if(isset($SelectedCategory)) { 
            if(strcmp($SelectedCategory ,$Category->Category_ID) == 0) 
            { echo "selected=true"; }}@endphp > {{$Category->Category_Name}}</option>

						
						@endforeach
					</select>
					@endif
					
					<div class="card">
						<button class="button-3" onClick="MobileFiltering('','Price',event)">price</button>
					</div>
					<div class="card">
						<button class="button-3" onClick="MobileFiltering('','Brand',event)">Brand</button>
					</div>
					<div class="card">
						<button class="button-3" onClick="MobileFiltering('','Colour',event)">Colour</button>
					</div>

				</div>
				<form id="mobileForm">
					{{csrf_field()}}
					<div class="subcategory-listing-div" id="MobileFilter">
						
						


					</div>
					<button onclick ="fetchDataBasedOnMobileFilter()" id="apply" style="display: none;" >Apply</button>
				</form>
				
				
			</div>
			<div class="desktop-filter-div">
				<div class="filter-section-div">
					<h3 class="filter-main-heading">Our Products</h3>
					<a href="#" onClick="fetchData('ALL')" aria-current="page" class="category-link w--current">All Products</a>

					@if( !($Categories->isEmpty()))  <!-- all category listing div  checking categories exist-->

					@foreach($Categories as $Category)<!-- category iterating loop   -->
					<div class="category-listing-div w-clearfix" >
						<a href="#"  onClick="fetchData('{{$Category->Category_ID}}')" aria-current="page" class="category-link w--current" id="{{$Category->Category_ID}}">{{$Category->Category_Name}}</a>

						@if($SelectedCategory == $Category->Category_ID)<!-- checking if selected category === this category -->
						<?php
						$categorycolor ="red";
				// if($Selected == $Category->Category_ID){
						$subCategories = Category::find($Category->Category_ID)->SubCategories;
				// $subCategories = $Categories->SubCategories;
				//dd($subCategories);
				//style="font-style:{{($SelectedCategory == $Category->Category_ID) ? 'red' : '' }} "
						?>

						@if( !($subCategories->isEmpty())) <!-- checking if sub category list empty -->


						@foreach($subCategories as $subCategory) <!-- looping sub categories -->
						<?php
				// if($Selected == $Category->Category_ID){
						$subSubCategories = $subCategory->SubSubCategories($subCategory->Category_ID,$subCategory->Sub_Category_ID);
				// $subCategories = $Categories->SubCategories;
				//dd($subCategory->Category_ID);
				//dd ($subCategory->Sub_Category_ID); 
				//dd($subSubCategories);
						?>
						@if($SelectedCategory == $subCategory->Category_ID)
						<div  style="margin-left: 10%;">
							<div style="display:flex"><input type="checkbox" @php if(isset($selectedSubCatValue)) { 
            if(strcmp($selectedSubCatValue ,$subCategory->Sub_Category_ID) == 0) 
            { echo "checked=checked"; }}@endphp name="category"  id="{{$subCategory->Category_ID}}-{{$subCategory->Sub_Category_ID}}" value="{{$subCategory->Category_ID}}-{{$subCategory->Sub_Category_ID}}" onChange="fetchDataBasedOnFilter('checkbox')" ><a  aria-current="page" class="category-link w--current">{{$subCategory->Sub_Category_Name}}</a></div>
							<!-- name="{{$subCategory->Category_ID}}-{{$subCategory->Sub_Category_ID}}" -->
							<!-- onClick="fetchDataCategory('{{$subCategory->Category_ID}}','{{$subCategory->Sub_Category_ID}}',{{$subCategories}})" -->

							@if( !($subSubCategories->isEmpty()))  <!-- checking if sub sub category list empty -->

							<div style="margin-left: 10%">
								@foreach($subSubCategories as $subSubCategory) <!-- looping sub sub categories -->

								<div style="display:flex"><input type="checkbox" @php if(isset($selectedSubSubCatValue) && isset($selectedSubCatValue)) { 
            if((strcmp($selectedSubSubCatValue ,$subSubCategory->Sub_Sub_Category_ID) == 0) && (strcmp($selectedSubCatValue ,$subCategory->Sub_Category_ID) == 0)) 
            { echo "checked=checked"; }}@endphp name="category" value="{{$subSubCategory->Category_ID}}-{{$subSubCategory->Sub_Category_ID}}-{{$subSubCategory->Sub_Sub_Category_ID}}" id="{{$subSubCategory->Category_ID}}-{{$subSubCategory->Sub_Category_ID}}-{{$subSubCategory->Sub_Sub_Category_ID}}" onChange="fetchDataBasedOnFilter('checkbox')" ><a  aria-current="page" class="category-link w--current">{{$subSubCategory->Sub_Sub_Category_Name}}</a></div>
								<!-- name="{{$subSubCategory->Category_ID}}-{{$subSubCategory->Sub_Category_ID}}-{{$subSubCategory->Sub_Sub_Category_ID}}" -->
								<!--  onClick="fetchDataSubCategory('{{$subSubCategory->Category_ID}}','{{$subSubCategory->Sub_Category_ID}}','{{$subSubCategory->Sub_Sub_Category_ID}}',{{$subSubCategories}})" --> 
								@endforeach <!--end of  looping sub sub categories -->
							</div> 

							@endif  <!-- end of if sub sub category list empty -->
						</div>
						@endif 
						@endforeach  <!-- end of looping sub categories -->
						@endif  <!--  close checking if sub category list empty -->

						@endif <!--  close of if selected category === this category -->

					</div>
					@endforeach <!-- end of vategory iterating loop -->
					@endif  <!-- all category listing div  close of category exist checking if -->

				</div>
				<div class="filter-section-div">
					<h3 class="filter-main-heading">Price Range</h3>
					<div>Select your Price Range:</div>
					<div id="slider-min" class="price-ranger" style="display:block">
						<!-- my price ranger code -->
						<div id="slider-range" class="price-filter-range" name="rangeInput">
						</div>  
						<input type="number" min=0 max="5900" oninput="validity.valid||(value='0');" id="min_price" class="price-range-field" />
						<input type="number" min=0 max="6000" oninput="validity.valid||(value='6000');" id="max_price" class="price-range-field" />
						<br>
						<div>
							<button class="price-range-search" id="price-range-submit" onClick="fetchDataBasedOnFilter('Button')">Search</button>
						</div>



						<div id="searchResults" class="search-results-block" ></div>

						<!-- end of price ranger code -->


					</div>

				</div>
				<div class="filter-section-div">
					<h3 class="filter-main-heading">Colour</h3>
					<!-- class="colour-filter-div" -->
					<?php
					$i=1;
					?>
					<div  >
						@if( (sizeof($colours)>0)) 
						@foreach($colours as $colouritem)
						<?php
						$i++;
						if($i%2 == 0){
					// echo ($i%2);

							?>
							<center><div class="brand-filter-div">

								<?php		
							}
							?>
							<div ><input type="checkbox" name="colours" value="{{$colouritem->colour}}" onChange="fetchDataBasedOnFilter('checkbox')">{{$colouritem->colour}} </div>

							<?php

							if($i%2 != 0){
								?>

							</div></center>
							<?php

						}
						?>
						@endforeach
						@endif

					</div>
				</div>
				<div class="filter-section-div">
					<h3 class="filter-main-heading">Our Brands</h3>
					@if( (sizeof($Brands)>0))
					@foreach($Brands as $Branditem)
					<div class="brand-filter-div"><input type="checkbox"  @php if(isset($selectedBrand)) { 

            if((strcmp($selectedBrand ,strtolower($Branditem->Brand_Name)) == 0)) 
            { echo "checked=checked"; }}@endphp name="Brands" value="{{$Branditem->Brand_Name}}" onChange="fetchDataBasedOnFilter('checkbox')">{{$Branditem->Brand_Name}}</div>
					@endforeach
					@endif

				</div>
			</div>

			@if( !($products->isEmpty()))
			<div class="w-layout-grid product-display-grid"  id ="productList">
				@foreach($products as $product)
				<div class="product-display-div">
					<div class="productlink-holding-div">
						<a href="{{ route('Product.description', $product->Product_id) }}" class="combocolorandavoidunderline w-inline-block">
							<div class="product-image-div"><img height="235" width="400" src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/{{$product->MainImage)}}" data-w-id="437c5c3e-61c4-24a8-550f-2bf0e3b35adc" alt="" class="product-image"></div>
							<div class="product-name combocolor">{{$product->product_name}}</div>
						</a>
					</div>
					<div class="fav-cart">
						<div class="fav" onClick=" return wishListAddition('{{$product->Product_id}}',event)" ><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/002-love.svg" width="22" height="22" alt="" class="favimage">
							<div class="like-text">Like</div>
						</div>
						<div class="addtocartbutton" onClick=" return CartAddition('{{$product->Product_id}}',event)"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Shoplist-Ikea-rzk-version.svg" width="19" height="19" alt="" class="cart-img">
							<div class="addtocarttext">Add To Cart</div>
						</div>
					</div>
				</div>
				@endforeach
			</div>

			@else
			<h1>No Products to display </h1>
			@endif
			<div id="main"></div>
		</div>

	</div>
</form>


<script>
	// function MobileFiltering(selectedVal,Type,event){
	// 		event.preventDefault();
	// 		$("#MobileFilter").empty();
	// 		var CatID ="";
	// 		if(selectedVal == ""){
	// 			CatID = $("#selectionCat option:selected").val();
	// 		}else{
	// 			CatID = selectedVal;
	// 		}
	// 		if(Type =="Price")
	// 		{
	// 			console.log("Inside Price selection");
	// 			var priceDiv =	"<div class='jsx-304923497 inputWrapper'><input type='number' name='min' id='min_price2' aria-label='min' class='jsx-304923497 textInput' value='0' onChange='updatePrice()'><span class='jsx-304923497 between'>To</span><input type='number' name='max' id='max_price2' aria-label='max' class='jsx-304923497 textInput' value='6000' onChange='updatePrice()'></div>";
	// 			$("#MobileFilter").append(priceDiv);

	// 		}


	// 		var url = "{{ route('Categories.Fetch') }}";
	// 		var _token = '<?php echo csrf_token() ?>';
	// 		$.ajax(
	// 		{
	// 					type: "get",
	// 					url: url,
	// 					data: {   

	// 						selectedCat : CatID,
	// 						Type:Type,
	// 						_token  :_token
	// 					},
	// 					success:function(result,e){

	// 									console.log(result);
	// 									console.log(url);
	// 									if(result.Type == "Category"){
	// 										if(result.subCategories.length != 0){
	// 											var subCategories = result.subCategories;
	// 											var categoryName="";
	// 											switch(subCategories[0].Category_ID){
	// 												case 'C': categoryName = "Ceramics"; break;
	// 												case 'S': categoryName = "SanitaryWares"; break;
	// 												case 'A': categoryName = "Allied"; break;
	// 												case 'Z': categoryName = "Accessories"; break;
	// 												case 'K': categoryName = "Kitchen"; break;
	// 												case 'M': categoryName = "Mixers"; break;
	// 											}
	// 											$("#MobileFilter").append("<div>"+categoryName+"</div>");
	// 										}
	// 										for( var subcat in subCategories){
	// 											var subsubcategories = subCategories[subcat].SubsubCat;
	// 											console.log(subsubcategories);
	// 											var html ="";
	// 											if(subsubcategories.length > 0){
	// 												html = "<div  style='margin-left: 10%;'>";
	// 												for(var subsubcat in subsubcategories){
	// 													html += "<div style='display:flex'><input type='checkbox' name='category' value='"+subsubcategories[subsubcat].Category_ID+"-"+subsubcategories[subsubcat].Sub_Category_ID+"-"+subsubcategories[subsubcat].Sub_Sub_Category_ID +"' id='"+subsubcategories[subsubcat].Category_ID+"-"+subsubcategories[subsubcat].Sub_Category_ID+"-"+subsubcategories[subsubcat].Sub_Sub_Category_ID +"'onChange='updateCategory()'  ><a  aria-current='page' class='category-link w--current'>"+subsubcategories[subsubcat].Sub_Sub_Category_Name+"</a></div>";
	// 												}
	// 												html +="</div>";
	// 											}
	// 											var CategoryDiv = "<div id='"+subCategories[subcat].Category_ID+"-"+subCategories[subcat].Sub_Category_ID+"'  style='margin-left: 10%;'><div style='display:flex'><input type='checkbox' name='category'  id='"+subCategories[subcat].Category_ID+"-"+subCategories[subcat].Sub_Category_ID +"' value='"+subCategories[subcat].Category_ID+"-"+subCategories[subcat].Sub_Category_ID+"' onChange='updateCategory()' ><a  aria-current='page' class='category-link w--current'>"+subCategories[subcat].Sub_Category_Name+"</a></div></div>";
	// 											$("#MobileFilter").append(CategoryDiv);
	// 											$("#"+subCategories[subcat].Category_ID+"-"+subCategories[subcat].Sub_Category_ID).append(html);

	// 										}
	// 										console.log($("#SelectedSUBCategories").val());
	// 										console.log($("#SelectedColours").val());
	// 										console.log($("#SelectedBrands").val());
	// 				//////////////////////////////

	// 										var category = $("#SelectedSUBCategories").val();
	// 										var categoriess = category.split(",");
	// 										if(categoriess.length > 1 ){
	// 														var categoryCheckboxes = document.getElementsByName("category");
	// 														for(var cat in categoriess){
	// 																for (var i=0; i<categoryCheckboxes.length; i++) {
											     
	// 										     							console.log("catogoryvalue"+categoryCheckboxes[i].value);
	// 										     							if (categoryCheckboxes[i].value == categoriess[cat]) {
														     	
	// 													     						categoryCheckboxes[i].checked = true;
														     	
	// 													     				}
	// 																}
	// 													}
														
	// 										}else if(categoriess.length == 1 && categoriess[0] != ""){
	// 													var categoryCheckboxes = document.getElementsByName("category");
	// 													for(var cat in categoriess){ 
	// 														    for (var i=0; i<categoryCheckboxes.length; i++) {	
											     
	// 										     						if (categoryCheckboxes[i].value == categoriess[cat]){
														     	
	// 													     						categoryCheckboxes[i].checked = true;
														     	
	// 													     			}
	// 													 		}
	// 													}
	// 										}
	// 										console.log($("#SelectedSUBCategories").val());
	// 										console.log($("#SelectedColours").val());
	// 										console.log($("#SelectedBrands").val());




	// 				/////////////////////////////////





	// 									}else if(result.Type=="Colour"){
	// 										console.log(result.Type);
	// 										var colourDiv ="<div class='filter-section-div'><h3 class='filter-main-heading'>Colour</h3><div>";
	// 										var colours = result.Colours;
	// 										var i=0;
	// 										console.log(colours);
	// 										if( result.Colours.length>0) {
	// 											for(var colour in  colours){
	// 												i++;
	// 												if(i%2 != 0){
	// 													colourDiv+= "<center><div class='brand-filter-div'>";
	// 												}
	// 												colourDiv+="<div ><input type='checkbox' name='colours' value="+colours[colour].colour+" onChange='updateColour()' >"+colours[colour].colour +"</div>";
	// 												if(i%2 == 0){
	// 													colourDiv+="</div></center>";
	// 												}
	// 											}
	// 											colourDiv+="</div></div>";

	// 										}
	// 										$("#MobileFilter").append(colourDiv);

	// 										//////////////////////////////////////////////////////////////////////
	// 										console.log($("#SelectedColours").val());
	// 										var coloursss = $("#SelectedColours").val();
	// 										var colours = coloursss.split(",");
	// 										if(colours.length > 1 ){
	// 												var coloursCheckboxes = document.getElementsByName("colours");
	// 												for(var cat in colours){
	// 														for (var i=0; i<coloursCheckboxes.length; i++) {
	// 																console.log("catogoryvalue"+coloursCheckboxes[i].value);
	// 																if (coloursCheckboxes[i].value == colours[cat]) {
	// 																		coloursCheckboxes[i].checked = true;

	// 																}


	// 														}

	// 												}
	// 										}else if(colours.length == 1 && colours[0] != ""){
	// 													var coloursCheckboxes = document.getElementsByName("colours");
	// 													for(var cat in colours){
	// 															for (var i=0; i<coloursCheckboxes.length; i++) {
	// 																	if (coloursCheckboxes[i].value == colours[cat]) {
	// 																			coloursCheckboxes[i].checked = true;
	// 																	}
	// 															}

	// 													}


	// 										}
												
												
											


	// 										///////////////////////////////////////////////////////////////////////
	// 									}else if(result.Type=="Brand"){
	// 										var Brands = result.Brands;
	// 										var brandDiv ="<div class='filter-section-div'><h3 class='filter-main-heading'>Our Brands</h3>";
	// 										if(result.Brands.length>0){
	// 											for(var brand in Brands){
	// 												brandDiv+="<div class='brand-filter-div'><input type='checkbox' name='Brands'  value="+ Brands[brand].Brand_Name+" onChange='updateBrand()'>"+Brands[brand].Brand_Name+"</div>";
	// 											}
	// 										}
	// 										brandDiv+="</div>";
	// 										$("#MobileFilter").append(brandDiv);
	// 										////////////////////////////////////////////////////////////////
	// 										var brandsss = $("#SelectedBrands").val();
	// 								    	var brands = brandsss.split(",");
	// 								     	if(brands.length > 1 ){
	// 								     			var brandCheckboxes = document.getElementsByName("Brands");
	// 								     			for(var cat in brands){
	// 								     					for (var i=0; i<brandCheckboxes.length; i++) {
	// 								     						console.log("catogoryvalue"+brandCheckboxes[i].value);
	// 								     						if (brandCheckboxes[i].value == brands[cat]) {
	// 								     								brandCheckboxes[i].checked = true;
	// 								     						}
	// 								     					}

	// 								     			}


	// 								     	}else if(brands.length == 1 && brands[0] != ""){
	// 								     			var brandCheckboxes = document.getElementsByName("Brands");
	// 								     			for(var cat in brands){
	// 								     					for (var i=0; i<brandCheckboxes.length; i++) {
	// 								     								if (brandCheckboxes[i].value == brands[cat]) {
	// 								     									brandCheckboxes[i].checked = true;
	// 								     								}

	// 								     					}

	// 								     			}

	// 								     	}

									    

	// 										//////////////////////////////////////////////////////////////////

	// 									}

	// 					}



	// 		});
	// 		$("#apply").show();


	// }

	function MobileFiltering(selectedVal,Type,event){
			event.preventDefault();
			$("#MobileFilter").empty();
			var CatID ="";
			if(selectedVal == ""){
				CatID = $("#selectionCat option:selected").val();
			}else{
				CatID = selectedVal;
			}
			if(Type =="Price")
			{
				console.log("Inside Price selection");
				var priceDiv =	"<div class='jsx-304923497 inputWrapper'><input type='number' name='min' id='min_price2' aria-label='min' class='jsx-304923497 textInput' value='0' onChange='updatePrice()'><span class='jsx-304923497 between'>To</span><input type='number' name='max' id='max_price2' aria-label='max' class='jsx-304923497 textInput' value='6000' onChange='updatePrice()'></div>";
				$("#MobileFilter").append(priceDiv);

			}


			var url = "{{ route('Categories.Fetch') }}";
			url = url.replace("http", "https");
			var _token = '<?php echo csrf_token() ?>';
			//alert(url);
			$.ajax(
			{
				type: "get",
				url: url,
				data: {   

					selectedCat : CatID,
					Type:Type,
					_token  :_token
				},
				success:function(result,e){
					console.log(result);
					console.log(url);
					if(result.Type == "Category"){
						if(result.subCategories.length != 0){
							var subCategories = result.subCategories;
							var categoryName="";
							switch(subCategories[0].Category_ID){
								case 'C': categoryName = "Ceramics"; break;
								case 'S': categoryName = "SanitaryWares"; break;
								case 'A': categoryName = "Allied"; break;
								case 'Z': categoryName = "Accessories"; break;
								case 'K': categoryName = "Kitchen"; break;
								case 'M': categoryName = "Mixers"; break;
							}
							$("#MobileFilter").append("<div>"+categoryName+"</div>");
						}
						for( var subcat in subCategories){
							var subsubcategories = subCategories[subcat].SubsubCat;
							console.log(subsubcategories);
							var html ="";
							if(subsubcategories.length > 0){
								html = "<div  style='margin-left: 10%;'>";
								for(var subsubcat in subsubcategories){
									html += "<div style='display:flex'><input type='checkbox' name='category' value='"+subsubcategories[subsubcat].Category_ID+"-"+subsubcategories[subsubcat].Sub_Category_ID+"-"+subsubcategories[subsubcat].Sub_Sub_Category_ID +"' id='"+subsubcategories[subsubcat].Category_ID+"-"+subsubcategories[subsubcat].Sub_Category_ID+"-"+subsubcategories[subsubcat].Sub_Sub_Category_ID +"'onChange='updateCategory()'  ><a  aria-current='page' class='category-link w--current'>"+subsubcategories[subsubcat].Sub_Sub_Category_Name+"</a></div>";
								}
								html +="</div>";
							}
							var CategoryDiv = "<div id='"+subCategories[subcat].Category_ID+"-"+subCategories[subcat].Sub_Category_ID+"'  style='margin-left: 10%;'><div style='display:flex'><input type='checkbox' name='category'  id='"+subCategories[subcat].Category_ID+"-"+subCategories[subcat].Sub_Category_ID +"' value='"+subCategories[subcat].Category_ID+"-"+subCategories[subcat].Sub_Category_ID+"' onChange='updateCategory()' ><a  aria-current='page' class='category-link w--current'>"+subCategories[subcat].Sub_Category_Name+"</a></div></div>";
							$("#MobileFilter").append(CategoryDiv);
							$("#"+subCategories[subcat].Category_ID+"-"+subCategories[subcat].Sub_Category_ID).append(html);

						}
						console.log($("#SelectedSUBCategories").val());
						console.log($("#SelectedColours").val());
						console.log($("#SelectedBrands").val());
						//////////////////////////////

						var category = $("#SelectedSUBCategories").val();
						checkboxchecking('category',category);
						// var categoriess = category.split(",");
						// if(categoriess.length > 1 ){
						// 				var categoryCheckboxes = document.getElementsByName("category");
						// 				for(var cat in categoriess){
						// 						for (var i=0; i<categoryCheckboxes.length; i++) {
						     
						//      							console.log("catogoryvalue"+categoryCheckboxes[i].value);
						//      							if (categoryCheckboxes[i].value == categoriess[cat]) {
									     	
						// 			     						categoryCheckboxes[i].checked = true;
									     	
						// 			     				}
						// 						}
						// 			}
									
						// }else if(categoriess.length == 1 && categoriess[0] != ""){
						// 			var categoryCheckboxes = document.getElementsByName("category");
						// 			for(var cat in categoriess){ 
						// 				    for (var i=0; i<categoryCheckboxes.length; i++) {	
						     
						//      						if (categoryCheckboxes[i].value == categoriess[cat]){
									     	
						// 			     						categoryCheckboxes[i].checked = true;
									     	
						// 			     			}
						// 			 		}
						// 			}
						// }
						console.log($("#SelectedSUBCategories").val());
						console.log($("#SelectedColours").val());
						console.log($("#SelectedBrands").val());




						/////////////////////////////////





					}else if(result.Type=="Colour"){
						console.log(result.Type);
						var colourDiv ="<div class='filter-section-div'><h3 class='filter-main-heading'>Colour</h3><div>";
						var colours = result.Colours;
						var i=0;
						console.log(colours);
						if( result.Colours.length>0) {
							for(var colour in  colours){
								i++;
								if(i%2 != 0){
									colourDiv+= "<center><div class='brand-filter-div'>";
								}
								colourDiv+="<div ><input type='checkbox' name='colours' value="+colours[colour].colour+" onChange='updateColour()' >"+colours[colour].colour +"</div>";
								if(i%2 == 0){
									colourDiv+="</div></center>";
								}
							}
							colourDiv+="</div></div>";

						}
						$("#MobileFilter").append(colourDiv);

						//////////////////////////////////////////////////////////////////////
						console.log($("#SelectedColours").val());
						var coloursss = $("#SelectedColours").val();
						checkboxchecking('colours',coloursss);
						// var colours = coloursss.split(",");
						// if(colours.length > 1 ){
						// 		var coloursCheckboxes = document.getElementsByName("colours");
						// 		for(var cat in colours){
						// 				for (var i=0; i<coloursCheckboxes.length; i++) {
						// 						console.log("catogoryvalue"+coloursCheckboxes[i].value);
						// 						if (coloursCheckboxes[i].value == colours[cat]) {
						// 								coloursCheckboxes[i].checked = true;

						// 						}


						// 				}

						// 		}
						// }else if(colours.length == 1 && colours[0] != ""){
						// 			var coloursCheckboxes = document.getElementsByName("colours");
						// 			for(var cat in colours){
						// 					for (var i=0; i<coloursCheckboxes.length; i++) {
						// 							if (coloursCheckboxes[i].value == colours[cat]) {
						// 									coloursCheckboxes[i].checked = true;
						// 							}
						// 					}

						// 			}


						// }
							
							
						


						///////////////////////////////////////////////////////////////////////
					}else if(result.Type=="Brand"){
						var Brands = result.Brands;
						var brandDiv ="<div class='filter-section-div'><h3 class='filter-main-heading'>Our Brands</h3>";
						if(result.Brands.length>0){
							for(var brand in Brands){
								brandDiv+="<div class='brand-filter-div'><input type='checkbox' name='Brands'  value="+ Brands[brand].Brand_Name+" onChange='updateBrand()'>"+Brands[brand].Brand_Name+"</div>";
							}
						}
						brandDiv+="</div>";
						$("#MobileFilter").append(brandDiv);
						////////////////////////////////////////////////////////////////
						var brandsss = $("#SelectedBrands").val();
						checkboxchecking('Brands',brandsss);
				    	// var brands = brandsss.split(",");
				     	// if(brands.length > 1 ){
				     	// 		var brandCheckboxes = document.getElementsByName("Brands");
				     	// 		for(var cat in brands){
				     	// 				for (var i=0; i<brandCheckboxes.length; i++) {
				     	// 					console.log("catogoryvalue"+brandCheckboxes[i].value);
				     	// 					if (brandCheckboxes[i].value == brands[cat]) {
				     	// 							brandCheckboxes[i].checked = true;
				     	// 					}
				     	// 				}

				     	// 		}


				     	// }else if(brands.length == 1 && brands[0] != ""){
				     	// 		var brandCheckboxes = document.getElementsByName("Brands");
				     	// 		for(var cat in brands){
				     	// 				for (var i=0; i<brandCheckboxes.length; i++) {
				     	// 							if (brandCheckboxes[i].value == brands[cat]) {
				     	// 								brandCheckboxes[i].checked = true;
				     	// 							}

				     	// 				}

				     	// 		}

				     	// }

				    

						//////////////////////////////////////////////////////////////////

					}






				},
				error:function(result) {
					alert('error');
					console.log(result);
				}

			});
			$("#apply").show();


		}

		function checkboxchecking(checkboxname,value){
			var values = value.split(",");
				     	if(values.length > 1 ){
				     			var Checkboxes = document.getElementsByName(checkboxname);
				     			for(var cat in values){
				     					for (var i=0; i<Checkboxes.length; i++) {
				     						console.log("value"+Checkboxes[i].value);
				     						if (Checkboxes[i].value == values[cat]) {
												Checkboxes[i].checked = true;
				     						}
				     					}

				     			}


				     	}else if(values.length == 1 && values[0] != ""){
				     			var Checkboxes = document.getElementsByName(checkboxname);
				     			for(var cat in values){
				     					for (var i=0; i<Checkboxes.length; i++) {
				     								if (Checkboxes[i].value == values[cat]) {
														Checkboxes[i].checked = true;
				     								}

				     					}

				     			}

				     	}
		}


		function fetchData(Selected){
			//alert($("#selCategory").val());
			if($("#selCategory").val() != "ALL"){
				var selCategory = $("#selCategory").val();
			}
			selCategory = selCategory
			$("#selCategory").val(Selected);
			//alert("Hi Inside Form submit function");
			
			//alert($("#selCategory").val());
			$("#Explore").submit();
		}
		
		
		function updatePrice(){
			var min_price = $('#min_price2').val();
			var max_price = $('#max_price2').val();

			$('#min_price1').val(min_price);
			$('#max_price1').val(max_price);
		}
		function fetchDataBasedOnFilter(type){


			event.preventDefault();
			//alert($("#selCategory").val());
			var selected = $("#selCategory").val();
			var checkboxes = document.getElementsByName("category");
			var categories = [];
			for (var i=0; i<checkboxes.length; i++) {
			     // And stick the checked ones onto an array...
			     if (checkboxes[i].checked) {
			     	//alert(checkboxes[i].value);
			     	categories.push(checkboxes[i].value);

			       // alert(checkboxes[i].value);
			   }
			}

			if(categories.length==0){
				categories.push("ALL");
			}
			 // alert(categories);
			 var colourcheckboxes = document.getElementsByName("colours");
			 var selColours = [];
			 for (var i=0; i<colourcheckboxes.length; i++) {
			     // And stick the checked ones onto an array...
			     if (colourcheckboxes[i].checked) {
			     	//alert(checkboxes[i].value);
			     	selColours.push(colourcheckboxes[i].value);

			       // alert(checkboxes[i].value);
			   }
			}
			  // if(selColours.length==0){
			  // 	selColours.push("ALL");
			  // }
			  var colourCount = selColours.length;
			 // alert(selColours.length);
			 // alert(selColours);
			 var brandcheckboxes = document.getElementsByName("Brands");
			 var selBrands = [];
			 for (var i=0; i<brandcheckboxes.length; i++) {
			     // And stick the checked ones onto an array...
			     if (brandcheckboxes[i].checked) {
			     	//alert(checkboxes[i].value);
			     	selBrands.push(brandcheckboxes[i].value);

			       // alert(checkboxes[i].value);
			   }
			}
			  // if(selBrands.length==0){
			  // 	selBrands.push("ALL");
			  // }
			  var brandCount = selBrands.length;
			 // alert(selBrands.length);
			 // alert(selBrands);
			 var min_price = $('#min_price').val();
			 var max_price = $('#max_price').val();

			 var url = "{{ route('Product.Fetch') }}";
			 url = url.replace("http", "https");
			 var _token = '<?php echo csrf_token() ?>';
			//alert(url);
			$.ajax(

			{
				type: "post",
				url: url,
				data: {   
					categories:categories,
					selectedCat : selected,
					selColours : selColours,
					selBrands  :selBrands,
					min_price:min_price,
					max_price:max_price,
					colourCount : colourCount,
					brandCount  : brandCount,
					_token  :_token
				},
				success:function(result,e) {
					console.log(result)


					console.log(url);

					console.log(result.products);
		      				// console.log(result.message);
		      				// console.log(result.Sub_Category_ID);
		      				// console.log(result.Category_ID);
		      				var products =result.products;
		      				console.log(products.length);
		      				product_display(products);

		      			},
		      			error:function(result) {
		      				alert('error');
		      				console.log(result);

		      			}
		      		});

		}
		
		
		function CartAddition(productId,e){

			event.preventDefault();

          //alert(productId +" and "+fromValue);
          var url = "{{ route('Cart.Add') }}";
		  url = url.replace("http", "https");
          var _token = '<?php echo csrf_token() ?>';
           // alert(url);
           // alert(_token);
           $.ajax({
           	type: "post",
           	url: url,
           	data: {   
           		id: productId,
           		Quantity: 1,
           		_token  :_token
           	},
           	success:function(result,e) {
                   // alert(result.message+"and"+ result.count+"and"+ result.success );
                   console.log(result);
                   console.log(result.data);
                   console.log(result.message);
                   console.log(result.count);
                    if(result.count > 0){ //checking cart is empty or not.. if not empty
                      //if not empty
                      $("#cartCount").css('display','inline');
                      $("#cartCountText").text(result.count);

                  }else{
                      // if cart is empty
                      $("#cartCount").css('display','none');
                  }

                    // e.preventDefault();
                    
                  },//end of success function
                  error:function(result) {
                  	alert('error');
                  	console.log(result);

                  }
              });

       }

       function wishListAddition(productId,e){
       	event.preventDefault();
       	var url = "{{ route('Favourite.Add') }}";
		   url = url.replace("http", "https");
       	var _token = '<?php echo csrf_token() ?>';
           // alert(url);
           // alert(_token);
           $.ajax({
           	type: "post",
           	url: url,
           	data: {   
           		id: productId,
           		Quantity: 1,
           		_token  :_token
           	},
           	success:function(result,e) {
                   // alert(result.message+"and"+ result.count+"and"+ result.success );
                   console.log(result);
                   console.log(result.data);
                   console.log(result.message);
                   console.log(result.count);


                   

                    // e.preventDefault();
                    
                },
                error:function(result) {
                	alert('error');
                	console.log(result);

                }
            });

       }


       function product_display(products){
       	$("#productList").empty();
       	$( "#main" ).empty();
       	if(products.length == 0){
       		var $html = $("<h1>No Products to display</h1><br>");
       		$( "#main" ).append( $html);
       	}else{
       		for (var product in products) {
       			var url = "{{ route('Product.description', ':id') }}";
       			url = url.replace(':id', products[product].Product_id);
				   url = url.replace("http", "https");
       			var carturl = "https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Shoplist-Ikea-rzk-version.svg";
       			var likeurl = "https://abccontentbucket.s3.me-south-1.amazonaws.com/images/002-love.svg";
       			var producturl =  "https://abccontentbucket.s3.me-south-1.amazonaws.com/images/:image') }}";
       			producturl = producturl.replace(':image', products[product].MainImage);
       			var $html = $("<div class='product-display-div'><div class='productlink-holding-div'><a href='"+ url +"' class='combocolorandavoidunderline w-inline-block'><div class='product-image-div'><img src='"+producturl+"' id='pro_pic"+products[product].Product_id+"' height='235' width='400'  data-w-id='437c5c3e-61c4-24a8-550f2bf0e3b35adc' alt='' class='product-image'></div><div class='product-name combocolor'>"+ products[product].product_name +"</div></a></div><div class='fav-cart'><div class='fav' onClick='wishListAddition(\""+ products[product].Product_id +"\",event)' ><img src='"+likeurl+"' width='22' height='22' alt='' class='favimage'><div class='like-text'>Like</div></div><div class='addtocartbutton' onClick='CartAddition(\""+ products[product].Product_id +"\",event)'><img src='"+carturl+"' width='19' height='19' alt='' class='cart-img'><div class='addtocarttext'>Add To Cart</div></div></div></div>");

       			$( "#productList" ).append( $html);
       		}
       	}
       }
       function updateCategory(){
       	if(document.getElementsByName("category").length != 0){ 
       		var selectedValues = "";
       				    // if($("#SelectedSUBCategories").val()!=""){
       				    // 	selectedValues = $("#SelectedSUBCategories").val()+","; 
       				    // }
       				    var checkboxes = document.getElementsByName("category");
       				    var categories = [];
       				    for (var i=0; i<checkboxes.length; i++) {
						     // And stick the checked ones onto an array...
						     if (checkboxes[i].checked) {
						     	//alert(checkboxes[i].value);
						     	categories.push(checkboxes[i].value);

						       // alert(checkboxes[i].value);
						   }
						}

						if(categories.length==0){
							categories.push("ALL");
						}
						// selectedValues += categories;
						$("#SelectedSUBCategories").val(categories);
						
						// console.log($("#SelectedSUBCategories").val());
						// console.log($("#SelectedColours").val());
						// console.log($("#SelectedBrands").val());
					}
				} 
				function updateBrand(){
					if(document.getElementsByName("Brands").length != 0){ 
						console.log("Inside updateBrand function");
						var selectedValues = "";
       				    
       				    var brandcheckboxes = document.getElementsByName("Brands");
       				    var brands = [];
       				    for (var i=0; i<brandcheckboxes.length; i++) {
						     // And stick the checked ones onto an array...
						     if (brandcheckboxes[i].checked) {
						     	//alert(checkboxes[i].value);
						     	brands.push(brandcheckboxes[i].value);

						       // alert(checkboxes[i].value);
						   }
						}

						
						$("#SelectedBrands").val(brands);
						
						console.log($("#SelectedBrands").val());
					}
				}	
				function updateColour(){
					if(document.getElementsByName("colours").length != 0){ 
						var selectedValues = "";
       				    
       				    var colourcheckboxes = document.getElementsByName("colours");
       				    var colours = [];
       				    for (var i=0; i<colourcheckboxes.length; i++) {
						    
						     if (colourcheckboxes[i].checked) {
						     	
						     	colours.push(colourcheckboxes[i].value);

						      
						   }
						}
						$("#SelectedColours").val(colours);
						// console.log($("#SelectedSUBCategories").val());
						// console.log($("#SelectedColours").val());
						// console.log($("#SelectedBrands").val());
					}
				}
				function fetchDataBasedOnMobileFilter(){
					event.preventDefault();
					console.log("Hi inside filter function");

					var str = $("#SelectedSUBCategories").val();
					var branddd = $("#SelectedBrands").val();
					var colourrr = $("#SelectedColours").val();
					var categories = str.split(",");
					var selBrands = branddd.split(",");
					var selColours = colourrr.split(",");
					var categorycount = categories.length;
					var colourCount = selColours.length;
					var brandCount = selBrands.length;
					var min_price = $('#min_price1').val();
					var max_price = $('#max_price1').val();
					console.log($("#SelectedSUBCategories").val());
					console.log($("#SelectedColours").val());
					console.log($("#SelectedBrands").val());
					if(colourCount == 1 && selColours[0] == "" ){
						colourCount =0;
					}
					if(brandCount == 1 && selBrands[0] == "" ){
						brandCount =0;
					}
					if(categorycount == 1 && categories[0] == "" ){

						categories[0]="ALL";
					}
					console.log(selBrands);
					console.log(selColours);

					console.log(categories);
					console.log($('#min_price1').val());
					console.log($('#max_price1').val());
					console.log("colourcount"+colourCount);
					console.log("brandCount"+brandCount);

					var url = "{{ route('Product.Fetch') }}";
					url = url.replace("http", "https");
					var _token = '<?php echo csrf_token() ?>';
							//alert(url);
							$.ajax(

							{
								type: "post",
								url: url,
								data: {   
									categories:categories,
									selectedCat : 'selected',
									selColours : selColours,
									selBrands  :selBrands,
									min_price:min_price,
									max_price:max_price,
									colourCount : colourCount,
									brandCount  : brandCount,
									_token  :_token
								},
								success:function(result,e) {
									console.log(result)


									console.log(url);

									console.log(result.products);
						      				// console.log(result.message);
						      				// console.log(result.Sub_Category_ID);
						      				// console.log(result.Category_ID);
						      				var products =result.products;
						      				console.log(products.length);
						      				product_display(products);

						      			},
						      			error:function(result) {
						      				alert('error');
						      				console.log(result);

						      			}
						      		});
							console.log("Successfully executed");
							$("#MobileFilter").empty();
							$("#apply").hide();


						}
					</script>
					@endsection
