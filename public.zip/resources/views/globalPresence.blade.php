@extends('Layout.layout')
@section('content')
<div class="global-presenceimage-section"></div>
  <div class="all-page-red-section w-clearfix">
    <div class="redsectioncontentdiv">
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat. Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc ut sem vitae risus tristique posuere.</p>
      <a href="#global-presence-div" class="know-more-link-block combotypocolour w-inline-block">
        <div class="buttonclass-knowmore combotypographycolor">
          <h3 class="know-more-heading">Know More</h3>
        </div>
      </a>
    </div>
  </div>
  <div id="global-presence-div" class="herosection">
    <h2 class="headinginnerpages">Our Footprints Over The World</h2>
    <div class="regularcontainer w-container">
      <div class="w-layout-grid global-presence-list">
        <div><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/tanzania.png" loading="lazy" width="259" height="259" alt="" class="showroom-img">
          <div class="reddividerdiv"></div>
          <h1 class="name-heading">Country</h1>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat. Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc ut sem vitae risus tristique posuere.</p><a href="#" class="website-link">website</a>
          <div>This is some text inside of a div block.</div>
          <div>This is some text inside of a div block.</div>
        </div>
        <div><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/oman-2.png" loading="lazy" width="259" height="259" alt="" class="showroom-img">
          <div class="reddividerdiv"></div>
          <h1 class="name-heading">Country</h1>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat. Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc ut sem vitae risus tristique posuere.</p><a href="#" class="website-link">website</a>
          <div>This is some text inside of a div block.</div>
          <div>This is some text inside of a div block.</div>
        </div>
        <div><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/india.png" loading="lazy" width="259" height="259" alt="" class="showroom-img">
          <div class="reddividerdiv"></div>
          <h1 class="name-heading">Country</h1>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat. Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc ut sem vitae risus tristique posuere.</p><a href="#" class="website-link">website</a>
          <div>This is some text inside of a div block.</div>
          <div>This is some text inside of a div block.</div>
        </div>
        <div><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/rwanda.jpeg" loading="lazy" width="259" height="259" srcset="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/rwanda-p-500.jpeg 500w, https://abccontentbucket.s3.me-south-1.amazonaws.com/images/rwanda.jpeg 1080w" sizes="(max-width: 479px) 93vw, (max-width: 767px) 38vw, (max-width: 991px) 26vw, (max-width: 1439px) 24vw, 259px" alt="" class="showroom-img">
          <div class="reddividerdiv"></div>
          <h1 class="name-heading">Country</h1>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat. Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc ut sem vitae risus tristique posuere.</p><a href="#" class="website-link">website</a>
          <div>This is some text inside of a div block.</div>
          <div>This is some text inside of a div block.</div>
        </div>
        <div><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/QATAR.jpg" loading="lazy" width="259" height="259" srcset="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/QATAR-p-500.jpeg 500w, https://abccontentbucket.s3.me-south-1.amazonaws.com/images/QATAR-p-1080.jpeg 1080w, https://abccontentbucket.s3.me-south-1.amazonaws.com/images/QATAR-p-1600.jpeg 1600w, https://abccontentbucket.s3.me-south-1.amazonaws.com/images/QATAR-p-2000.jpeg 2000w, https://abccontentbucket.s3.me-south-1.amazonaws.com/images/QATAR-p-2600.jpeg 2600w, https://abccontentbucket.s3.me-south-1.amazonaws.com/images/QATAR-p-3200.jpeg 3200w, https://abccontentbucket.s3.me-south-1.amazonaws.com/images/QATAR.jpg 4032w" sizes="(max-width: 479px) 93vw, (max-width: 767px) 38vw, (max-width: 991px) 26vw, (max-width: 1439px) 24vw, 259px" alt="" class="showroom-img">
          <div class="reddividerdiv"></div>
          <h1 class="name-heading">Country</h1>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat. Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc ut sem vitae risus tristique posuere.</p><a href="#" class="website-link">website</a>
          <div>This is some text inside of a div block.</div>
          <div>This is some text inside of a div block.</div>
        </div>
        <div><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/india-2.png" loading="lazy" width="259" height="259" alt="" class="showroom-img">
          <div class="reddividerdiv"></div>
          <h1 class="name-heading">Country</h1>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat. Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc ut sem vitae risus tristique posuere.</p><a href="#" class="website-link">website</a>
          <div>This is some text inside of a div block.</div>
          <div>This is some text inside of a div block.</div>
        </div>
      </div>
    </div>
  </div>
  @endsection