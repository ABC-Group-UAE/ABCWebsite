<!DOCTYPE html>
<!--  This site was created in Webflow. http://www.webflow.com  -->
<!--  Last Published: Sun Sep 13 2020 06:17:07 GMT+0000 (Coordinated Universal Time)  -->
<html data-wf-page="5f152e10d13f492ef1b162d0" data-wf-site="5f103f7e5224a5353e5ce1c7">
<head>
  <meta charset="utf-8">
  <title>team</title>
  <meta content="team" property="og:title">
  <meta content="team" property="twitter:title">
  <meta content="width=device-width, initial-scale=1" name="viewport">
  <meta content="Webflow" name="generator">
  <link href="css/normalize.css" rel="stylesheet" type="text/css">
  <link href="css/webflow.css" rel="stylesheet" type="text/css">
  <link href="css/abcgroupuae.webflow.css" rel="stylesheet" type="text/css">
  <!-- [if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.min.js" type="text/javascript"></script><![endif] -->
  <script type="text/javascript">!function(o,c){var n=c.documentElement,t=" w-mod-";n.className+=t+"js",("ontouchstart"in o||o.DocumentTouch&&c instanceof DocumentTouch)&&(n.className+=t+"touch")}(window,document);</script>
  <link href="images/favicon.ico" rel="shortcut icon" type="image/x-icon">
  <link href="images/webclip.png" rel="apple-touch-icon">
</head>
<body class="body">
  <div class="modal-wrapper">
    <div class="form-wrapper w-clearfix"><a href="index.html" aria-current="page" class="link-7 w--current">X </a>
      <h2 class="heading-4 headinginnerpages">Have a chat with us</h2>
      <div class="w-form">
        <form id="email-form-4" name="email-form-4" data-name="Email Form 4" method="get"><input type="text" class="w-input" autofocus="true" maxlength="256" name="name" data-name="Name" placeholder="Enter Your name" id="name"><input type="email" class="w-input" autofocus="true" maxlength="256" name="email" data-name="Email" placeholder="Enter your mail id" id="email" required=""><input type="tel" class="w-input" autofocus="true" maxlength="256" name="PhNo" data-name="PhNo" placeholder="Enter Your mobile number" id="PhNo" required=""><input type="text" class="w-input" autofocus="true" maxlength="256" name="TypeofEnquiry" data-name="TypeofEnquiry" placeholder="Enter type of enquiry here" id="TypeofEnquiry" required=""><textarea data-name="message" maxlength="5000" id="message" name="message" placeholder="type any message here" autofocus="true" class="textarea w-input"></textarea><input type="submit" value="Submit" data-wait="Please wait..." class="btnclass borderclass w-button"></form>
        <div class="w-form-done">
          <div>Thank you! Your submission has been received!</div>
        </div>
        <div class="w-form-fail">
          <div>Oops! Something went wrong while submitting the form.</div>
        </div>
      </div>
    </div>
  </div>
  <div id="header" class="headersection">
    <div class="myheadercontainer w-container">
      <div class="mygreyheaderdiv">
        <div class="div-block-19">
          <div class="div-block-18"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/001-email.svg" width="20" height="17" alt="" class="image-19"><a href="mailto:info@abcgroupuae.com?subject=Enquiry" class="link-4">info@abcmercantile.ae</a></div>
          <div class="w-layout-grid grid-3"><a href="#" class="w-inline-block"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/002-facebook.svg" height="17" alt=""></a><a href="#" class="w-inline-block"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/004-linkedin.svg" height="17" alt=""></a><a href="#" class="w-inline-block"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/004-twitter.svg" height="17" alt=""></a><a href="#" class="w-inline-block"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/005-instagram.svg" width="20" height="17" alt=""></a></div>
          <div class="w-layout-grid mobileview-media-link-grid"><a href="#" class="w-inline-block"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/002-facebook.svg" height="13" alt=""></a><a href="#" class="w-inline-block"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/004-linkedin.svg" height="13" alt=""></a><a href="#" class="w-inline-block"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/004-twitter.svg" height="13" alt=""></a><a href="#" class="w-inline-block"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/005-instagram.svg" width="20" height="13" alt=""></a></div>
        </div>
        <div class="greyheaderrightsection">
          <div class="div-block-17">
            <a href="tel:80011141621" class="tollfreenumber w-inline-block">
              <div class="w-layout-grid grid-4 grid-5"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/001-phone-call.svg" width="19" height="19" id="w-node-01653a7b8efd-f1b162d0" alt="" class="image-20">
                <div id="w-node-01653a7b8efe-f1b162d0" class="text-block-8">800 ABCGROUP</div>
              </div>
            </a>
            <div class="div-block-16"><a href="mailto:info@abcgroupuae.com?subject=Enquiry" class="englanglink">Ar</a>
              <div class="text-block-6">I</div><a href="mailto:info@abcgroupuae.com?subject=Enquiry" class="englanglink">En</a></div>
          </div>
        </div>
      </div>
      <div data-collapse="medium" data-animation="over-right" data-duration="400" data-w-id="5d844d68-73ba-10b4-46c5-01653a7b8f07" style="display:flex" role="banner" class="navbar-5 w-nav">
        <div class="navbar-container w-container"><a href="index.html" aria-current="page" class="brand w-nav-brand w--current"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/ABC-logo.svg" height="50" width="48" alt="" class="abclogo"></a>
          <nav role="navigation" class="nav-menu-4 w-nav-menu">
            <div data-hover="1" data-delay="0" id="OurStoryMenu" class="ourstorydropmenu w-dropdown">
              <div class="w-dropdown-toggle">
                <div class="w-icon-dropdown-toggle"></div>
                <div>Our Story</div>
              </div>
              <nav class="w-dropdown-list"><a href="#" class="w-dropdown-link">Company Profile</a><a href="#" class="w-dropdown-link">History</a><a href="team.html" class="w-dropdown-link">Team</a><a href="global-presence.html" class="w-dropdown-link">Global Presence</a><a href="dealers.html" class="w-dropdown-link">Dealers</a></nav>
            </div><a href="#" data-w-id="5d844d68-73ba-10b4-46c5-01653a7b8f1c" class="our-story w-nav-link">Our Story</a><a href="product-exploration.html" data-w-id="5d844d68-73ba-10b4-46c5-01653a7b8f1e" class="product w-nav-link">Product</a>
            <div data-hover="1" data-delay="0" id="OurStoryMenu" class="exploredropmenu w-dropdown">
              <div class="w-dropdown-toggle">
                <div class="w-icon-dropdown-toggle"></div>
                <div>Explore</div>
              </div>
              <nav class="w-dropdown-list"><a href="brands.html" class="w-dropdown-link">Brands</a><a href="exhibit.html" class="w-dropdown-link">Exhibits</a><a href="#" class="w-dropdown-link">Projects</a></nav>
            </div><a href="#" data-w-id="5d844d68-73ba-10b4-46c5-01653a7b8f2c" class="explore w-nav-link">Explore</a><a href="#" data-w-id="5d844d68-73ba-10b4-46c5-01653a7b8f2e" class="downloads w-nav-link">Downloads</a><a href="#" data-w-id="5d844d68-73ba-10b4-46c5-01653a7b8f30" class="store-locator w-nav-link">Store Locator</a><a href="career.html" data-w-id="5d844d68-73ba-10b4-46c5-01653a7b8f32" class="career w-nav-link">Career</a>
            <div class="searchboxdiv">
              <div class="form-block w-form">
                <form id="wf-form-searchBlock" name="wf-form-searchBlock" data-name="searchBlock" class="searchform"><input type="text" class="search-textbox w-input" maxlength="256" name="Search-prosucts-2" data-name="Search Prosucts 2" placeholder="search products here" id="Search-prosucts-2"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/002-loupe.svg" width="19" id="searchicon" alt="" class="searchicon"></form>
                <div class="w-form-done"></div>
                <div class="w-form-fail"></div>
              </div>
            </div>
            <div class="favandshoplisticondiv">
              <div class="w-layout-grid grid-6"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/002-love.svg" width="29" height="23" id="w-node-01653a7b8f3d-f1b162d0" alt="" class="image-12"><a href="shoplist.html" class="w-inline-block"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Shoplist-Ikea-rzk-version.svg" width="23" height="23" alt="" class="image-11"></a></div>
            </div>
            <div class="whatsappdiv">
              <div class="w-layout-grid whatsapp-grid"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/003-whatsapp.svg" width="19" height="19" alt="">
                <div id="w-node-01653a7b8f42-f1b162d0">+971553322119</div>
                <div id="w-node-01653a7b8f44-f1b162d0">ENGLISH</div><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/003-whatsapp.svg" width="19" height="19" alt="">
                <div id="w-node-01653a7b8f47-f1b162d0">+971553322119</div>
                <div id="w-node-01653a7b8f49-f1b162d0">ARABIC</div>
              </div>
            </div>
          </nav>
          <div class="div-block-20">
            <div class="favandshoplisticondiv-hidden">
              <div class="w-layout-grid grid-6"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/002-love.svg" width="29" height="23" id="w-node-01653a7b8f4e-f1b162d0" alt="" class="image-12"><a href="shoplist.html" class="w-inline-block"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Shoplist-Ikea-rzk-version.svg" width="23" height="23" alt="" class="image-11"></a></div>
            </div>
            <div class="whatsappdiv-hidden">
              <div class="w-layout-grid whatsapp-grid"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/003-whatsapp.svg" width="19" height="19" alt="">
                <div id="w-node-01653a7b8f53-f1b162d0">+971553322119</div>
                <div id="w-node-01653a7b8f55-f1b162d0">ENGLISH</div><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/003-whatsapp.svg" width="19" height="19" alt="">
                <div id="w-node-01653a7b8f58-f1b162d0">+971553322119</div>
                <div id="w-node-01653a7b8f5a-f1b162d0">ARABIC</div>
              </div>
            </div>
          </div>
          <div class="menu-button w-nav-button">
            <div class="icon w-icon-nav-menu"></div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="reddish-menu">
    <div class="container-22 w-container"><a href="#" class="red-section-nav-link">Company Profile</a><a href="#" class="red-section-nav-link">History</a><a href="team.html" class="red-section-nav-link">Team</a><a href="global-presence.html" class="red-section-nav-link">Global Presence</a><a href="dealers.html" class="red-section-nav-link">Our Dealers<br>‍</a></div>
  </div>
  <div class="explore-reddish-menu">
    <div class="exploresubmenucontainer w-container"><a href="brands.html" class="red-section-nav-link">Brands</a><a href="exhibit.html" class="red-section-nav-link">Exhibits</a><a href="#" class="red-section-nav-link">Projects</a></div>
  </div>
  <div data-poster-url="videos/video-20200808-153546-922_h1367ecOcompressed-poster-00001.jpg" data-video-urls="videos/video-20200808-153546-922_h1367ecOcompressed-transcode.mp4,videos/video-20200808-153546-922_h1367ecOcompressed-transcode.webm" data-autoplay="true" data-loop="true" data-wf-ignore="true" class="background-video w-background-video w-background-video-atom"><video autoplay="" loop="" style="background-image:url(&quot;videos/video-20200808-153546-922_h1367ecOcompressed-poster-00001.jpg&quot;)" muted="" playsinline="" data-wf-ignore="true" data-object-fit="cover"><source src="videos/video-20200808-153546-922_h1367ecOcompressed-transcode.mp4" data-wf-ignore="true"><source src="videos/video-20200808-153546-922_h1367ecOcompressed-transcode.webm" data-wf-ignore="true"></video></div>
  <div class="whatsappbox"><a href="https://api.whatsapp.com/send?phone=971502777088&amp;abid=971502777088" class="link-block-3 w-inline-block"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/001-whatsapp.svg" width="54" height="54" alt="" class="image-31"><h5 class="heading-9">Chat<br>with Us</h5></a></div>
  <div class="section-5">
    <div class="container-19 all-page-red-section w-container">
      <div class="div-block-38">
        <h2 class="heading-11 categoryheading">Explore</h2>
      </div>
      <div class="w-layout-grid grid-11">
        <a href="#" class="link-block-3 w-inline-block">
          <div class="div-block-46"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/FweAiP.svg" height="170" width="170" alt="" class="image-27">
            <h5 class="heading-8 home-page">Sanitarywares</h5>
          </div>
        </a>
        <a href="#" class="link-block-3 w-inline-block">
          <div class="div-block-47"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Asset-4.svg" width="170" height="170" alt="" class="image-28">
            <h5 class="heading-8 home-page">Ceramics</h5>
          </div>
        </a>
        <a href="#" class="link-block-3 w-inline-block">
          <div class="div-block-45"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/9NaSBr.svg" width="170" height="170" alt="" class="image-29">
            <h5 class="heading-8 compensation">Faucets</h5>
          </div>
        </a>
        <a href="#" class="link-block-3 w-inline-block">
          <div class="div-block-48"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Asset-2.svg" width="230" height="170" alt="" class="image-30">
            <h5 class="heading-8 home-page">Kitchen</h5>
          </div>
        </a>
        <a href="#" class="link-block-3 w-inline-block">
          <div class="div-block-49"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Asset-1.svg" width="217" height="170" alt="" class="image-36">
            <h5 class="heading-8 home-page">Accessories</h5>
          </div>
        </a>
      </div>
    </div>
  </div>
  <div class="section-5-copy">
    <div class="container-19 all-page-red-section w-container">
      <div class="div-block-38">
        <h2 class="heading-11">Explore</h2>
      </div>
      <div class="w-layout-grid grid-11">
        <div id="w-node-ba469db9f95e-f1b162d0">
          <h5 class="heading-8 combocolour">Sanitarywares</h5>
        </div>
        <div id="w-node-ba469db9f962-f1b162d0">
          <h5 class="heading-8 combocolour">Ceramics</h5>
        </div>
        <div id="w-node-ba469db9f966-f1b162d0">
          <h5 class="heading-8 combocolour">Faucets</h5>
        </div>
        <div id="w-node-ba469db9f96a-f1b162d0">
          <h5 class="heading-8 combocolour">Kitchen</h5>
        </div>
        <div id="w-node-ba469db9f96e-f1b162d0">
          <h5 class="heading-8 combocolour">Accessories</h5>
        </div>
      </div>
    </div>
  </div>
  <div class="homepage-herosection w-clearfix">
    <div class="coloureddivisionmain"></div>
    <div class="container-20 w-container">
      <div class="w-layout-grid grid-10">
        <h3 id="w-node-47c6bbd8af41-f1b162d0" class="heading-7 w-clearfix"><span class="text-span">Message from the<br> founder and Md</span></h3><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/madanikka.jpg" width="259" height="259" id="w-node-983056b0843a-f1b162d0" alt="" class="image-32">
        <div id="w-node-63299fef606d-f1b162d0" class="div-block-37">
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat. Aenean faucibus nibh et j56156+125+15156+156+156156+usto cursus id rutrum lorem imperdiet. Nunc ut sem vitae risus tristique posuere.</p>
          <h4 class="heading-10">Muhammed Madani</h4>
        </div>
      </div>
      <div class="div-block-29">
        <h2 class="redheadings">Our Core Purpose</h2>
        <div class="mainfullcaptext">To Help People<br>Transform their World</div>
        <h2 class="redheadings">Our Values</h2>
      </div>
      <div class="div-block-25">
        <div id="w-node-da8042520882-f1b162d0" class="corevaluedivblock">
          <div class="valuesign-and-heading"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Asset-6.svg" width="54" height="60" alt="" class="image-22">
            <h3 class="heading-2">Relationship for life</h3>
          </div>
          <div class="div-block-28">
            <p class="paragraph-5">ABC has a lifelong commitment to its customers, employees, stakeholders, vendors and well-wishers. We are committed to help them to lead a happier, longer and fulfilling life</p>
          </div>
        </div>
        <div class="corevaluedivblock">
          <div class="valuesign-and-heading"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Asset-4_1.svg" width="54" height="60" alt="" class="image-22">
            <h3 class="heading-2">Customer Service and Satisfaction</h3>
          </div>
          <div class="div-block-28">
            <p class="paragraph-5">ABC has a lifelong commitment to its customers, employees, stakeholders, vendors and well-wishers. We are committed to help them to lead a happier, longer and fulfilling life</p>
          </div>
        </div>
        <div class="corevaluedivblock">
          <div class="valuesign-and-heading"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Asset-5.svg" width="54" height="60" alt="" class="image-22">
            <h3 class="heading-2">Futuristic and Innovative</h3>
          </div>
          <div class="div-block-28">
            <p class="paragraph-5">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat. Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc ut sem vitae risus tristique posuere.</p>
          </div>
        </div>
        <div class="corevaluedivblock">
          <div class="valuesign-and-heading"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Asset-3.svg" width="54" height="60" alt="" class="image-22">
            <h3 class="heading-2">Teamwork for Excellence</h3>
          </div>
          <div class="div-block-28">
            <p class="paragraph-5">ABC has a lifelong commitment to its customers, employees, stakeholders, vendors and well-wishers. We are committed to help them to lead a happier, longer and fulfilling life</p>
          </div>
        </div>
        <div class="corevaluedivblock">
          <div class="valuesign-and-heading"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Asset-2_1.svg" width="54" height="60" alt="" class="image-22">
            <h3 class="heading-2">Responsible &amp; Result Oriented</h3>
          </div>
          <div class="div-block-28">
            <p class="paragraph-5">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat. Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc ut sem vitae risus tristique posuere.</p>
          </div>
        </div>
        <div class="corevaluedivblock">
          <div class="valuesign-and-heading"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Asset-1_1.svg" width="54" height="60" alt="" class="image-22">
            <h3 class="heading-2">Win-win Cooperation</h3>
          </div>
          <div class="div-block-28">
            <p class="paragraph-5">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat. Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc ut sem vitae risus tristique posuere.</p>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="home-page-red-section w-container">
    <h1 class="heading-5 fontfamily">Become a Trade Partner</h1>
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat. Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc ut sem vitae risus tristique posuere.</p>
    <div data-w-id="2e2e4fa3-211c-c57b-6c2d-8d76bc6c62da" class="buttonclass">
      <h3 class="heading-6">Contact us For Dealership</h3>
    </div>
  </div>
  <div class="footersection">
    <div class="footermenucontainer w-container">
      <div data-w-id="084592a8-06a0-e5a4-2527-7513cd9ec849" class="scrolltotoparrow"><a href="#" class="w-inline-block"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/up-arrow.svg" width="38" height="30" alt="" class="image-15"></a></div>
      <div class="w-layout-grid footermenugrid">
        <div id="w-node-91a09e5fc710-9e5fc70b" class="footer-heading-div">
          <ul role="list" class="list w-list-unstyled">
            <li class="footerlist-item"><a href="#" class="footerlink">Company Profile</a></li>
            <li class="footerlist-item"><a href="#" class="footerlink">History</a></li>
            <li class="footerlist-item"><a href="team.html" class="footerlink">Team</a></li>
            <li class="footerlist-item"><a href="global-presence.html" class="footerlink">Global Presence</a></li>
          </ul>
          <div class="whitedividerdiv"></div>
        </div>
        <div class="footer-heading-div">
          <ul role="list" class="list w-list-unstyled">
            <li class="footerlist-item"><a href="dealers.html" class="footerlink">Dealers</a></li>
            <li class="footerlist-item"><a href="brands.html" class="footerlink">Brand</a></li>
            <li class="footerlist-item"><a href="exhibit.html" class="footerlink">Exhibits</a></li>
            <li class="footerlist-item"><a href="downloads.html" class="footerlink">Downloads</a></li>
          </ul>
          <div class="whitedividerdiv"></div>
        </div>
        <div class="footer-heading-div">
          <ul role="list" class="list w-list-unstyled">
            <li class="footerlist-item"><a href="#" class="footerlink">StoreLocator</a></li>
            <li class="footerlist-item"><a href="career.html" class="footerlink">Career</a></li>
            <li class="footerlist-item"><a href="#" class="footerlink">Privacy Policy</a></li>
            <li class="footerlist-item"><a href="#" class="footerlink">Cookies Policy</a></li>
          </ul>
          <div class="whitedividerdiv"></div>
        </div>
        <div class="footer-heading-div">
          <ul role="list" class="footerlastsectionlist w-list-unstyled">
            <li class="footerlist-item"><a href="#" class="footerlink">Terms and condition</a></li>
            <li class="footerlist-item"><a href="product-exploration.html" class="footerlink">Products</a></li>
          </ul>
          <div class="whitedividerdiv"></div>
        </div>
        <div id="w-node-91a09e5fc742-9e5fc70b" class="footer-newsletter-div">
          <div class="text-block-11">Get Our News Letter</div>
          <div class="form-block-3 w-form">
            <form id="email-form-3" name="email-form-3" data-name="Email Form 3" class="form-3"><input type="text" class="text-field-2 w-input" maxlength="256" name="Mailid-2" data-name="Mailid 2" placeholder="Enter your mail id" id="Mailid-2"><input type="submit" value="Subscribe" data-wait="Please wait..." class="newslwttersubscribebutton w-button"></form>
            <div class="w-form-done">
              <div>Thank you! Your submission has been received!</div>
            </div>
            <div class="w-form-fail">
              <div>Oops! Something went wrong while submitting the form.</div>
            </div>
          </div>
          <div class="whitedividerdiv"></div>
        </div>
        <div class="footer-social-media-links">
          <div class="w-layout-grid footersocialmediagrid"><a href="#" class="w-inline-block"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/method-draw-image.svg" height="" width="12" alt=""></a><a href="#" class="w-inline-block"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Asset-1-1.png" height="" width="17" alt=""></a><a href="#" class="w-inline-block"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Asset-2-1.png" height="" width="17" alt=""></a><a href="#" class="w-inline-block"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/method-draw-image-1.svg" height="" width="17" alt=""></a></div>
        </div>
      </div>
    </div>
  </div>
  <script src="https://d3e54v103j8qbb.cloudfront.net/js/jquery-3.5.1.min.dc5e7f18c8.js?site=5f103f7e5224a5353e5ce1c7" type="text/javascript" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
  <script src="js/webflow.js" type="text/javascript"></script>
  <!-- [if lte IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/placeholders/3.0.2/placeholders.min.js"></script><![endif] -->
</body>
</html>