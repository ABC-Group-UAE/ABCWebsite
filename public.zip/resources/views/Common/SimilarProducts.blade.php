
  <?php
      $From = '';
      if($fromValue != ''){
        $From = $fromValue;
      }

  ?>
  <style>
.sf-rib-scroller {
    display: flex;
    align-items: center;
    height: 48px;
    min-height: 0;
    padding: 0;
    border-bottom: 2px solid #ddd;
    background-color: #fff;
    -ms-overflow-style: none;
}
.s-mobile-toolbar {
    min-height: 44px;
    padding-top: 6px;
    padding-bottom: 6px;
    background-color: #fff;
    border-bottom: 2px solid #ddd;
    transition: .2s linear;
}
.a-scroller-horizontal {
    overflow-y: hidden;
}
.a-scroller {
    width: 10%;
    height: 100%;
    overflow: auto;
    -webkit-overflow-scrolling: touch;
}
* {
    -moz-box-sizing: border-box;
    /* -webkit-box-sizing: border-box; */
    /* box-sizing: border-box; */
}


.sf-rib-scroller::-webkit-scrollbar {
    display: none;
}
.sf-rib-scroller .sf-rib-element:first-child {
    padding-left: 8px;
}
.a-nowrap, .aok-nowrap {
    white-space: nowrap;
}
.a-section {
    margin-bottom: 1.3rem;
}
.a-spacing-none, .a-ws .a-ws-spacing-none {
    /* margin-bottom: 0!important; */
}
* {
    -moz-box-sizing: border-box;
    /* -webkit-box-sizing: border-box; */
    /* box-sizing: border-box; */
}
/*div {
    display: block;
}*/

/*.content {
 overflow-x: scroll;
 padding: 20px;
}*/

</style>


  @if(!empty($mightAlsoLike))

       <div class="container-32-copy w-container">
        <form>
          @csrf
        <h4 class="heading-15">Similar products you may like</h4>
             <div class="similar-products-div">
                    
                      <div class="w-layout-grid grid-21 ">
                        
                      @foreach($mightAlsoLike as $productItem)
                          <div>
                            <div class="productlink-holding-div">
                              <a href="{{ route('Product.description', $productItem->Product_id) }}" style="text-decoration:none;font-color:black;">
                                  <div class="product-image-div">
                                      <img height="235" width="400" src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/{{$productItem->MainImage)}}" data-w-id="3c19b6ca-7ea9-da35-4a03-adbd651e2f1a" alt="" class="product-image">
                                    </div>
                                  <div class="product-name">{{ $productItem->product_name }}</div>
                              </a>
                            </div>
                            <div class="fav-cart">
                              <div class="fav" onClick=" return wishListAddition('{{$productItem->Product_id}}','{{$From}}',event)"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/002-love.svg" width="22" height="22" alt="" class="favimage">
                                <div class="like-text">Like</div>
                              </div>
                              <div class="addtocartbutton" onClick=" return CartAddition('{{$productItem->Product_id}}','{{$From}}',event)"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Shoplist-Ikea-rzk-version.svg" width="19" height="19" alt="" class="cart-img">
                                <div class="addtocarttext">Add To Cart</div>
                              </div>
                            </div>
                          </div>
                      @endforeach  
                        </div>
                        
                          
                     
            </div>
          </form>  
       </div>
   @endif 


   <script>
      function CartAddition(productId,fromValue,e){
        alert("hi from inside similar product product-image" + fromValue);
          event.preventDefault();
          
                          if($("#shopmsg"). length)
                          {
                            $("#shopmsg").remove();
                           
                          }
          //alert(productId +" and "+fromValue);
            var url = "{{ route('Cart.Add') }}";
            url = url.replace("http", "https");
            var _token = '<?php echo csrf_token() ?>';
            alert(url);
            alert(_token);
            $.ajax({
                  type: "post",
                  url: url,
                  data: {   
                               id: productId,
                         Quantity: 1,
                         _token  :_token
                       },
                  success:function(result,e) {
                   // alert(result.message+"and"+ result.count+"and"+ result.success );
                    console.log(result);
                      console.log(result.data);
                    console.log(result.message);
                    console.log(result.count);
                    if(result.count > 0){ //checking cart is empty or not.. if not empty
                      //if not empty
                      $("#cartCount").css('display','inline');
                      $("#cartCountText").text(result.count);
                    
                    }else{
                      // if cart is empty
                      $("#cartCount").css('display','none');
                    }
                     if(fromValue == "ShopList"){ //opening of from value checking if



                        alert("Adding to Cart");



                    if(!result.AlreadyAdded){// checking if the item already exist in cart
                          // do this if the item is new to the cart
                                  if(! (jQuery.isEmptyObject(result.product))){ // checking the product detail container is empty or not
                                    //do this if it is not empty
                                    if(result.count > 0 && result.count == 1){// checking if the cart is empty and no cart div present in page
                                          //console.log.(result.count);

                                          // if Cart div is not present then including cart div that cart content is appending to the container and hiding cart empty message


                                          $("#message").css('display','none');
                                          var $html = $("<div id='CARTLIST'><div><h1>CART</h1></div><div class='heading-div'><div class='div-block-78'><div><h4>Product Added to the ShopList</h4></div><div><h4>Quantity</h4></div><div><h4 class='heading-23'>Quantity</h4></div>"
                                             +"<div><h4 class='heading-23'>Price</h4></div></div></div></div><form id='cartUpdate' name='email-form' data-name='Email Form' class='form-4'><input name='_token' value='"+_token+"' type='hidden'>"
                                              +"<div class='w-layout-grid cart-list' id='Cart' name='Cart'><div id='row"+result.count+"' style='display:inline'><div class='div-block-76 w-clearfix'><div class='div-block-90'><a href='Description/"+ result.product.Product_id +"'>"
                                            +"<div class='div-block-75' id = 'Productpic_"+result.count+"'></div><div>"+ result.product.product_name +"</div></a></div><div class='div-block-89'><div class='w-form'><input  name='productId_"+result.count+"' id='productId_"+result.count+"' value='"+result.product.Product_id+"' type='hidden'>"
                                            +"<input type='text' class='text-field-3 w-input' maxlength='256' name='qtyText"+result.count+"' id='qtyText"+result.count+"' data-name='Name' value= '"+result.cartitem.quantity+"'  onChange='UpdateCartQuantity("+result.count+",event) '></div></div><div > <label id = 'price_"+result.count+"' name=price_"+result.count+"'> AED"+result.summedPrice+" </label> </div>"
                                            +"<a id ='delete_"+result.count+"' href=''   class='close' onClick='RemoveFromCart("+result.count+",event)'>+</a></div><div class='grey-divider-div'></div></div> </div><div id='priceDetails'><div style='float:right;display:flex'><label>SubTotal</label><label id='subtotal'>"+result.subTotal+"</label></div><br><div style='float:right;display:flex'><label>VAT included</label><label id='tax'>"+result.vat+"</label></div><br><div style='float:right;display:flex'><label>Grand Total</label><label id='grandtotal'>"+result.Total+"</label></div><br></div></form>");
                                            newdiv2 = document.createElement( "div" ),
                                           // existingdiv1 = $( "#ShopList" );
                                            $( "#CartContent" ).append( $html);
                                             $("<div class='button-div' id='purchaseButton'><a data-w-id='058c16d4-5fe2-d8eb-62df-fa46370ee06d' href='#' class='buttonclass-copy combostyle w-button'>Proceed To Purchase</a></div>").appendTo("#CartContent");
                                            $('#Productpic_'+ result.count).css("background-image", 'url(' + 'images/' + result.product.MainImage+ ')');
                                            $('#Productpic_'+ result.count).css("background-repeat", 'no-repeat');
                                            $('#Productpic_'+ result.count).css("width", '1000%');
                                            $('#qtyText'+ result.count).val(result.cartitem.quantity);
                            }
                            else
                            {


                              //if the cart div is present then appending product details to the existing cart div

                              var $temp = $("<div id='row"+result.count+"' style='display:inline'><div class='div-block-76 w-clearfix'><div class='div-block-90'><a href='Description/"+ result.product.Product_id +"' ><div class='div-block-75' id = 'Productpic_"+result.count+"'></div><div>"+ result.product.product_name +"</div></a></div><div class='div-block-89'><div class='w-form'> <input type='hidden' name='productId_"+result.count+"' id='productId_"+result.count+"' value='"+result.product.Product_id+"'><input type='text' class='text-field-3 w-input' maxlength='256' name='qtyText"+result.count+"' id='qtyText"+result.count+"' data-name='Name' value= '"+result.cartitem.quantity+"'  onChange='UpdateCartQuantity("+result.count+",event) '></div></div><div > <label id = 'price_"+result.count+"' name=price_"+result.count+"'> AED"+result.summedPrice+" </label> </div><a id ='delete_"+result.count+"' href=''  class='close'  onClick='RemoveFromCart("+result.count+",event)'>+</a></div><div class='grey-divider-div'></div></div> "); 
                                // $( "#Cart" ).append( $temp );
                                $temp.appendTo("#Cart");
                                    // newdiv2 = document.createElement( "div" ),
                                    // existingdiv1 = $( "#Cart" );
                                    // $( "body" ).append( $temp, [ newdiv2, existingdiv1 ] );
                                    $('#Productpic_'+ result.count).css("background-image", 'url(' + 'images/' + result.product.MainImage+ ')');
                                    $('#Productpic_'+ result.count).css("background-repeat", 'no-repeat');
                                    $('#Productpic_'+ result.count).css("width", '1000%');
                                    $('#qtyText'+ result.count).val(result.cartitem.quantity);
                                    if($("#priceDetails"). length){
                                            $("#subtotal").text(result.subTotal);
                                            $("#tax").text(result.vat);
                                            $("#grandtotal").text(result.Total);
                                       } 
                            }

                              alert("product fetched");  
                                    
                            }//end of jQuery.isEmptyObject(result.product)))
                    }else{
                      // do the following if the item already exist in cart
                        for(var i=1;i<=result.count;i++){
                          var pid = $('#productId_'+i).val();
                          //alert("product id" + pid);
                          if(pid == result.product.Product_id){
                                $('#qtyText'+ i).val(result.cartitem.quantity);
                                $('#price_'+ i).text(result.summedPrice);
                                if($("#priceDetails"). length){
                                            $("#subtotal").text(result.subTotal);
                                            $("#tax").text(result.vat);
                                            $("#grandtotal").text(result.Total);
                                } 
                                break;

                          }
                        }
                        alert("product fetched");
                        

                    }
                    
                    } // close of from value checking if
                    // e.preventDefault();
                    
                  },//end of success function
                  error:function(result) {
                    alert('error');
                    console.log(result);

                  }
              });

      }


       function wishListAddition(productId,fromValue,e){
        alert("hi from inside similar product product-image");
        if($("#favmsg"). length)
                          {
                            $("#favmsg").remove();
                           
                          }
          event.preventDefault();
          alert(fromValue);
           if($("#favmsg"). length)
                          {
                            $("#favmsg").remove();
                           
                          }
                          if($("#shopmsg"). length)
                          {
                            $("#shopmsg").remove();
                           
                          }
          //alert(productId +" and "+fromValue);
            var url = "{{ route('Favourite.Add') }}";
            url = url.replace("http", "https");
            var _token = '<?php echo csrf_token() ?>';
            alert(url);
            alert(_token);
            $.ajax({
                  type: "post",
                  url: url,
                  data: {   
                               id: productId,
                         Quantity: 1,
                         _token  :_token
                       },
                  success:function(result,e) {
                   // alert(result.message+"and"+ result.count+"and"+ result.success );
                    console.log(result);
                      console.log(result.data);
                    console.log(result.message);
                    console.log(result.count);
                     if(fromValue == "ShopList"){ //opening of from value checking if



                        alert("Adding to wishlist");



                    if(!result.AlreadyAdded){// checking if the item already exist in cart
                          // do this if the item is new to the cart
                                  if(! (jQuery.isEmptyObject(result.product))){ // checking the product detail container is empty or not
                                    //do this if it is not empty
                                    if(result.count > 0 && result.count == 1){// checking if the cart is empty and no cart div present in page
                                          //console.log.(result.count);

                                          // if Cart div is not present then including cart div that cart content is appending to the container and hiding cart empty message


                                          $("#message").css('display','none');
                                          var $html = $("<div id='FAVLIST'><div><h1>Favourite List</h1></div><div class='heading-div'><div class='div-block-78'><div><h4>Product Added to the wishList</h4></div><div><h4>Quantity</h4></div><div><h4 class='heading-23'>Quantity</h4></div>"
                                             +"<div><h4 class='heading-23'>Price</h4></div></div></div></div><form id='wishList' name='wishList' data-name='wishList' class='wishList'><input name='_token' value='"+_token+"' type='hidden'>"
                                              +"<div class='w-layout-grid cart-list' id='WishCart' name='WishCart'><div id='Wishrow"+result.count+"' style='display:inline'><div class='div-block-76 w-clearfix'><div class='div-block-90'><a href='Description/"+ result.product.Product_id +"' >"
                                            +"<div class='div-block-75' id = 'WishProductpic_"+result.count+"'></div><div>"+ result.product.product_name +"</div></a></div><div class='div-block-89'><div class='w-form'><input  name='WishproductId_"+result.count+"' id='WishproductId_"+result.count+"' value='"+result.product.Product_id+"' type='hidden'>"
                                            +"<input type='text' class='text-field-3 w-input' maxlength='256' name='WishqtyText"+result.count+"' id='WishqtyText"+result.count+"' data-name='Name' value= '"+result.cartitem.quantity+"'  onChange='UpdateWishListQuantity("+result.count+",event) '></div></div><div > <label id = 'Wishprice_"+result.count+"' name= 'Wishprice_"+result.count+"'> AED "+result.summedPrice+" </label> </div>"
                                            +"<a id ='Wishdelete_"+result.count+"' href=''   class='close' onClick='RemoveFromWishList("+result.count+",event)'>+</a><div id = 'WishAddCart_"+result.count+"' style='width:30%' onClick='addFromWishListToCart("+result.count+",\""+fromValue+"\",event)' ><a  href='#' class='buttonclass-copy combostyle hereonly w-button'>Add To Cart</a></div></div><div class='grey-divider-div'></div></div> </div></form>");
                                            newdiv2 = document.createElement( "div" ),
                                           // existingdiv1 = $( "#ShopList" );
                                            $( "#wishListDiv" ).append( $html);
                                            $('#WishProductpic_'+ result.count).css("background-image", 'url(' + 'images/' + result.product.MainImage+ ')');
                                            $('#WishProductpic_'+ result.count).css("background-repeat", 'no-repeat');
                                            $('#WishProductpic_'+ result.count).css("width", '1000%');
                                            $('#WishqtyText'+ result.count).val(result.cartitem.quantity);
                            }
                            else
                            {


                              //if the cart div is present then appending product details to the existing cart div

                              var $temp = $("<div id='Wishrow"+result.count+"' style='display:inline'><div class='div-block-76 w-clearfix'><div class='div-block-90'><a href='Description/"+ result.product.Product_id +"' ><div class='div-block-75' id = 'WishProductpic_"+result.count+"'></div><div>"+ result.product.product_name +"</div></a></div><div class='div-block-89'><div class='w-form'> <input type='hidden' name='WishproductId_"+result.count+"' id='WishproductId_"+result.count+"' value='"+result.product.Product_id+"'><input type='text' class='text-field-3 w-input' maxlength='256' name='WishqtyText"+result.count+"' id='WishqtyText"+result.count+"' data-name='Name' value= '"+result.cartitem.quantity+"'  onChange='UpdateWishListQuantity("+result.count+",event) '></div></div><div > <label id = 'Wishprice_"+result.count+"' name='Wishprice_"+result.count+"'> AED"+result.summedPrice+" </label> </div><a id ='Wishdelete_"+result.count+"' href=''  class='close'  onClick='RemoveFromWishList("+result.count+",event)'>+</a><div id = 'WishAddCart_"+result.count+"' style='width:30%'  onClick='addFromWishListToCart("+result.count+",\""+fromValue+"\",event)' ><a  href='#' class='buttonclass-copy combostyle hereonly w-button'>Add To Cart</a></div></div><div class='grey-divider-div'></div></div> "); 
                                //$( "#Cart" ).append( $temp );
                                $temp.appendTo("#WishCart");
                                    // newdiv2 = document.createElement( "div" ),
                                    // existingdiv1 = $( "#Cart" );
                                    // $( "body" ).append( $temp, [ newdiv2, existingdiv1 ] );
                                    $('#WishProductpic_'+ result.count).css("background-image", 'url(' + 'images/' + result.product.MainImage+ ')');
                                    $('#WishProductpic_'+ result.count).css("background-repeat", 'no-repeat');
                                    $('#WishProductpic_'+ result.count).css("width", '1000%');
                                    $('#WishqtyText'+ result.count).val(result.cartitem.quantity);
                            }

                              alert("product fetched");  
                                    
                            }//end of jQuery.isEmptyObject(result.product)))
                    }else{
                      // do the following if the item already exist in wishList
                        for(var i=1;i<=result.count;i++){
                          var pid = $('#WishproductId_'+i).val();
                          alert("count="+result.count+"product id" + pid +"product id from controller"+result.product.Product_id);
                          if(pid == result.product.Product_id){
                            alert("inside changing content function");
                                $('#WishqtyText'+ i).val(result.cartitem.quantity);
                                $('#Wishprice_'+ i).text(result.summedPrice);

                          }
                        }
                        alert("product fetched");
                        

                    }
                    
                    } // close of from value checking if

                   
                    
                    // e.preventDefault();
                    
                  },
                  error:function(result) {
                    alert('error');
                    console.log(result);

                  }
              });

      }

   </script>