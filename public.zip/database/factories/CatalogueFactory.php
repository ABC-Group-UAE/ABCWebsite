<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\catalogue;
use Faker\Generator as Faker;

$factory->define(catalogue::class, function (Faker $faker) {
    return [
        //
    ];
});
