<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\SubSubCategory;
use Faker\Generator as Faker;

$factory->define(SubSubCategory::class, function (Faker $faker) {
    return [
        //
    ];
});
