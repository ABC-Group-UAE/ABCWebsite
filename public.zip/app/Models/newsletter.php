<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class newsletter extends Model
{
    use HasFactory;
    protected $table = 'newsletter';
    public $primaryKey = 'subscriberID';
    protected $guarded =[]; 
     public $timestamps = false;
}
