<?php

use Illuminate\Support\Facades\Route;
use App\Models\page;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'App\Http\Controllers\careerController@indexhome')->name('home');

Route::view('download','download');
Route::view('Dealers','Dealers')->name('Dealers');
Route::view('exhibit','exhibit')->name('Exhibits');
Route::view('brands','brands')->name('Brands');

Route::view('careerview','career')->name('careers');
Route::view('product1','productDescription');
Route::view('product','product.productExplore');
Route::view('Team','Team')->name('Team');
Route::view('Presence','globalPresence')->name('OurPresence');
Route::view('CartDisplay','cart.ShopList');
// Route::view('Product/Explore','product.Explore');''

Route::get('catalogue','App\Http\Controllers\CatalogueController@index')->name('catalogue');
Route::get('download/{filename}','App\Http\Controllers\CatalogueController@downloadpdf')->name('catalogue.download');
Route::get('Description/{Product_id}','App\Http\Controllers\ProductController@index')->name('Product.description');
Route::get('Description/BX1071','App\Http\Controllers\ProductController@index')->name('Description');
Route::post('Description/Option','App\Http\Controllers\filterController@ProductFetchBasedOnOption')->name('Product.description.option');
Route::get('Product/Explore','App\Http\Controllers\ProductController@indexExplore')->name('Explore');
Route::get('Product/Explore/MobileFilter','App\Http\Controllers\ProductController@CategoryDetailsFetch')->name('Categories.Fetch');
// Route::post('Product/Explore/SubCategory','App\Http\Controllers\ProductController@ProductFectchBasedOnSubCategory')->name('Product.Fetch');
// Route::post('Product/Explore/SubSubCategory','App\Http\Controllers\ProductController@ProductFectchBasedOnSubSubCategory')->name('Product.ProductFetch');
// Route::post('Product/Explore/Price','App\Http\Controllers\ProductController@ProductFectchBasedOnFilters')->name('Product.Fetch.Price');
// Route::post('Product/Explore/Filter','App\Http\Controllers\ProductController@ProductFetchBasedOnFilters')->name('Product.Fetch');
Route::post('Product/Explore/Filter','App\Http\Controllers\filterController@ProductFetchBasedOnFilters')->name('Product.Fetch');



//ajax route
// Route::post('/cart/{Product_id}','App\Http\Controllers\cartController@add')->name('Cart.add'); 
// Route::post('Description/{Product_id}/cart','App\Http\Controllers\cartController@add')->name('Cart.add');
  // Route::post('cart','App\Http\Controllers\cartController@add')->name('Cart.Add');

//Cart Related Routes
Route::post('AddToCart','App\Http\Controllers\ABCCartController@add')->name('Cart.Add');
Route::get('CartView','App\Http\Controllers\ABCCartController@index')->name('Cart.View');
Route::post('Cart/Update','App\Http\Controllers\ABCCartController@cartUpdate')->name('Cart.Update');
Route::post('Cart/Remove','App\Http\Controllers\ABCCartController@cartRemove')->name('Cart.Remove');
Route::post('Cart/Multiple','App\Http\Controllers\ABCCartController@AddingMultipleItemsToCart')->name('Cart.Add.Multiple');
Route::post('Enquire','App\Http\Controllers\ABCCartController@ContactUs')->name('shoplist.enquire');
Route::get('CartView/order','App\Http\Controllers\ABCCartController@indextoorder')->name('Cart.order');



//FavouriteList Related Routes
Route::post('AddToWishList','App\Http\Controllers\WishListController@addToWhishList')->name('Favourite.Add');
Route::post('WishList/Update','App\Http\Controllers\WishListController@wishListUpdate')->name('Favourite.Update');
Route::post('WishList/Remove','App\Http\Controllers\WishListController@cartRemove')->name('Favourite.Remove');

//Route::view('product.Description','product.Description');

Route::post('file_upload','App\Http\Controllers\careerController@file_upload');
Route::post('newsLetter','App\Http\Controllers\careerController@subscribeNewsLetter')->name('Subscribe.newsLetter');
Route::post('contactus','App\Http\Controllers\careerController@ContactUs')->name('Dealers.contactus');
Route::get('/autosearch','App\Http\Controllers\careerController@autosearch')->name('autocomplete');
Route::get('/career','App\Http\Controllers\careerController@index')->name('indexCareer');
Route::get('/filter','App\Http\Controllers\careerController@SearchFilter')->name('Search.filter');
Route::get('/Category/filter','App\Http\Controllers\careerController@HomeSearchFilter')->name('Search.Home.filter');



// google map API
 Route::get('location','App\Http\Controllers\careerController@locations')->name('location');
 Route::get('locationfilter','App\Http\Controllers\careerController@locationfilter');


Route::resource('/category' , 'App\Http\Controllers\categoryController');



Route::view('accordian','accordian');


/// uploading images to amazon s3 and retreiving from s3
Route::get('/productimages', 'App\Http\Controllers\Imagecontroller@create');
Route::post('/productimages', 'App\Http\Controllers\Imagecontroller@store');
Route::get('/productimages/{image}', 'App\Http\Controllers\Imagecontroller@show')->name('image.show');
