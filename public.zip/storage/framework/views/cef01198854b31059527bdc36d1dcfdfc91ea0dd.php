<!DOCTYPE html>
<!--  This site was created in Webflow. http://www.webflow.com  -->
<!--  Last Published: Tue Sep 15 2020 12:53:39 GMT+0000 (Coordinated Universal Time)  -->

<?php if(isset($page)): ?>
<html data-wf-page="<?php echo e($page->page_id); ?>" data-wf-site="5f103f7e5224a5353e5ce1c7">
<?php else: ?>
 <html data-wf-page="5f91211170b33add84a26cf0" data-wf-site="5f103f7e5224a5353e5ce1c7"> 
<?php endif; ?>

<head>
  <meta charset="utf-8">
  <?php if(isset($page)): ?>
   <title><?php echo e($page->page_name); ?></title>
<?php else: ?>
   <title>ABC Home</title>
<?php endif; ?>
 
  <meta content="ABC Group" property="og:title">
  <meta content="ABC Group" property="twitter:title">
  <meta content="width=device-width, initial-scale=1" name="viewport">
  <meta content="Webflow" name="generator">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  
  <link href="/css/normalize.css" rel="stylesheet" type="text/css">
  <link href="/css/webflow.css" rel="stylesheet" type="text/css">
  <link href="/css/share.css" rel="stylesheet" type="text/css">
  <link href="/css/abcgroupuae.webflow.css" rel="stylesheet" type="text/css">
  <!-- [if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.min.js" type="text/javascript"></script><![endif] -->
  <script type="text/javascript">!function(o,c){var n=c.documentElement,t=" w-mod-";n.className+=t+"js",("ontouchstart"in o||o.DocumentTouch&&c instanceof DocumentTouch)&&(n.className+=t+"touch")}(window,document);</script>
  <link href="/images/favicon.ico" rel="shortcut icon" type="image/x-icon">
  <link href="/images/webclip.png" rel="apple-touch-icon">
  <link href="https://www.jqueryscript.net/css/jquerysctipttop.css" rel="stylesheet" type="text/css">
  <!-- <link type="text/css" rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>"> -->
  <script src="https://code.jquery.com/jquery-1.11.3.min.js"></script>
 
  <script src="/js/ranger.js"></script>
<script src="/js/jquery.min.js"></script>
<script src="/js/jquery.simplePagination.js"></script>
<script src="/js/jquery-ui.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui-touch-punch/0.2.3/jquery.ui.touch-punch.min.js" integrity="sha512-0bEtK0USNd96MnO4XhH8jhv3nyRF0eK87pJke6pkYf3cM0uDIhNJy9ltuzqgypoIFXw3JSuiy04tVk4AjpZdZw==" crossorigin="anonymous"></script>

<link href="/extra_css/ranger.css" rel="stylesheet">
<link href="/extra_css/jquery-ui.css" rel="stylesheet">
<link href="/css/bootstyle.css" rel="stylesheet">
<link href="/css/simplePagination.css" rel="stylesheet">
<link href='https://use.fontawesome.com/releases/v5.7.2/css/all.css'>
<script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js'></script>
<!-- <link href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css'> -->
<link href="/css/bootstrap.min.css">

<!-- <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script> -->
<script type='text/javascript' src='https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js'></script>
<link href="/css/bootstrap.min.css" rel='stylesheet'>
                                <link href='https://use.fontawesome.com/releases/v5.7.2/css/all.css' rel='stylesheet'>
                                <!-- <script  src="https://use.fontawesome.com/releases/v5.6.3/js/all.js" integrity="sha384-EIHISlAOj4zgYieurP0SdoiBYfGJKkgWedPHH4jCzpCXLmzVsw1ouK59MuUtP4a1" crossorigin="anonymous"></script> -->
                                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">              
                                <meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">                                           
</head>
<body >

<?php echo $__env->make('Common.Dynamicheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('extra-css'); ?>

<?php echo $__env->yieldContent('content'); ?>

<?php echo $__env->yieldContent('extra-js'); ?>

<?php echo $__env->make('Common.Footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
  <script src="/js/webflow.js" type="text/javascript"></script>
   <!-- <script src="https://d3e54v103j8qbb.cloudfront.net/js/jquery-3.5.1.min.dc5e7f18c8.js?site=5f103f7e5224a5353e5ce1c7" type="text/javascript" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>  -->
 
  <!-- [if lte IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/placeholders/3.0.2/placeholders.min.js"></script><![endif] -->
</body>

</html>

<script>
// var base_url= '<?php echo e(url()); ?>';
// console.log("base_url="+base_url);
//   $( document ).ajaxComplete( function() {
//     window.Webflow && window.Webflow.destroy();
//     window.Webflow && window.Webflow.ready();
//     window.Webflow && window.Webflow.require( 'ix2' ).init();
//     document.dispatchEvent( new Event( 'readystatechange' ) );
// });
  </script>
  <?php /**PATH C:\wamp\www\Projects\ABC3\ABC_hosted\resources\views\Layout\layout.blade.php ENDPATH**/ ?>