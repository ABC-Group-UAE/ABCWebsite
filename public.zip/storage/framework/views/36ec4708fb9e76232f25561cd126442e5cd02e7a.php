
<br>

This customer has enquired about dealership details
<br>
Customer detail is
<br>

** Email:** <?php echo e($contact->customer_mailid); ?>  <br>

** Name:** <?php echo e($contact->CustomerName); ?>  <br>

** Mobile Number:** <?php echo e($contact->mobile); ?> <br>



**Type of enquiry:**   <?php echo e($contact->type_of_enquiry); ?>  <br>
**Message: **   <?php echo e($contact->message); ?>  <br>



Please contact this person...

<br>

Thank you <br>

Regards,<br>
Abc Website<?php /**PATH C:\wamp\www\Projects\ABC3\ABC_hosted\resources\views\emails\contact.blade.php ENDPATH**/ ?>