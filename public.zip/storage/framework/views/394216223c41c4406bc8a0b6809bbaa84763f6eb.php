<?php if($Category->count()): ?>

<form action="/category/<?php echo e($Category->Category_ID); ?>" method="post">
    <?php echo method_field('PATCH'); ?>
    <?php echo csrf_field(); ?>
<div class="box">
<div>
<label for="Category_Id"> Category_Id</label>
    <input type="text" name="Category_Id" id="Category_Id" value="<?php echo e($Category->Category_ID); ?>">
</div>
    <div>
    <label for="Category_Name"> Category_Name</label>
    <input type="text" name="Category_Name" id="Category_Name" value="<?php echo e($Category->Category_Name); ?>">
    </div>
    <div>
    <label for="Description"> Description</label>
    <input type="text" name="Description" id="Description" value="<?php echo e($Category->Description); ?>">
    </div>
    
    <button type="submit">Save </button>
</div>
</form>
<?php endif; ?><?php /**PATH C:\wamp\www\Projects\ABC3\ABC_hosted\resources\views\Category\CategoryEdit.blade.php ENDPATH**/ ?>