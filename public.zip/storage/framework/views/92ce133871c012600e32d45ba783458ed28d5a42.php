
<?php if($Category->count()): ?>

<table>
    <tr>
        <td>
            Category _id
        </td>
        <td>
            Category _Name
        </td>
        <td>
            Description
        </td>
        <!-- <td>
            Status
        </td> -->
        <td>
              
        </td>
        <td>
               
        </td>
    </tr>
    <?php $__currentLoopData = $Category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoryItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td>
            <?php echo e($categoryItem->Category_ID); ?>

        </td>
        <td>
            <?php echo e($categoryItem->Category_Name); ?>

        </td>
        <td>
            <?php echo e($categoryItem->Description); ?>

        </td>
        <!-- <td>
            <?php echo e($categoryItem->Status); ?> 
        </td> -->
        
        <td>
           <a href="/category/<?php echo e($categoryItem->Category_ID); ?>/edit" > <button  >Edit</button> </a>   
        </td>
        <td>
            <a href="/category/<?php echo e($categoryItem->Category_ID); ?>"><button  >Delete</button>  </a>  
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<?php else: ?>

<h1>No Categories to display</h1>
<h2>Please add Categories</h2>

<?php endif; ?>

<a href="category/create"><button>Add Category</button></a>
    
<?php /**PATH C:\wamp\www\Projects\ABC3\ABC_hosted\resources\views\Category\CategoryHome.blade.php ENDPATH**/ ?>