



<?php $__env->startSection('content'); ?>
<link href="<?php echo e(asset('extra_css/ranger.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('extra_css/jquery-ui.css')); ?>" rel="stylesheet">
<div>
    <div class="productpageimagecontainer w-container">
      <h1 class="mainheading">Explore Our collections</h1>
    </div>
  </div>
  <div class="container-30 w-container">
    <div class="div-block-71">
      <div class="div-block-59">
        <h3 data-w-id="51e7688d-dc9a-f7af-24dd-ef06a825201e" class="heading-13">Our Products</h3>
        <div data-w-id="797d9cf3-b8fa-e37a-6643-b88327865aaa" style="width:0PX;height:0PX">
          <div data-w-id="623fcbdf-e1b1-6b49-413b-865856a2b503" style="width:0PX;height:0PX" class="div-block-58">
            <div data-w-id="5ced1108-e704-6224-a4ce-e16e83f5562c" style="opacity:0;width:0PX;height:0PX">Category</div>
            <div data-hover="" data-delay="0" data-w-id="17c5a2e8-9d33-ae72-2d07-79124de73b42" style="opacity:0;width:0PX;height:0PX" class="w-dropdown">
              <div class="w-dropdown-toggle">
                <div class="w-icon-dropdown-toggle"></div>
                <div>Please Select Category</div>
              </div>
              <nav class="w-dropdown-list">
                <div class="w-dyn-list">
                  <div role="list" class="w-dyn-items">
                    <div role="listitem" class="w-dyn-item"><a href="#" class="w-dropdown-link"></a></div>
                  </div>
                  <div class="w-dyn-empty">
                    <div>No items found.</div>
                  </div>
                </div>
              </nav>
            </div>
          </div>
          <div data-w-id="6a58f455-0f22-0c39-3948-b2bcff196f5c" style="width:0PX;height:0PX">
            <div data-w-id="6a58f455-0f22-0c39-3948-b2bcff196f72" style="opacity:0;width:0PX;height:0PX"> Product</div>
            <div class="subcategory-div"><a href="#" class="button-3 w-button">Sub Category</a><a href="#" class="button-3 w-button">Sub Category</a><a href="#" class="button-3 w-button">Sub Category</a><a href="#" class="button-3 w-button">Sub Category</a><a href="#" class="button-3 w-button">Sub Category</a><a href="#" class="button-3 w-button">Sub Category</a></div>
          </div>
          <div data-w-id="9fc82de8-2f34-1fcd-ebc6-2d211eaca595" style="width:0PX;height:0PX">
            <div data-w-id="9fc82de8-2f34-1fcd-ebc6-2d211eaca5a4" style="opacity:0;width:0PX;height:0PX"> Brand</div>
            <div class="branddiv"><a href="#" class="button-3 w-button">Brand</a><a href="#" class="button-3 w-button">Brand</a><a href="#" class="button-3 w-button">Brand</a><a href="#" class="button-3 w-button">Brand</a><a href="#" class="button-3 w-button">Brand</a></div>
          </div>
        </div>
      </div>
      <!-- price Ranger -->
      <!-- <div class="div-block-59">
        <h3 class="heading-13">Price Range</h3>
        <div>Select your Price Range:</div>
        <div id="slider-min" class="price-ranger" style="display:block">
                <-- my price ranger code --
                <div id="slider-range1" class="price-filter-range" name="rangeInput">
                </div>  
                <input type="number" min=0 max="9900" oninput="validity.valid||(value='0');" id="min_price" class="price-range-field" />
                <input type="number" min=0 max="10000" oninput="validity.valid||(value='10000');" id="max_price" class="price-range-field" />
                <br>
                <div>
                <button class="price-range-search" id="price-range-submit" onclick="search()">Search</button>
                </div>
                


                <div id="searchResults" class="search-results-block" ></div>

<-- end of price ranger code --


            </div>
      </div> -->
      <!-- end of price ranger -->
      <div class="div-block-59">
        <h3 class="heading-13">Colour</h3>
        <div class="div-block-58">
          <div class="div-block-60"></div>
          <div class="greycolourblock"></div>
          <div class="ash-colour-block"></div>
          <div class="blackcolourblock"></div>
          <div class="div-block-60"></div>
        </div>
      </div>
    </div>
    <div class="div-block-54">
      <div class="div-block-59">
        <h3 class="heading-13">Our Products</h3><a href="product-exploration.html" aria-current="page" class="link-8 w--current">All Products</a>
        <div class="w-dyn-list">
          <div role="list" class="collection-list-16 w-dyn-items">
            <div role="listitem" class="w-dyn-item"><a href="#" class="link-8"></a></div>
          </div>
          <div class="w-dyn-empty">
            <div>No items found.</div>
          </div>
        </div>
      </div>
      <!-- price Ranger -->
      <div class="div-block-59">
        <h3 class="heading-13">Price Range</h3>
        <div>Select your Price Range:</div>
        <div id="slider-min" class="price-ranger" style="display:block">
                <!-- my price ranger code -->
                <div id="slider-range" class="price-filter-range" name="rangeInput">
                </div>  
                <input type="number" min=0 max="9900" oninput="validity.valid||(value='0');" id="min_price" class="price-range-field" />
                <input type="number" min=0 max="10000" oninput="validity.valid||(value='10000');" id="max_price" class="price-range-field" />
                <br>
                <div>
                <button class="price-range-search" id="price-range-submit" onclick="search()">Search</button>
                </div>
                


                <div id="searchResults" class="search-results-block" ></div>

<!-- end of price ranger code -->


            </div>
      </div>
      <!-- end of price ranger -->
      <div class="div-block-59">
        <h3 class="heading-13">Colour</h3>
        <div class="div-block-58">
          <div class="div-block-60"></div>
          <div class="greycolourblock"></div>
          <div class="ash-colour-block"></div>
          <div class="blackcolourblock"></div>
          <div class="div-block-60"></div>
        </div>
      </div>
      <div class="div-block-59">
        <h3 class="heading-13">Our Brands</h3>
        <div class="div-block-58"><a href="#" class="link-8">Becken</a><a href="#" class="link-8-copy">20</a></div>
        <div class="div-block-58"><a href="#" class="link-8">BathX</a><a href="#" class="link-8-copy">20</a></div>
        <div class="div-block-58"><a href="#" class="link-8">Viceroy</a><a href="#" class="link-8">20</a></div>
        <div class="div-block-58"><a href="#" class="link-8">Granitogres</a><a href="#" class="link-8-copy">20</a></div>
        <div class="div-block-58"><a href="#" class="link-8">Deko</a><a href="#" class="link-8-copy">20</a></div>
        <div class="div-block-58"><a href="#" class="link-8">Inox</a><a href="#" class="link-8-copy">20</a></div>
      </div>
    </div>
    <div class="div-block-72">
      <div class="div-block-59">
        <h3 class="heading-13">Our Products</h3>
        <div>
          <div><a href="#">Bath tub</a><a href="#">56</a></div>
          <div><a href="#">Ceramics</a><a href="#">35</a></div>
          <div><a href="#">Basins</a><a href="#">20</a></div>
          <div><a href="#">Kitchen Sink</a><a href="#">20</a></div>
          <div><a href="#">Water Closets</a><a href="#">100</a></div>
          <div><a href="#">Faucets</a><a href="#">100</a></div>
        </div>
      </div>
      <div class="div-block-59">
        <h3 class="heading-13">Price Range</h3>
        <div>
          <div id="slider-range-min" class="price-ranger"></div>
        </div>
      </div>
      <div class="div-block-59">
        <h3 class="heading-13">Colour</h3>
        <div>
          <div>
            <div class="div-block-60"></div>
            <div class="greycolourblock"></div>
            <div class="ash-colour-block"></div>
            <div class="blackcolourblock"></div>
            <div class="div-block-60"></div>
          </div>
        </div>
      </div>
      <div class="div-block-59">
        <h3 class="heading-13">Our Brands</h3>
        <div>
          <div><a href="#">Becken</a><a href="#">20</a></div>
          <div><a href="#">BathX</a><a href="#">20</a></div>
          <div><a href="#">Viceroy</a><a href="#">20</a></div>
          <div><a href="#">Granitogres</a><a href="#">20</a></div>
          <div><a href="#">Deko</a><a href="#">20</a></div>
          <div><a href="#">Inox</a><a href="#">20</a></div>
        </div>
      </div>
    </div>
    <div class="w-layout-grid product-display-grid">
      <div class="product-display-div">
        <div class="div-block-55">
          <a href="#" class="combocolorandavoidunderline w-inline-block">
            <div class="div-block-70"><img height="235" width="400" src="https://d3e54v103j8qbb.cloudfront.net/plugins/Basic/assets/placeholder.60f9b1840c.svg" data-w-id="437c5c3e-61c4-24a8-550f-2bf0e3b35adc" alt="" class="image-39"></div>
            <div class="text-block-26 combocolor">This is some text inside of a div block.</div>
          </a>
        </div>
        <div class="fav-cart">
          <div class="fav"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/002-love.svg" width="22" height="22" alt="" class="favimage">
            <div class="text-block-25">Like</div>
          </div>
          <div class="addtocartbutton"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Shoplist-Ikea-rzk-version.svg" width="19" height="19" alt="" class="image-40">
            <div class="addtocarttext">Add To Cart</div>
          </div>
        </div>
      </div>
      <div class="product-display-div">
        <div class="div-block-55">
          <a href="#" class="combocolorandavoidunderline w-inline-block">
            <div class="div-block-70"><img height="235" width="400" src="https://d3e54v103j8qbb.cloudfront.net/plugins/Basic/assets/placeholder.60f9b1840c.svg" data-w-id="abce45f6-a62f-fd7b-f3b6-5e2e6c07e4a4" alt="" class="image-39"></div>
            <div class="text-block-26 combocolor">This is some text inside of a div block.</div>
          </a>
        </div>
        <div class="fav-cart">
          <div class="fav"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/002-love.svg" width="22" height="22" alt="" class="favimage">
            <div class="text-block-25">Like</div>
          </div>
          <div class="addtocartbutton"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Shoplist-Ikea-rzk-version.svg" width="19" height="19" alt="" class="image-40">
            <div class="addtocarttext">Add To Cart</div>
          </div>
        </div>
      </div>
    </div>
  </div>






  <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery-ui.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/ranger.js')); ?>"></script>
    <script>
        function search(){
            var min_price = $('#min_price').val();
                var max_price = $('#max_price').val();
                
                $("searchResults").text("Here List of products will be shown which are cost between " + min_price  +" "+ "and" + " "+ max_price + ".");
                alert("hi inside search function");
        }
    </script>

<?php $__env->stopSection(); ?>

    
<?php echo $__env->make('Layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\Projects\ABC3\ABC_hosted\resources\views\product\productExplore.blade.php ENDPATH**/ ?>