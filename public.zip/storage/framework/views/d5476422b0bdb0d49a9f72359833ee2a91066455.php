<form action="/category" method="post">
    
    <?php echo csrf_field(); ?>
<div class="box">
<div>
<label for="Category_ID"> Category_Id</label>
    <input type="text" name="Category_ID" id="Category_ID" value="">
</div>
    <div>
    <label for="Category_Name"> Category_Name</label>
    <input type="text" name="Category_Name" id="Category_Name" value="">
    </div>
    <div>
    <label for="Description"> Description</label>
    <input type="text" name="Description" id="Description" value="">
    </div>
    
    <button type="submit">Save </button>
</div>
</form>
<?php if($errors->any()): ?>
    <?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <span style="color:red"><?php echo e($err); ?> </span>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?><?php /**PATH C:\wamp\www\Projects\ABC3\ABC_hosted\resources\views\Category\CategoryAdd.blade.php ENDPATH**/ ?>