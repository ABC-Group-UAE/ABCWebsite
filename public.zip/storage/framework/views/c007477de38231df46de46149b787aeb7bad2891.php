<style>
.sf-rib-scroller {
    display: flex;
    align-items: center;
    height: 48px;
    min-height: 0;
    padding: 0;
    border-bottom: 2px solid #ddd;
    background-color: #fff;
    -ms-overflow-style: none;
}
.s-mobile-toolbar {
    min-height: 44px;
    padding-top: 6px;
    padding-bottom: 6px;
    background-color: #fff;
    border-bottom: 2px solid #ddd;
    transition: .2s linear;
}
.a-scroller-horizontal {
    overflow-y: hidden;
}
.a-scroller {
    width: 10%;
    height: 100%;
    overflow: auto;
    -webkit-overflow-scrolling: touch;
}
* {
    -moz-box-sizing: border-box;
    /* -webkit-box-sizing: border-box; */
    /* box-sizing: border-box; */
}

.sf-rib-scroller::-webkit-scrollbar {
    display: none;
}
.sf-rib-scroller .sf-rib-element:first-child {
    padding-left: 8px;
}
.a-nowrap, .aok-nowrap {
    white-space: nowrap;
}
.a-section {
    margin-bottom: 1.3rem;
}
.a-spacing-none, .a-ws .a-ws-spacing-none {
    /* margin-bottom: 0!important; */
}
* {
    -moz-box-sizing: border-box;
    /* -webkit-box-sizing: border-box; */
    /* box-sizing: border-box; */
}
div {
    display: block;
}



</style>


<div class="a-scroller sf-rib-scroller s-mobile-toolbar a-scroller-horizontal">
                
                <div class="a-section a-spacing-none sf-rib-element aok-nowrap">
                    






                </div>
                
                
     </div>           
                    
                        
                        
                            






<div class="a-section a-spacing-none sf-rib-element aok-nowrap">
    <span class="a-declarative" data-action="super-filter-pill" data-super-filter-pill="{}">
        <span id="intermediateRefinements" tabindex="0" class="sf-rib-all-filters sf-mobile-filter-element " aria-pressed="false" role="button">
            
                <span class="a-size-small a-color-base" dir="auto">Delivery</span>
            
            <i class="a-icon sf-rib-triangle" role="img"></i>
        </span>
    </span>
</div>

                        
                            






<div class="a-section a-spacing-none sf-rib-element aok-nowrap">
    <span class="a-declarative" data-action="super-filter-pill" data-super-filter-pill="{}">
        <span id="s-all-filters" tabindex="0" class="sf-rib-all-filters sf-mobile-filter-element sf-rib-truncate" aria-pressed="false" role="button">
            
                <span class="a-size-small a-color-base" dir="auto">Accessories</span>
            
            <i class="a-icon sf-rib-triangle" role="img"></i>
        </span>
    </span>
</div>

                        
                            






<div class="a-section a-spacing-none sf-rib-element aok-nowrap">
    <span class="a-declarative" data-action="super-filter-pill" data-super-filter-pill="{}">
        <span id="departments" tabindex="0" class="sf-rib-all-filters sf-mobile-filter-element sf-rib-label-selected" aria-pressed="false" role="button">
            
                <span class="a-size-small a-color-base" dir="auto">Category</span>
            
                <span class="a-size-small a-color-state" dir="auto">(1)</span>
            
            <i class="a-icon sf-rib-triangle" role="img"></i>
        </span>
    </span>
</div>

                        
                            






<div class="a-section a-spacing-none sf-rib-element aok-nowrap">
    <span class="a-declarative" data-action="super-filter-pill" data-super-filter-pill="{}">
        <span id="brandsRefinements" tabindex="0" class="sf-rib-all-filters sf-mobile-filter-element " aria-pressed="false" role="button">
            
                <span class="a-size-small a-color-base" dir="auto">Brand</span>
            
            <i class="a-icon sf-rib-triangle" role="img"></i>
        </span>
    </span>
</div>

                        
                            






<div class="a-section a-spacing-none sf-rib-element aok-nowrap">
    <span class="a-declarative" data-action="super-filter-pill" data-super-filter-pill="{}">
        <span id="reviewsRefinements" tabindex="0" class="sf-rib-all-filters sf-mobile-filter-element " aria-pressed="false" role="button">
            
                <span class="a-size-small a-color-base" dir="auto">Review</span>
            
            <i class="a-icon sf-rib-triangle" role="img"></i>
        </span>
    </span>
</div>

                        
                            






<div class="a-section a-spacing-none sf-rib-element aok-nowrap">
    <span class="a-declarative" data-action="super-filter-pill" data-super-filter-pill="{}">
        <span id="priceRefinements" tabindex="0" class="sf-rib-all-filters sf-mobile-filter-element " aria-pressed="false" role="button">
            
                <span class="a-size-small a-color-base" dir="auto">Price</span>
            
            <i class="a-icon sf-rib-triangle" role="img"></i>
        </span>
    </span>
</div>

                        
                            






<div class="a-section a-spacing-none sf-rib-element aok-nowrap">
    <span class="a-declarative" data-action="super-filter-pill" data-super-filter-pill="{}">
        <span id="sorts" tabindex="0" class="sf-rib-all-filters sf-mobile-filter-element " aria-pressed="false" role="button">
            
                <span class="a-size-small a-color-base" dir="auto">Sort by: Featured</span>
            
            <i class="a-icon sf-rib-triangle" role="img"></i>
        </span>
    </span>
</div>

                        
                    
                    
                
            </div><?php /**PATH C:\wamp\www\Projects\ABC3\ABC_hosted\resources\views\scrollableDiv.blade.php ENDPATH**/ ?>