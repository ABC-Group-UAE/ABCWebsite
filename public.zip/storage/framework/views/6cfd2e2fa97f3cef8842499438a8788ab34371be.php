
<?php $__env->startSection('extra-css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>




<div class="container-21 combo w-container">
	<h1 class="mainheading">your Shoplist</h1>
</div>
<div class="main-container w-container" id ="ShopList">
	

	<?php     
	use App\Product;
	$SId = Session::get('id');
	if(\Cart::session($SId)->isEmpty()) {

		$message ="Cart is Empty... Please Continue shopping";
		?>
		<h1 id = "message"> <?php echo e($message); ?></h1>

	<?php  } else{    ?>
		<div id ="CARTLIST">
			<div><h1>CART</h1></div>

			<div class="heading-div">
				<div class="div-block-78">
					<div>
						<h4>Product Added to the ShopList</h4>
					</div>
					<div>
						<h4>Quantity</h4>
					</div>
					<div>
						<h4 class="heading-23">Quantity</h4>
					</div>
					<div>
						<h4 class="heading-23">Price</h4>
					</div>
				</div>
			</div>
		</div>
		<form id="cartUpdate" name="email-form" data-name="Email Form" class="form-4">
			<?php echo csrf_field(); ?>
			<div class="w-layout-grid cart-list" id="Cart" name="Cart">

				<?php 
				if( !($cartContent->isEmpty())){
					$row = 0;
					$rowcount = $cartContent->count();
					$subTotal = \Cart::session($SId)->getSubTotal();
					$vat = 0.05* $subTotal;
					$Total = $vat+$subTotal;

					?>
					<input type="hidden" name="rowcount" id="rowcount" value=<?php echo e($rowcount); ?>>
					<?php
					foreach($cartContent as $item){
						$row++;
						$product = Product::find($item->id);
						$summedPrice = \Cart::session($SId)->get($item->id)->getPriceSum();


						
						?>
						<div id="<?php echo e('row'.$row); ?>">
							<div class="div-block-76 w-clearfix">
								<div class="div-block-90">
									<div class="div-block-75">
										<!-- style="background:url('https://abccontentbucket.s3.me-south-1.amazonaws.com/images/<?php echo e($product->MainImage)); ?>') ;background-position:'0px 0px, 50% 50%' ; background-size: auto, cover; background-repeat:no-repeat" id = "<?php echo e('Productpic_'.$row); ?>"> -->
										<a href=" <?php echo e(route('Product.description',$product->Product_id)); ?>" ><img src= "https://abccontentbucket.s3.me-south-1.amazonaws.com/images/<?php echo e($product->MainImage)); ?>" id = "<?php echo e('Productpic_'.$row); ?>" name = "<?php echo e('Productpic_'.$row); ?>"> 
										</a></div>
										<div><a href=" <?php echo e(route('Product.description',$product->Product_id)); ?>" ><?php echo e($product->product_name); ?></div></a>
									</div>
									<div class="div-block-89">
										<div class="w-form">
											
											
											<input type="hidden" name="<?php echo e('productId_'.$row); ?>" id="<?php echo e('productId_'.$row); ?>" value="<?php echo e($product->Product_id); ?>">
											<input type="text" class="text-field-3 w-input" maxlength="256" name="<?php echo e('qtyText'.$row); ?>" id="<?php echo e('qtyText'.$row); ?>" data-name="Name" 
											value= "<?php echo e($item->quantity); ?>"  onChange="UpdateCartQuantity(<?php echo e($row); ?>,event) ">
											
										</div>
									</div>
									<div >
										<label id = "<?php echo e('price_'.$row); ?>" name="<?php echo e('price_'.$row); ?>"> AED <?php echo e($summedPrice); ?> </label> 
									</div>
									<a id="<?php echo e('delete_'.$row); ?>" href=""   class="close" onClick="RemoveFromCart(<?php echo e($row); ?>,event)">+</a>


								</div>
								<div class="grey-divider-div"></div>
							</div>
							


							<?php

						}
						?>                              </div>
						<div id="priceDetails">
							<div style="float:right;display:flex"> 

								<label>SubTotal</label>
								<label id="subtotal"><?php echo e($subTotal); ?></label>
							</div><br>

							<div style="float:right;display:flex"> 

								<label>VAT included</label>
								<label id="tax"><?php echo e($vat); ?></label>
							</div><br>
							<div style="float:right;display:flex"> 

								<label>Grand Total</label>
								<label id="grandtotal"><?php echo e($Total); ?></label>
							</div><br>

						</div>
						


						<?php 
					}

					?>

					
				</form>  
				<div class="button-div"><a data-w-id="058c16d4-5fe2-d8eb-62df-fa46370ee06d" href="#" class="buttonclass-copy combostyle w-button">Get A Quote</a></div>
				<?php 
			}


			?>
			<!-- starting code for wishList -->
			<?php     
			if( !($wishListContent->isEmpty())) {
				?>
				<div id ="FAVLIST" >
					<div><h1>FAVOURITE LIST</h1></div>
					<div class="heading-div">
						<div class="div-block-78">
							<div>
								<h4>Product</h4>
							</div>
							<div>
								<h4>Quantity</h4>
							</div>
							<div>
								<h4 class="heading-23">Quantity</h4>
							</div>
							<div>
								<h4 class="heading-23">Price</h4>
							</div>
						</div>
					</div>
				</div>
				<form id="wishList" name="wishList" data-name="wishList" class="wishList">
					<?php echo csrf_field(); ?>
					<div class="w-layout-grid cart-list" id="WishCart" name="WishCart">

						<?php 
						if( !($wishListContent->isEmpty())){
							$row = 0;
							$rowcount = $wishListContent->count();
							?>
							<input type="hidden" name="rowcount" id="rowcount" value=<?php echo e($rowcount); ?>>
							<?php
							foreach($wishListContent as $item){
								$row++;
								$product = Product::find($item->id);
								$summedPrice =0;
								$summedPrice = app('wishlist')->get($item->id)->getPriceSum();

								
								?>
								<div id="<?php echo e('Wishrow'.$row); ?>">
									<div class="div-block-76 w-clearfix">
										<div class="div-block-90">
											<div class="div-block-75" style="background:url('https://abccontentbucket.s3.me-south-1.amazonaws.com/images/<?php echo e($product->MainImage)); ?>') ;background-position:'0px 0px, 50% 50%' ; background-size: auto, cover; background-repeat:no-repeat" id = "<?php echo e('WishProductpic_'.$row); ?>"></div>
											<div><?php echo e($product->product_name); ?></div>
										</div>
										<div class="div-block-89">
											<div class="w-form">
												
												
												<input type="hidden" name="<?php echo e('WishproductId_'.$row); ?>" id="<?php echo e('WishproductId_'.$row); ?>" value="<?php echo e($product->Product_id); ?>">
												<input type="text" class="text-field-3 w-input" maxlength="256" name="<?php echo e('WishqtyText'.$row); ?>" id="<?php echo e('WishqtyText'.$row); ?>" data-name="Name" 
												value= "<?php echo e($item->quantity); ?>"  onChange="UpdateWishListQuantity(<?php echo e($row); ?>,event)">
												
											</div>
										</div>
										<div >
											<label id = "<?php echo e('Wishprice_'.$row); ?>" name="<?php echo e('Wishprice_'.$row); ?>"> AED <?php echo e($summedPrice); ?> </label> 
										</div>
										<a id="<?php echo e('Wishdelete_'.$row); ?>" href=""   class="close" onClick="RemoveFromWishList(<?php echo e($row); ?>,event)">+</a>
										<div id = "<?php echo e('WishAddCart_'.$row); ?>" style="width:30%"  onClick="addFromWishListToCart(<?php echo e($row); ?>,'ShopList',event)"><a  href="#" class="buttonclass-copy combostyle hereonly w-button">Add To Cart</a></div>

									</div>
									<div class="grey-divider-div"></div>
								</div>


								<?php

							}
						}

						?>

					</div>
				</form>


				<?php
			}
			?>
			<!-- ending of whishList -->






			


			
		</div>
		<?php echo $__env->make('Common.SimilarProducts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php $__env->stopSection(); ?>

		<?php $__env->startSection('extra-js'); ?>
		<script>
			function UpdateCartQuantity(rowid,e){
				e.preventDefault();
		   // e.stopP
		   alert("Hi inside js function");
		   var productId = $('#productId_'+rowid).val();
			//alert(productId);'qtyText'.$row
			var quantity = $('#qtyText'+rowid).val();
			alert(quantity);
			var url = "<?php echo e(route('Cart.Update')); ?>";
			var _token = '<?php echo csrf_token() ?>';
			alert(url);
			alert(_token);
			$.ajax(

			{
				type: "post",
				url: url,
				data: {   
					id: productId,
					Quantity: quantity,
					_token  :_token
				},
				success:function(result,e) {
				   // alert(result.message+"and"+ result.count+"and"+ result.success );
				   alert("price" + result.cartitem);
				   $('#price_'+ rowid).text("AED "+result.summedPrice);
				   console.log(result);
				   console.log(result.data);
				   console.log(result.message);
				   console.log(result.count);
					// if(result.count > 0){
					//   $("#cartCount").css('display','inline');
					//   $("#cartCountText").text(result.count);
					
					// }else{
					//   $("#cartCount").css('display','none');
					// }
					if($("#priceDetails"). length){
						$("#subtotal").text(result.subTotal);
						$("#tax").text(result.vat);
						$("#grandtotal").text(result.Total);
					} 
					
					// e.preventDefault();
					
				},
				error:function(result) {
					alert('error');
					console.log(result);

				}
			});

		}

		function RemoveFromCart(rowid,e){
			e.preventDefault();
		   // e.stopP
		   alert("Hi inside js function");
		   var productId = $('#productId_'+rowid).val();
			//alert(productId);'qtyText'.$row
			var quantity = $('#qtyText'+rowid).val();
			//alert(quantity);
			var url = "<?php echo e(route('Cart.Remove')); ?>";
			var _token = '<?php echo csrf_token() ?>';
		   // alert(url);
			//alert(_token);
			$.ajax(

			{
				type: "post",
				url: url,
				data: {   
					id: productId,
					
					_token  :_token
				},
				success:function(result,e) {
				   // alert(result.message+"and"+ result.count+"and"+ result.success );
				   console.log(result);
				   console.log(result.data);
				   console.log(result.message);
				   console.log(result.count);
				   var rowidd = parseInt(rowid);
				   var count= parseInt(result.count);
				   if(rowidd == count ){
					alert(" roe id == count row ID ="+rowidd);
					$("#row"+ rowidd).remove();
					if($("#row"+(rowidd+1)). length){
						$("#row"+(rowidd+1)).prop('id','row'+(rowidd));
						$("#row"+(rowidd+1)).prop('name', 'row'+(rowidd));
					} 
					if($("#Productpic_"+(rowidd+1)). length){
						$("#Productpic_"+(rowidd+1)).prop('name', 'Productpic_'+(rowidd));
						$("#Productpic_"+(rowidd+1)).prop('id','Productpic_'+(rowidd));
					} 
					if($("#productId_"+(rowidd+1)). length){
						$("#productId_"+(rowidd+1)).prop('name', 'productId_'+(rowidd));
						$("#productId_"+(rowidd+1)).prop('id','productId_'+(rowidd));
					} 
					if($("#qtyText"+(rowidd+1)). length){
						$("#qtyText"+(rowidd+1)).prop('name', 'qtyText'+(rowidd));
						$("#qtyText"+(rowidd+1)).prop('id','qtyText'+(rowidd));
						$("#qtyText"+(rowidd)).removeAttr('onchange');
						$("#qtyText"+(rowidd)).attr("onChange","UpdateCartQuantity('"+rowidd+"', event)"); 
					}
					if($("#price_"+(rowidd+1)). length){
						$("#price_"+(rowidd+1)).prop('name', 'price_'+(rowidd));
						$("#price_"+(rowidd+1)).prop('id','price_'+(rowidd));
					}
					if($("#delete_"+(rowidd+1)). length){
						$("#delete_"+(rowidd+1)).prop('id','delete_'+(rowidd));
						$("#delete_"+(rowidd)).removeAttr('onclick');
						$("#delete_"+(rowidd)).attr("onClick","RemoveFromCart('"+rowidd+"', event)");
					} 
					if($("#priceDetails"). length){
						$("#subtotal").text(result.subTotal);
						$("#tax").text(result.vat);
						$("#grandtotal").text(result.Total);
					} 
					
				   }else if(rowidd < count ){
					alert(" less than count row ID ="+rowidd);
					$("#row"+ rowidd).remove();
					for(var i=rowidd; i<=count ; i++)
					{
						alert(" inside for loop row ID ="+i);
						if($("#row"+(i+1)). length)
						{
							$("#row"+(i+1)).prop('id','row'+(i));
							$("#row"+(i+1)).prop('name', 'row'+(i));
						} 
						if($("#Productpic_"+(i+1)). length)
						{
							$("#Productpic_"+(i+1)).prop('name', 'Productpic_'+(i));
							$("#Productpic_"+(i+1)).prop('id','Productpic_'+(i));
						} 
						if($("#productId_"+(i+1)). length)
						{
							$("#productId_"+(i+1)).prop('name', 'productId_'+(i));
							$("#productId_"+(i+1)).prop('id','productId_'+(i));
						} 
						if($("#qtyText"+(i+1)). length)
						{
							$("#qtyText"+(i+1)).prop('name', 'qtyText'+(i));
							$("#qtyText"+(i+1)).prop('id','qtyText'+(i));
							$("#qtyText"+(i)).removeAttr('onchange');
							$("#qtyText"+(i)).attr("onchange","UpdateCartQuantity('"+i+"', event)"); 
						}
						if($("#price_"+(i+1)). length)
						{
							$("#price_"+(i+1)).prop('name', 'price_'+(i));
							$("#price_"+(i+1)).prop('id','price_'+(i));
						}  
						if($("#delete_"+(i+1)). length)
						{
							alert("#delete_"+(i+1));
							$("#delete_"+(i+1)).prop('id','delete_'+(i));
							alert("#delete_"+(i));
							$("#delete_"+(i)).removeAttr('onclick');
							$("#delete_"+(i)).attr("onclick","RemoveFromCart('"+i+"', event)");
						} 

					}

					if($("#priceDetails"). length){
						$("#subtotal").text(result.subTotal);
						$("#tax").text(result.vat);
						$("#grandtotal").text(result.Total);
					} 

				   }else{
					$("#row"+ rowid).remove();
				   }
					//$("#row"+ rowid).css('display','none');
					
					if(result.count > 0){
						if($("#shopmsg"). length)
						{
							$("#shopmsg").remove();
							
						}
						$("#cartCount").css('display','inline');
						$("#cartCountText").text(result.count);
						if($("#priceDetails"). length){
							$("#subtotal").text(result.subTotal);
							$("#tax").text(result.vat);
							$("#grandtotal").text(result.Total);
						} 
						
					}else{
						$("#cartCount").css('display','none');
						$("#Cart").remove();
						$("#CARTLIST").remove();
						$("#priceDetails").remove();
					   // $("#subtotal").remove();
					   // $("#tax").remove();
					   // $("#grandtotal").remove();
					   $("<h1 id='shopmsg'>No Items found in your Cart </h1>").appendTo("#ShopList");

				   }
				   
				   
					// e.preventDefault();
					
				},
				error:function(result) {
					alert('error');
					console.log(result);

				}
			});

}

function UpdateWishListQuantity(rowid,e){
	e.preventDefault();
		   // e.stopP
		   alert("Hi inside js function");
		   var productId = $('#WishproductId_'+rowid).val();
			//alert(productId);'qtyText'.$row
			var quantity = $('#WishqtyText'+rowid).val();
			alert(quantity);
			var url = "<?php echo e(route('Favourite.Update')); ?>";
			var _token = '<?php echo csrf_token() ?>';
			alert(url);
			alert(_token);
			$.ajax(

			{
				type: "post",
				url: url,
				data: {   
					id: productId,
					Quantity: quantity,
					_token  :_token
				},
				success:function(result,e) {
				   // alert(result.message+"and"+ result.count+"and"+ result.success );
					// alert("price" + result.cartitem);
					// $('#price_'+ rowid).text("AED "+result.summedPrice);
					alert("price" + result.cartitem);
					$('#Wishprice_'+ rowid).text("AED "+result.summedPrice);
					console.log(result);
					console.log(result.data);
					console.log(result.message);
					console.log(result.count);
					// if(result.count > 0){
					//   $("#cartCount").css('display','inline');
					//   $("#cartCountText").text(result.count);
					
					// }else{
					//   $("#cartCount").css('display','none');
					// }

					
					// e.preventDefault();
					
				},
				error:function(result) {
					alert('error');
					console.log(result);

				}
			});

		}

		function RemoveFromWishList(rowid,e){
			e.preventDefault();
		   // e.stopP
		   alert("Hi inside js function");
		   var productId = $('#WishproductId_'+rowid).val();
			//alert(productId);'qtyText'.$row
			var quantity = $('#WishqtyText'+rowid).val();
			alert(quantity);
			var url = "<?php echo e(route('Favourite.Remove')); ?>";
			var _token = '<?php echo csrf_token() ?>';
			alert(url);
			alert(_token);
			$.ajax(

			{
				type: "post",
				url: url,
				data: {   
					id: productId,
					
					_token  :_token
				},
				success:function(result,e) {
				   // alert(result.message+"and"+ result.count+"and"+ result.success );
				   console.log(result);
				   console.log(result.data);
				   console.log(result.message);
				   console.log(result.count);
				   var rowidd = parseInt(rowid);
				   var count= parseInt(result.count);
				   if(rowidd == count ){
					alert(" row id == count row ID ="+rowidd);
					$("#Wishrow"+ rowidd).remove();
					if($("#Wishrow"+(rowidd+1)). length){
						$("#Wishrow"+(rowidd+1)).prop('id','Wishrow'+(rowidd));
						$("#Wishrow"+(rowidd+1)).prop('name', 'Wishrow'+(rowidd));
					} 
					if($("#WishProductpic_"+(rowidd+1)). length){
						$("#WishProductpic_"+(rowidd+1)).prop('name', 'WishProductpic_'+(rowidd));
						$("#WishProductpic_"+(rowidd+1)).prop('id','WishProductpic_'+(rowidd));
					} 
					if($("#WishproductId_"+(rowidd+1)). length){
						$("#WishproductId_"+(rowidd+1)).prop('name', 'WishproductId_'+(rowidd));
						$("#WishproductId_"+(rowidd+1)).prop('id','WishproductId_'+(rowidd));
					} 
					if($("#WishqtyText"+(rowidd+1)). length){
						$("#WishqtyText"+(rowidd+1)).prop('name', 'WishqtyText'+(rowidd));
						$("#WishqtyText"+(rowidd+1)).prop('id','WishqtyText'+(rowidd));
						$("#WishqtyText"+(rowidd)).removeAttr('onchange');
						$("#WishqtyText"+(rowidd)).attr("onChange","UpdateWishListQuantity('"+rowidd+"', event)"); 
					}
					if($("#Wishprice_"+(rowidd+1)). length){
						$("#Wishprice_"+(rowidd+1)).prop('name', 'Wishprice_'+(rowidd));
						$("#Wishprice_"+(rowidd+1)).prop('id','Wishprice_'+(rowidd));
					}
					if($("#Wishdelete_"+(rowidd+1)). length){
						$("#Wishdelete_"+(rowidd+1)).prop('id','Wishdelete_'+(rowidd));
						$("#Wishdelete_"+(rowidd)).removeAttr('onclick');
						$("#Wishdelete_"+(rowidd)).attr("onClick","RemoveFromWishList('"+rowidd+"', event)");
					} 
					if($("#WishAddCart_"+(rowidd+1)). length){
						$("#WishAddCart_"+(rowidd+1)).prop('id','WishAddCart_'+(rowidd));
						$("#WishAddCart_"+(rowidd)).removeAttr('onclick');
						$("#WishAddCart_"+(rowidd)).attr("onClick","addFromWishListToCart('"+rowidd+"','ShopList', event)");
					}
					
				   }else if(rowidd < count ){
					alert(" less than count row ID ="+rowidd);
					$("#Wishrow"+ rowidd).remove();
					for(var i=rowidd; i<=count ; i++)
					{
						alert(" inside for loop row ID ="+i);
						if($("#Wishrow"+(i+1)). length)
						{
							$("#Wishrow"+(i+1)).prop('id','Wishrow'+(i));
							$("#Wishrow"+(i+1)).prop('name', 'Wishrow'+(i));
						} 
						if($("#WishProductpic_"+(i+1)). length)
						{
							$("#WishProductpic_"+(i+1)).prop('name', 'WishProductpic_'+(i));
							$("#WishProductpic_"+(i+1)).prop('id','WishProductpic_'+(i));
						} 
						if($("#WishproductId_"+(i+1)). length)
						{
							$("#WishproductId_"+(i+1)).prop('name', 'WishproductId_'+(i));
							$("#WishproductId_"+(i+1)).prop('id','WishproductId_'+(i));
						} 
						if($("#WishqtyText"+(i+1)). length)
						{
							$("#WishqtyText"+(i+1)).prop('name', 'WishqtyText'+(i));
							$("#WishqtyText"+(i+1)).prop('id','WishqtyText'+(i));
							$("#WishqtyText"+(i)).removeAttr('onchange');
							$("#WishqtyText"+(i)).attr("onchange","UpdateWishListQuantity('"+i+"', event)"); 
						}
						if($("#Wishprice_"+(i+1)). length)
						{
							$("#Wishprice_"+(i+1)).prop('name', 'Wishprice_'+(i));
							$("#Wishprice_"+(i+1)).prop('id','Wishprice_'+(i));
						}  
						if($("#Wishdelete_"+(i+1)). length)
						{
							alert("#Wishdelete_"+(i+1));
							$("#Wishdelete_"+(i+1)).prop('id','Wishdelete_'+(i));
							alert("#Wishdelete_"+(i));
							$("#Wishdelete_"+(i)).removeAttr('onclick');
							$("#Wishdelete_"+(i)).attr("onclick","RemoveFromWishList('"+i+"', event)");
						} 
						if($("#WishAddCart_"+(i+1)). length)
						{
							$("#WishAddCart_"+(i+1)).prop('id','WishAddCart_'+(i));
							$("#WishAddCart_"+(i)).removeAttr('onclick');
							$("#WishAddCart_"+(i)).attr("onClick","addFromWishListToCart('"+i+"','ShopList', event)");
						}

					}



				   }else{
					if($("#favmsg"). length)
					{
						$("#favmsg").remove();
						
					}
					$("#Wishrow"+ rowid).remove();
				   }
				   if(result.count == 0){
					$("#FAVLIST").remove();
					$("#WishCart").remove();

					

					$("<h1 id='favmsg'>No Items found in your Favourite List </h1>").appendTo("#ShopList");
				   }
				   
					// e.preventDefault();
					
				},
				error:function(result) {
					alert('error');
					console.log(result);

				}
			});

}


function addFromWishListToCart(rowid, fromValue ,event){
	alert("hi from inside similar product product-image" + fromValue);
	event.preventDefault();
		  //alert(productId +" and "+fromValue);
		  var url = "<?php echo e(route('Cart.Add')); ?>";
		  var _token = '<?php echo csrf_token() ?>';
		  var productId = $('#WishproductId_'+rowid).val();
		  alert(productId);
			// 'qtyText'.$row
			var quantity = $('#WishqtyText'+rowid).val();
			alert(url);
			alert(_token);
			$.ajax({
				type: "post",
				url: url,
				data: {   
					id: productId,
					Quantity: quantity,
					_token  :_token
				},
				success:function(result,e) {
				   // alert(result.message+"and"+ result.count+"and"+ result.success );
				   console.log(result);
				   console.log(result.data);
				   console.log(result.message);
				   console.log(result.count);
					if(result.count > 0){ //checking cart is empty or not.. if not empty
					  //if not empty
					  $("#cartCount").css('display','inline');
					  $("#cartCountText").text(result.count);
					  
				  }else{
					  // if cart is empty
					  $("#cartCount").css('display','none');
				  }
				  alert("Before Adding View");
					 if(fromValue == "ShopList"){ //opening of from value checking if



						alert("Adding to Cart");



					if(!result.AlreadyAdded){// checking if the item already exist in cart
						  // do this if the item is new to the cart
								  if(! (jQuery.isEmptyObject(result.product))){ // checking the product detail container is empty or not
									//do this if it is not empty
									if(result.count > 0 && result.count == 1){// checking if the cart is empty and no cart div present in page
										  //console.log.(result.count);

										  // if Cart div is not present then including cart div that cart content is appending to the container and hiding cart empty message


										  $("#message").css('display','none');
										  var $html = $("<div id='CARTLIST'><div><h1>CART</h1></div><div class='heading-div'><div class='div-block-78'><div><h4>Product Added to the ShopList</h4></div><div><h4>Quantity</h4></div><div><h4 class='heading-23'>Quantity</h4></div>"
											+"<div><h4 class='heading-23'>Price</h4></div></div></div></div><form id='cartUpdate' name='email-form' data-name='Email Form' class='form-4'><input name='_token' value='"+_token+"' type='hidden'>"
											+"<div class='w-layout-grid cart-list' id='Cart' name='Cart'><div id='row"+result.count+"' style='display:inline'><div class='div-block-76 w-clearfix'><div class='div-block-90'>"
											+"<div class='div-block-75' id = 'Productpic_"+result.count+"'></div><div>"+ result.product.product_name +"</div></div><div class='div-block-89'><div class='w-form'><input  name='productId_"+result.count+"' id='productId_"+result.count+"' value='"+result.product.Product_id+"' type='hidden'>"
											+"<input type='text' class='text-field-3 w-input' maxlength='256' name='qtyText"+result.count+"' id='qtyText"+result.count+"' data-name='Name' value= '"+result.cartitem.quantity+"'  onChange='UpdateCartQuantity("+result.count+",event) '></div></div><div > <label id = 'price_"+result.count+"' name=price_"+result.count+"'> AED"+result.summedPrice+" </label> </div>"
											+"<a id ='delete_"+result.count+"' href=''   class='close' onClick='RemoveFromCart("+result.count+",event)'>+</a></div><div class='grey-divider-div'></div></div> </div><div id='priceDetails'><div style='float:right;display:flex'><label>SubTotal</label><label id='subtotal'>"+result.subTotal+"</label></div><br><div style='float:right;display:flex'><label>VAT included</label><label id='tax'>"+result.vat+"</label></div><br><div style='float:right;display:flex'><label>Grand Total</label><label id='grandtotal'>"+result.Total+"</label></div><br></div></form>");
										  newdiv2 = document.createElement( "div" ),
										   // existingdiv1 = $( "#ShopList" );
										   $( "#ShopList" ).append( $html);
										   $('#Productpic_'+ result.count).css("background-image", 'url(' + 'images/' + result.product.MainImage+ ')');
										   $('#Productpic_'+ result.count).css("background-repeat", 'no-repeat');
										   $('#qtyText'+ result.count).val(result.cartitem.quantity);
									   }
									   else
									   {


							  //if the cart div is present then appending product details to the existing cart div

							  var $temp = $("<div id='row"+result.count+"' style='display:inline'><div class='div-block-76 w-clearfix'><div class='div-block-90'><div class='div-block-75' id = 'Productpic_"+result.count+"'></div><div>"+ result.product.product_name +"</div></div><div class='div-block-89'><div class='w-form'> <input type='hidden' name='productId_"+result.count+"' id='productId_"+result.count+"' value='"+result.product.Product_id+"'><input type='text' class='text-field-3 w-input' maxlength='256' name='qtyText"+result.count+"' id='qtyText"+result.count+"' data-name='Name' value= '"+result.cartitem.quantity+"'  onChange='UpdateCartQuantity("+result.count+",event) '></div></div><div > <label id = 'price_"+result.count+"' name=price_"+result.count+"'> AED"+result.summedPrice+" </label> </div><a id ='delete_"+result.count+"' href=''  class='close'  onClick='RemoveFromCart("+result.count+",event)'>+</a></div><div class='grey-divider-div'></div></div> "); 
								//$( "#Cart" ).append( $temp );
								$temp.appendTo("#Cart");
									// newdiv2 = document.createElement( "div" ),
									// existingdiv1 = $( "#Cart" );
									// $( "body" ).append( $temp, [ newdiv2, existingdiv1 ] );
									$('#Productpic_'+ result.count).css("background-image", 'url(' + 'images/' + result.product.MainImage+ ')');
									$('#Productpic_'+ result.count).css("background-repeat", 'no-repeat');
									$('#qtyText'+ result.count).val(result.cartitem.quantity);
									if($("#priceDetails"). length){
										$("#subtotal").text(result.subTotal);
										$("#tax").text(result.vat);
										$("#grandtotal").text(result.Total);
									} 
								}

								alert("product fetched");  
								
							}//end of jQuery.isEmptyObject(result.product)))
						}else{
							alert("Hi inside cart existing quantity");
					  // do the following if the item already exist in cart
					  for(var i=1;i<=result.count;i++){
						var pid = $('#productId_'+i).val();
						  //alert("product id" + pid);
						  if(pid == result.product.Product_id){
							$('#qtyText'+ i).val(result.cartitem.quantity);
							$('#price_'+ i).text(result.summedPrice);
							if($("#priceDetails"). length){
								$("#subtotal").text(result.subTotal);
								$("#tax").text(result.vat);
								$("#grandtotal").text(result.Total);
							} 
							break;

						  }
					  }
					  alert("product fetched");
					  

				  }
				  
					} // close of from value checking if
					// e.preventDefault();
					RemoveFromWishList(rowid,event);
					
				  },//end of success function
				  error:function(result) {
					alert('error');
					console.log(result);

				  }
			  });

}

</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\Projects\ABC3\ABC_hosted\resources\views\cart\shoplist copy.blade.php ENDPATH**/ ?>