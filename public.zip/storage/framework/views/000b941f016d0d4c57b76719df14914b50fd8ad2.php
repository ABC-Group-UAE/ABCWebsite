
<!-- product gallery -->

    <link rel="stylesheet" type="text/css" href="extra_css/reset.css">
    <link rel="stylesheet" type="text/css" href="extra_css/jquery-picZoomer.css">
    
    <script type="text/javascript" src="src/jquery.picZoomer.js"></script>
    <!-- end of product gallery -->
<style>
    .piclist{
        margin-top: auto;
        margin-right: 10px;;
        display:flex;
        flex-direction: column;
    }
    .piclist li{
        display: inline-block;
        width: 50px;
        height: 50px;
        margin:3px;
    }
    .piclist li img{
        width: 100%;
        height: auto;
    }

    /* custom style */
    .picZoomer-pic-wp,
    .picZoomer-zoom-wp{
        border: 1px solid #fff;
    }


    
    </style>
    
    
    
<?php $__env->startSection('content'); ?>
  <!-- <?php $__env->startSection('extra-js'); ?> -->
    <!-- product gallery style -->
    
     <!--end of product gallery style -->
  <!-- <?php $__env->stopSection(); ?> -->
  <div class="container-32 w-container">
    <div class="w-layout-grid grid-17">
      <div id="w-node-839af9fdddca-0bc48b59" class="div-block-87">
        <div class="div-block-93" style="display:flex"><img src="" alt="" class="image-41">
       <!-- Product Display Gallery -->
            <ul class="piclist">
                <li><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/0.jpg" alt=""></li>
                <li><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/1.jpg" alt=""></li>
                <li><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/2.jpg" alt=""></li>
                <li><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/3.jpg" alt=""></li>
                <li><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/4.jpg" alt=""></li>
                <li><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/5.jpg" alt=""></li>
                
            </ul>
            <div class="picZoomer">
                <img id="productImage" src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/0.jpg" height="320" width="320" alt="">
            </div>
          </div>
      </div>
      <div id="w-node-ed04cfd1ea0b-0bc48b59" class="div-block-81">
        <h5 class="heading-17">Heading</h5>
        <h2 class="heading-18">Heading</h2>
        <div class="div-block-83">
          <h6 class="heading-21">Availability</h6>
          <div class="button">
            <h6 class="heading-16">in stock</h6>
          </div>
        </div>
        <div class="div-block-83-copy">
          <h6>Choose an option</h6>
          <div class="div-block-84">
            <div class="button-copy">
              <h6 class="heading-16">Heading</h6>
            </div>
            <div class="button-copy">
              <h6 class="heading-16">Heading</h6>
            </div>
          </div>
        </div>
        <div class="addtocartbutton"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Shoplist-Ikea-rzk-version.svg" width="19" height="19" alt="" class="image-40">
          <div class="addtocarttext">Add To Cart</div>
        </div>
      </div>
      <div id="w-node-f6648ae7f933-0bc48b59" class="div-block-80">
        <div>
          <h4 class="heading-19">DESCRIPTION</h4>
          <p class="paragraph-9">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat. Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc ut sem vitae risus tristique posuere.</p>
        </div>
        <div>
          <h4 class="heading-19">Specifications</h4>
        </div>
        <div class="w-layout-grid grid-19">
          <div id="w-node-ba0e327b390f-0bc48b59" class="greydiv">
            <h4 class="heading-20">Itemcode</h4>
          </div>
          <div class="lightgreydiv">
            <h4 class="heading-20">Heading</h4>
          </div>
          <div id="w-node-f72c26079507-0bc48b59" class="greydiv">
            <h4 class="heading-20">Brand</h4>
          </div>
          <div class="lightgreydiv">
            <h4 class="heading-20">Heading</h4>
          </div>
          <div id="w-node-1c26b30611a5-0bc48b59" class="greydiv">
            <h4 class="heading-20">Size</h4>
          </div>
          <div class="lightgreydiv">
            <h4 class="heading-20">Heading</h4>
          </div>
          <div id="w-node-04be13188632-0bc48b59" class="greydiv">
            <h4 class="heading-20">Classification</h4>
          </div>
          <div class="lightgreydiv">
            <h4 class="heading-20">Heading</h4>
          </div>
          <div id="w-node-6e919f0d8dd6-0bc48b59" class="greydiv">
            <h4 class="heading-20">Material</h4>
          </div>
          <div class="lightgreydiv">
            <h4 class="heading-20">Heading</h4>
          </div>
          <div id="w-node-f7f20bb29177-0bc48b59" class="greydiv">
            <h4 class="heading-20">Space</h4>
          </div>
          <div class="lightgreydiv">
            <h4 class="heading-20">Heading</h4>
          </div>
        </div>
      </div>
      <div id="w-node-1deec0dac78b-0bc48b59" class="div-block-86">
        <div class="div-block-82">
          <h4 class="heading-15">Frequently brought together</h4>
          <div class="collection-list-wrapper-9 w-dyn-list">
            <div role="list" class="collection-list-10 w-dyn-items">
              <div role="listitem" class="w-dyn-item">
                <div class="div-block-70"><img height="235" width="400" src="https://d3e54v103j8qbb.cloudfront.net/plugins/Basic/assets/placeholder.60f9b1840c.svg" data-w-id="6c2dd090-f0b8-992a-20e3-1deec0dac793" alt="" class="image-39">
                  <h4 class="heading-22">Heading</h4>
                </div>
              </div>
            </div>
            <div class="w-dyn-empty">
              <div>No items found.</div>
            </div>
          </div>
          <div class="addtocartbutton"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Shoplist-Ikea-rzk-version.svg" width="19" height="19" alt="" class="image-40">
            <div class="buy-together">Buy Together</div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="container-32-copy w-container">
    <h4 class="heading-15">Similar products you may like</h4>
    <div class="div-block-73">
      <div class="w-layout-grid grid-21">
        <div>
          <div class="div-block-55">
            <div class="div-block-70"><img height="235" width="400" src="https://d3e54v103j8qbb.cloudfront.net/plugins/Basic/assets/placeholder.60f9b1840c.svg" data-w-id="3c19b6ca-7ea9-da35-4a03-adbd651e2f1a" alt="" class="image-39"></div>
            <div class="text-block-26">This is some text inside of a div block.</div>
          </div>
          <div class="fav-cart">
            <div class="fav"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/002-love.svg" width="22" height="22" alt="" class="favimage">
              <div class="text-block-25">Like</div>
            </div>
            <div class="addtocartbutton"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Shoplist-Ikea-rzk-version.svg" width="19" height="19" alt="" class="image-40">
              <div class="addtocarttext">Add To Cart</div>
            </div>
          </div>
        </div>
        <div>
          <div class="div-block-55">
            <div class="div-block-70"><img height="235" width="400" src="https://d3e54v103j8qbb.cloudfront.net/plugins/Basic/assets/placeholder.60f9b1840c.svg" data-w-id="a70a8fc5-b2ae-baed-d692-fb12e6500a92" alt="" class="image-39"></div>
            <div class="text-block-26">This is some text inside of a div block.</div>
          </div>
          <div class="fav-cart">
            <div class="fav"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/002-love.svg" width="22" height="22" alt="" class="favimage">
              <div class="text-block-25">Like</div>
            </div>
            <div class="addtocartbutton"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Shoplist-Ikea-rzk-version.svg" width="19" height="19" alt="" class="image-40">
              <div class="addtocarttext">Add To Cart</div>
            </div>
          </div>
        </div>
        <div>
          <div class="div-block-55">
            <div class="div-block-70"><img height="235" width="400" src="https://d3e54v103j8qbb.cloudfront.net/plugins/Basic/assets/placeholder.60f9b1840c.svg" data-w-id="deb7d637-0ee6-fffe-61d8-9214a6c30198" alt="" class="image-39"></div>
            <div class="text-block-26">This is some text inside of a div block.</div>
          </div>
          <div class="fav-cart">
            <div class="fav"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/002-love.svg" width="22" height="22" alt="" class="favimage">
              <div class="text-block-25">Like</div>
            </div>
            <div class="addtocartbutton"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Shoplist-Ikea-rzk-version.svg" width="19" height="19" alt="" class="image-40">
              <div class="addtocarttext">Add To Cart</div>
            </div>
          </div>
        </div>
        <div>
          <div class="div-block-55">
            <div class="div-block-70"><img height="235" width="400" src="https://d3e54v103j8qbb.cloudfront.net/plugins/Basic/assets/placeholder.60f9b1840c.svg" data-w-id="d2e70b23-1a16-4806-33e5-75df2483e74b" alt="" class="image-39"></div>
            <div class="text-block-26">This is some text inside of a div block.</div>
          </div>
          <div class="fav-cart">
            <div class="fav"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/002-love.svg" width="22" height="22" alt="" class="favimage">
              <div class="text-block-25">Like</div>
            </div>
            <div class="addtocartbutton"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Shoplist-Ikea-rzk-version.svg" width="19" height="19" alt="" class="image-40">
              <div class="addtocarttext">Add To Cart</div>
            </div>
          </div>
        </div>
        <div>
          <div class="div-block-55">
            <div class="div-block-70"><img height="235" width="400" src="https://d3e54v103j8qbb.cloudfront.net/plugins/Basic/assets/placeholder.60f9b1840c.svg" data-w-id="6279728e-9cb8-f848-66a2-7088395921bd" alt="" class="image-39"></div>
            <div class="text-block-26">This is some text inside of a div block.</div>
          </div>
          <div class="fav-cart">
            <div class="fav"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/002-love.svg" width="22" height="22" alt="" class="favimage">
              <div class="text-block-25">Like</div>
            </div>
            <div class="addtocartbutton"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Shoplist-Ikea-rzk-version.svg" width="19" height="19" alt="" class="image-40">
              <div class="addtocarttext">Add To Cart</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <?php $__env->stopSection(); ?> 

  <script type="text/javascript">
        $(function() {
          alert("hi");
           // $('.picZoomer').picZoomer();
           // $('.picZoomer').picChanger();
        $('.piclist li').on('click',function(event){
                var $pic = $(this).find('img');
                
                $('#productImage').attr('src',$pic.attr('src'));
               // $('.picZoomer-pic').attr('src',$pic.attr('src'));
            });
        });
    </script>
<?php echo $__env->make('Layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\Projects\ABC3\ABC_hosted\resources\views\product\productDescription.blade.php ENDPATH**/ ?>