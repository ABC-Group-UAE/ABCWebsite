
<br>

applicant details.
<br>


** Email:** <?php echo e($career->Candidate_mailid); ?>  <br>

** Name:** <?php echo e($career->Candidate_Name); ?>  <br>

** Job position:** <?php echo e($career->jobPosition); ?> <br>



**Coverletter:**   <?php echo e($career->coverletter); ?>  <br>



please check the attachment for further details..

<br>

Thank you <br>

Regards,<br>
Abc Website
<?php /**PATH C:\wamp\www\Projects\ABC3\ABC_hosted\resources\views\emails\career.blade.php ENDPATH**/ ?>