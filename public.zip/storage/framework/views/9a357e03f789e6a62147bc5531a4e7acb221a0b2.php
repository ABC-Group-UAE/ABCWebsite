



<?php $__env->startSection('content'); ?>
<link href="<?php echo e(asset('extra_css/ranger.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('extra_css/jquery-ui.css')); ?>" rel="stylesheet">
<?php
				use App\Category;
?>

  <?php
		$SelectedCategory='ALL';
		$SelectedSubCategory='ALL';
		$SelectedSubSubCategory='ALL';
		$categorycolor ="black";
		if(!empty($selectedCatValue)){
			$SelectedCategory = $selectedCatValue;
		}
		if(!empty($selectedSubCatValue)){
			$SelectedSubCategory = $selectedSubCatValue;
		}
		if(!empty($selectedSubSubCatValue)){
			$SelectedSubSubCategory = $selectedSubSubCatValue;
		}
		
  ?>
 <form action="<?php echo e(route('Explore')); ?>" method="" id="Explore">
	<?php echo e(csrf_field()); ?>

<input type="hidden" id="selCategory" name="selCategory" value="<?php echo e($SelectedCategory); ?>">
<input type="hidden" id="selSubCategory" name="selSubCategory" value="<?php echo e($SelectedSubCategory); ?>">
<input type="hidden" id="selSubSubCategory" name="selSubSubCategory" value="<?php echo e($SelectedSubSubCategory); ?>">
<div>
<div class="product-container w-container " >
	<div class="mobile-filter-div">
	  <h3 data-w-id="51e7688d-dc9a-f7af-24dd-ef06a825201e" class="filter-main-heading">Our Products</h3>
	  <div class="subcategory-listing-div">
		<div data-w-id="623fcbdf-e1b1-6b49-413b-865856a2b503" style="width:0PX;height:0PX" class="colour-filter-div">
		  <div data-w-id="5ced1108-e704-6224-a4ce-e16e83f5562c" style="opacity:0;width:0PX;height:0PX">Category</div>
		  <div data-hover="" data-delay="0" data-w-id="17c5a2e8-9d33-ae72-2d07-79124de73b42" style="opacity:0;width:0PX;height:0PX" class="w-dropdown">
			<div class="w-dropdown-toggle">
			  <div class="w-icon-dropdown-toggle"></div>
			  <div>Please Select Category</div>
			</div>
			<nav class="w-dropdown-list">
			  <div class="w-dyn-list">
				<div role="list" class="w-dyn-items">
				  <div role="listitem" class="w-dyn-item"><a href="#" class="w-dropdown-link"></a></div>
				</div>
				<div class="w-dyn-empty">
				  <div>No items found.</div>
				</div>
			  </div>
			</nav>
		  </div>
		</div>
		<div data-w-id="6a58f455-0f22-0c39-3948-b2bcff196f5c" style="width:0PX;height:0PX">
		  <div data-w-id="6a58f455-0f22-0c39-3948-b2bcff196f72" style="opacity:0;width:0PX;height:0PX"> Product</div>
		  <div class="subcategory-div"><a href="#" class="button-3 w-button">Sub Category</a><a href="#" class="button-3 w-button">Sub Category</a><a href="#" class="button-3 w-button">Sub Category</a><a href="#" class="button-3 w-button">Sub Category</a><a href="#" class="button-3 w-button">Sub Category</a><a href="#" class="button-3 w-button">Sub Category</a></div>
		</div>
		<div data-w-id="9fc82de8-2f34-1fcd-ebc6-2d211eaca595" style="width:0PX;height:0PX">
		  <div data-w-id="9fc82de8-2f34-1fcd-ebc6-2d211eaca5a4" style="opacity:0;width:0PX;height:0PX"> Brand</div>
		  <div class="branddiv"><a href="#" class="button-3 w-button">Brand</a><a href="#" class="button-3 w-button">Brand</a><a href="#" class="button-3 w-button">Brand</a><a href="#" class="button-3 w-button">Brand</a><a href="#" class="button-3 w-button">Brand</a></div>
		</div>
		<div data-w-id="797d9cf3-b8fa-e37a-6643-b88327865aaa" style="width:0PX;height:0PX"></div>
	  </div>
	  <div class="mobile-price-range-div">
		<h3 class="filter-main-heading">Price Range</h3>
		<div>
		  <div>Select your Price Range:</div>
		  <div id="slider-range-min" class="price-ranger"></div>
		</div>
	  </div>
	  <div class="filter-section-div">
		<h3 class="filter-main-heading">Colour</h3>
		<div class="colour-filter-div">
		  <div class="colour-block"></div>
		  <div class="greycolourblock"></div>
		  <div class="ash-colour-block"></div>
		  <div class="blackcolourblock"></div>
		  <div class="colour-block"></div>
		</div>
	  </div>
	</div>
	<div class="desktop-filter-div">
	  <div class="filter-section-div">
		<h3 class="filter-main-heading">Our Products</h3>
		<a href="#" onClick="fetchData('ALL')" aria-current="page" class="category-link w--current">All Products</a>
		
		<?php if( !($Categories->isEmpty())): ?>  <!-- all category listing div  checking categories exist-->
		
		<?php $__currentLoopData = $Categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><!-- category iterating loop   -->
		<div class="category-listing-div w-clearfix" >
			<a href="#"  onClick="fetchData('<?php echo e($Category->Category_ID); ?>')" aria-current="page" class="category-link w--current" id="<?php echo e($Category->Category_ID); ?>"><?php echo e($Category->Category_Name); ?></a>
			
			<?php if($SelectedCategory == $Category->Category_ID): ?><!-- checking if selected category === this category -->
			<?php
			$categorycolor ="red";
				// if($Selected == $Category->Category_ID){
				$subCategories = Category::find($Category->Category_ID)->SubCategories;
				// $subCategories = $Categories->SubCategories;
				//dd($subCategories);
				//style="font-style:{{($SelectedCategory == $Category->Category_ID) ? 'red' : '' }} "
			?>

		   <?php if( !($subCategories->isEmpty())): ?> <!-- checking if sub category list empty -->

			
		   <?php $__currentLoopData = $subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <!-- looping sub categories -->
		   <?php
				// if($Selected == $Category->Category_ID){
				$subSubCategories = $subCategory->SubSubCategories($subCategory->Category_ID,$subCategory->Sub_Category_ID);
				// $subCategories = $Categories->SubCategories;
				//dd($subCategory->Category_ID);
				//dd ($subCategory->Sub_Category_ID); 
				//dd($subSubCategories);
			?>
			<?php if($SelectedCategory == $subCategory->Category_ID): ?>
			<div  style="margin-left: 10%;">
			<div style="display:flex"><input type="checkbox" name="category"  id="<?php echo e($subCategory->Category_ID); ?>-<?php echo e($subCategory->Sub_Category_ID); ?>" value="<?php echo e($subCategory->Category_ID); ?>-<?php echo e($subCategory->Sub_Category_ID); ?>" onChange="fetchDataBasedOnFilter('checkbox')" ><a  aria-current="page" class="category-link w--current"><?php echo e($subCategory->Sub_Category_Name); ?></a></div>
			<!-- name="<?php echo e($subCategory->Category_ID); ?>-<?php echo e($subCategory->Sub_Category_ID); ?>" -->
			<!-- onClick="fetchDataCategory('<?php echo e($subCategory->Category_ID); ?>','<?php echo e($subCategory->Sub_Category_ID); ?>',<?php echo e($subCategories); ?>)" -->

			<?php if( !($subSubCategories->isEmpty())): ?>  <!-- checking if sub sub category list empty -->
			
			 <div style="margin-left: 10%">
			<?php $__currentLoopData = $subSubCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subSubCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <!-- looping sub sub categories -->
			
				<div style="display:flex"><input type="checkbox" name="category" value="<?php echo e($subSubCategory->Category_ID); ?>-<?php echo e($subSubCategory->Sub_Category_ID); ?>-<?php echo e($subSubCategory->Sub_Sub_Category_ID); ?>" id="<?php echo e($subSubCategory->Category_ID); ?>-<?php echo e($subSubCategory->Sub_Category_ID); ?>-<?php echo e($subSubCategory->Sub_Sub_Category_ID); ?>" onChange="fetchDataBasedOnFilter('checkbox')" ><a  aria-current="page" class="category-link w--current"><?php echo e($subSubCategory->Sub_Sub_Category_Name); ?></a></div>
				<!-- name="<?php echo e($subSubCategory->Category_ID); ?>-<?php echo e($subSubCategory->Sub_Category_ID); ?>-<?php echo e($subSubCategory->Sub_Sub_Category_ID); ?>" -->
				<!--  onClick="fetchDataSubCategory('<?php echo e($subSubCategory->Category_ID); ?>','<?php echo e($subSubCategory->Sub_Category_ID); ?>','<?php echo e($subSubCategory->Sub_Sub_Category_ID); ?>',<?php echo e($subSubCategories); ?>)" --> 
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--end of  looping sub sub categories -->
			</div> 
			
			<?php endif; ?>  <!-- end of if sub sub category list empty -->
		  </div>
			<?php endif; ?> 
		  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  <!-- end of looping sub categories -->
		  <?php endif; ?>  <!--  close checking if sub category list empty -->

		  <?php endif; ?> <!--  close of if selected category === this category -->
		
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!-- end of vategory iterating loop -->
		<?php endif; ?>  <!-- all category listing div  close of category exist checking if -->

	  </div>
	  <div class="filter-section-div">
		<h3 class="filter-main-heading">Price Range</h3>
		<div>Select your Price Range:</div>
		 <div id="slider-min" class="price-ranger" style="display:block">
				<!-- my price ranger code -->
				<div id="slider-range" class="price-filter-range" name="rangeInput">
				</div>  
				<input type="number" min=0 max="5900" oninput="validity.valid||(value='0');" id="min_price" class="price-range-field" />
				<input type="number" min=0 max="6000" oninput="validity.valid||(value='6000');" id="max_price" class="price-range-field" />
				<br>
				<div>
				<button class="price-range-search" id="price-range-submit" onClick="fetchDataBasedOnFilter('Button')">Search</button>
				</div>
				


				<div id="searchResults" class="search-results-block" ></div>

<!-- end of price ranger code -->


			</div>
		
	  </div>
	  <div class="filter-section-div">
		<h3 class="filter-main-heading">Colour</h3>
		<!-- class="colour-filter-div" -->
		<?php
			$i=1;
		?>
		<div  >
			<?php if( (sizeof($colours)>0)): ?> 
			<?php $__currentLoopData = $colours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $colouritem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php
				$i++;
				if($i%2 == 0){
					// echo ($i%2);

			?>
					<center><div class="brand-filter-div">
						
			<?php		
				}
			?>
			<div ><input type="checkbox" name="colours" value="<?php echo e($colouritem->colour); ?>" onChange="fetchDataBasedOnFilter('checkbox')"><?php echo e($colouritem->colour); ?> </div>
		  		
		  		<?php
				
					if($i%2 != 0){
				?>
					
					</div></center>
				<?php
					
				}
			?>
		  	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		  	<?php endif; ?>
		  
		</div>
	  </div>
	  <div class="filter-section-div">
		<h3 class="filter-main-heading">Our Brands</h3>
		<?php if( (sizeof($Brands)>0)): ?>
		<?php $__currentLoopData = $Brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Branditem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="brand-filter-div"><input type="checkbox" name="Brands" value="<?php echo e($Branditem->Brand_Name); ?>" onChange="fetchDataBasedOnFilter('checkbox')"><?php echo e($Branditem->Brand_Name); ?></div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php endif; ?>
		
	  </div>
	</div>

	<?php if( !($products->isEmpty())): ?>
	<div class="w-layout-grid product-display-grid"  id ="productList">
		<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		   <div class="product-display-div">
			<div class="productlink-holding-div">
			  <a href="<?php echo e(route('Product.description', $product->Product_id)); ?>" class="combocolorandavoidunderline w-inline-block">
				<div class="product-image-div"><img height="235" width="400" src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/<?php echo e($product->MainImage)); ?>" data-w-id="437c5c3e-61c4-24a8-550f-2bf0e3b35adc" alt="" class="product-image"></div>
				<div class="product-name combocolor"><?php echo e($product->product_name); ?></div>
			  </a>
			</div>
			<div class="fav-cart">
			  <div class="fav" onClick=" return wishListAddition('<?php echo e($product->Product_id); ?>',event)" ><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/002-love.svg" width="22" height="22" alt="" class="favimage">
				<div class="like-text">Like</div>
			  </div>
			  <div class="addtocartbutton" onClick=" return CartAddition('<?php echo e($product->Product_id); ?>',event)"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Shoplist-Ikea-rzk-version.svg" width="19" height="19" alt="" class="cart-img">
				<div class="addtocarttext">Add To Cart</div>
			  </div>
			</div>
		  </div>
	  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
	
	<?php else: ?>
	<h1>No Products to display </h1>
	<?php endif; ?>
	<div id="main"></div>
  </div>
 
</div>
</form>

<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/jquery-ui.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/ranger.js')); ?>"></script>
    <script>
    		function fetchData(Selected){
			//alert($("#selCategory").val());
			if($("#selCategory").val() != "ALL"){
				var selCategory = $("#selCategory").val();
			}
			selCategory = selCategory
			$("#selCategory").val(Selected);
			//alert("Hi Inside Form submit function");
			
			//alert($("#selCategory").val());
			$("#Explore").submit();
		}
		
		function fetchDataBasedOnFilter(type){
			

			event.preventDefault();
			//alert($("#selCategory").val());
			var selected = $("#selCategory").val();
			var checkboxes = document.getElementsByName("category");
			var categories = [];
			  for (var i=0; i<checkboxes.length; i++) {
			     // And stick the checked ones onto an array...
			     if (checkboxes[i].checked) {
			     	//alert(checkboxes[i].value);
			     	categories.push(checkboxes[i].value);
			       
			       // alert(checkboxes[i].value);
			     }
			  }
			  
			  if(categories.length==0){
			  	categories.push("ALL");
			  }
			 // alert(categories);
			  var colourcheckboxes = document.getElementsByName("colours");
			var selColours = [];
			  for (var i=0; i<colourcheckboxes.length; i++) {
			     // And stick the checked ones onto an array...
			     if (colourcheckboxes[i].checked) {
			     	//alert(checkboxes[i].value);
			     	selColours.push(colourcheckboxes[i].value);
			       
			       // alert(checkboxes[i].value);
			     }
			  }
			  // if(selColours.length==0){
			  // 	selColours.push("ALL");
			  // }
			  var colourCount = selColours.length;
			 // alert(selColours.length);
			 // alert(selColours);
			   var brandcheckboxes = document.getElementsByName("Brands");
			var selBrands = [];
			  for (var i=0; i<brandcheckboxes.length; i++) {
			     // And stick the checked ones onto an array...
			     if (brandcheckboxes[i].checked) {
			     	//alert(checkboxes[i].value);
			     	selBrands.push(brandcheckboxes[i].value);
			       
			       // alert(checkboxes[i].value);
			     }
			  }
			  // if(selBrands.length==0){
			  // 	selBrands.push("ALL");
			  // }
			  var brandCount = selBrands.length;
			 // alert(selBrands.length);
			 // alert(selBrands);
			   var min_price = $('#min_price').val();
			var max_price = $('#max_price').val();

			  var url = "<?php echo e(route('Product.Fetch')); ?>";
            		var _token = '<?php echo csrf_token() ?>';
			//alert(url);
				$.ajax(

				{
					type: "post",
					url: url,
					data: {   
						categories:categories,
						selectedCat : selected,
						selColours : selColours,
						selBrands  :selBrands,
						min_price:min_price,
						max_price:max_price,
						colourCount : colourCount,
						brandCount  : brandCount,
						_token  :_token
					},
					success:function(result,e) {
						console.log(result)
					     
		      				
		      				console.log(url);

		      				console.log(result.products);
		      				// console.log(result.message);
		      				// console.log(result.Sub_Category_ID);
		      				// console.log(result.Category_ID);
		      				var products =result.products;
		      				console.log(products.length);
		      				product_display(products);
		      			
					},
					error:function(result) {
						alert('error');
						console.log(result);

					}
				});

		}
		
		
	function CartAddition(productId,e){
      
          event.preventDefault();
          
          //alert(productId +" and "+fromValue);
            var url = "<?php echo e(route('Cart.Add')); ?>";
            var _token = '<?php echo csrf_token() ?>';
           // alert(url);
           // alert(_token);
            $.ajax({
                  type: "post",
                  url: url,
                  data: {   
                               id: productId,
                         Quantity: 1,
                         _token  :_token
                       },
                  success:function(result,e) {
                   // alert(result.message+"and"+ result.count+"and"+ result.success );
                    console.log(result);
                      console.log(result.data);
                    console.log(result.message);
                    console.log(result.count);
                    if(result.count > 0){ //checking cart is empty or not.. if not empty
                      //if not empty
                      $("#cartCount").css('display','inline');
                      $("#cartCountText").text(result.count);
                    
                    }else{
                      // if cart is empty
                      $("#cartCount").css('display','none');
                    }
                     
                    // e.preventDefault();
                    
                  },//end of success function
                  error:function(result) {
                    alert('error');
                    console.log(result);

                  }
              });

      }

      function wishListAddition(productId,e){
       	event.preventDefault();
            var url = "<?php echo e(route('Favourite.Add')); ?>";
            var _token = '<?php echo csrf_token() ?>';
           // alert(url);
           // alert(_token);
            $.ajax({
                  type: "post",
                  url: url,
                  data: {   
                               id: productId,
                         Quantity: 1,
                         _token  :_token
                       },
                  success:function(result,e) {
                   // alert(result.message+"and"+ result.count+"and"+ result.success );
                    console.log(result);
                      console.log(result.data);
                    console.log(result.message);
                    console.log(result.count);
                     

                   
                    
                    // e.preventDefault();
                    
                  },
                  error:function(result) {
                    alert('error');
                    console.log(result);

                  }
              });

      }

     
function product_display(products){
			$("#productList").empty();
		      				$( "#main" ).empty();
		      				if(products.length == 0){
		      					var $html = $("<h1>No Products to display</h1><br>");
		      					$( "#main" ).append( $html);
		      				}else{
		      					for (var product in products) {
		      					var url = "<?php echo e(route('Product.description', ':id')); ?>";
    							url = url.replace(':id', products[product].Product_id);
    							var carturl = "https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Shoplist-Ikea-rzk-version.svg";
    							var likeurl = "https://abccontentbucket.s3.me-south-1.amazonaws.com/images/002-love.svg";
    							var producturl =  "https://abccontentbucket.s3.me-south-1.amazonaws.com/images/:image') }}";
    							producturl = producturl.replace(':image', products[product].MainImage);
		      					var $html = $("<div class='product-display-div'><div class='productlink-holding-div'><a href='"+ url +"' class='combocolorandavoidunderline w-inline-block'><div class='product-image-div'><img src='"+producturl+"' id='pro_pic"+products[product].Product_id+"' height='235' width='400'  data-w-id='437c5c3e-61c4-24a8-550f2bf0e3b35adc' alt='' class='product-image'></div><div class='product-name combocolor'>"+ products[product].product_name +"</div></a></div><div class='fav-cart'><div class='fav' onClick='wishListAddition(\""+ products[product].Product_id +"\",event)' ><img src='"+likeurl+"' width='22' height='22' alt='' class='favimage'><div class='like-text'>Like</div></div><div class='addtocartbutton' onClick='CartAddition(\""+ products[product].Product_id +"\",event)'><img src='"+carturl+"' width='19' height='19' alt='' class='cart-img'><div class='addtocarttext'>Add To Cart</div></div></div></div>");
		      						
		      					       $( "#productList" ).append( $html);
		      					}
		      				}
		}	
	</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\Projects\ABC3\ABC_hosted\resources\views\product\back up\Explore1.blade.php ENDPATH**/ ?>