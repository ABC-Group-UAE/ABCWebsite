<br>

Product Enquiry
<br>
Customer detail is
<br>

** Email:** <?php echo e($contact->customer_mailid); ?>  <br>

** Name:** <?php echo e($contact->CustomerName); ?>  <br>

** Mobile Number:** <?php echo e($contact->mobile); ?> <br>



Product Details <br>
<?php
$i=0;
?>
<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
<?php
$i++;
?>
<?php echo e($i); ?>. </t>
Product ID : <?php echo e($product->id); ?> <br>
Product Name: <?php echo e($product->name); ?>                    <br>
Quantity : <?php echo e($product->quantity); ?>                          <br>



<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



Please contact this person...

<br>

Thank you <br>

Regards,<br><?php /**PATH C:\wamp\www\Projects\ABC3\ABC_hosted\resources\views\emails\cartlist.blade.php ENDPATH**/ ?>