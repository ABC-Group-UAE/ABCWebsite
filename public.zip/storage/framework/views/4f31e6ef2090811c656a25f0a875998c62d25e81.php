

<?php $__env->startSection('content'); ?>
<div class="catalogue-img-container w-container">
    <h1 class="mainheading">Catalogues</h1>
</div>   
<div class="main-hero-section">
<div class="wrapper">
    <?php if(!empty($catalogues)): ?>    
         <?php $__currentLoopData = $catalogues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catalogueA): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <?php if($catalogueA->count()): ?>
                    
                        <div class="title-div">
                            <h1 class="headinginnerpages">
                                <?php
                                    $category ="";
                                ?>
                                <?php $__currentLoopData = $catalogueA; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catinfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php 
                                    $category = $catinfo->Categories->Category_Name;
                                    break;
                                ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($category); ?>

                            </h1>

                            <div class="reddividerdiv combo-length"></div>
                        </div>
                    <div class="w-layout-grid catalogue-list">
                        <?php $__currentLoopData = $catalogueA; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catinfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="image-wrapper" style="background:url('https://abccontentbucket.s3.me-south-1.amazonaws.com/images/<?php echo e($catinfo->frontCover); ?>');">
                            <div data-w-id="a205876a-3abe-3966-05c9-60f617972b67"  href="#" class="item-overlay w-inline-block">
                                <div style="-webkit-transform:translate3d(0, 0PX, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);-moz-transform:translate3d(0, 0PX, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);-ms-transform:translate3d(0, 0PX, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);transform:translate3d(0, 0PX, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);" class="downloadbuttonclass">
                                <a href="<?php echo e(asset('Catalogues/'.$catinfo->pdfPath)); ?>"  target="_blank" style="text-decoration:none;"><div class="text-block-24">View</div></a> 
                                </div>
                                <div style="-webkit-transform:translate3d(0, 0PX, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);-moz-transform:translate3d(0, 0PX, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);-ms-transform:translate3d(0, 0PX, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);transform:translate3d(0, 0PX, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);" class="downloadbuttonclass">
                                <a href="<?php echo e(route('catalogue.download',$catinfo->pdfPath)); ?>" style="text-decoration:none;"><div class="text-block-24">Download</div></a>
                                </div>
                            </div>
                            <div class="content-image" style="background:url('https://abccontentbucket.s3.me-south-1.amazonaws.com/images/<?php echo e($catinfo->frontCover); ?>');"></div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
       
        
</div>        
</div>

<?php $__env->stopSection(); ?>

    
<?php echo $__env->make('Layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\Projects\ABC3\ABC_hosted\resources\views\download.blade.php ENDPATH**/ ?>