<br>
Thanks for your enquiry...
Greetings of the day!..
You have enquired about the following products.


<br>


Product Details <br>
<?php
$i=0;
?>
<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
<?php
$i++;
?>
<?php echo e($i); ?>. </t>
Product ID : <?php echo e($product->id); ?> <br>
Product Name: <?php echo e($product->name); ?>                    <br>
Quantity : <?php echo e($product->quantity); ?>                          <br>



<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



Very soon our customer service associate will contact you through whatsapp or call and will provide details.  

<br>

Thank you <br>

Regards,<br><?php /**PATH C:\wamp\www\Projects\ABC3\ABC_hosted\resources\views/emails/customercopy.blade.php ENDPATH**/ ?>