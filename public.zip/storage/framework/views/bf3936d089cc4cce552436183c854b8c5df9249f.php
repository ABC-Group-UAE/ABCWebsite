


<?php $__env->startSection('extra-css'); ?>
<style>
    .piclist{
        margin-top: auto;
        margin-right: 10px;;
        display:flex;
        flex-direction: column;
    }
    .piclist li{
        display: inline-block;
        width: 50px;
        height: 50px;
        margin:3px;
    }
    .piclist li img{
        width: 100%;
        height: auto;
    }

    /* custom style */
    .picZoomer-pic-wp,
    .picZoomer-zoom-wp{
        border: 1px solid #fff;
    }



    /* jquery pic zoomer.css */

  
    
    </style> 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-32 w-container">
<!--   <form action="<?php echo e(route('Cart.Add')); ?>"  method="post"> -->
  <!--    <form action="cart/<?php echo e($product->Product_id); ?>" method="get"> -->
    
    <form>

      
    <?php echo csrf_field(); ?>
  <?php if(!empty($product)): ?>
    <div class="w-layout-grid page-layout-grid">
      <div id="w-node-839af9fdddca-0bc48b59" class="image-gallery-div">
        <div class="thumpnail-holding-div" style="display:flex">
          <!-- <div class="thumpnail"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/0.jpg" loading="lazy" alt=""></div>
          <div class="thumpnail"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/3.jpg" loading="lazy" alt=""></div>
          <div class="thumpnail"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/1.jpg" loading="lazy" alt=""></div>
          <div class="thumpnail"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/3.jpg" loading="lazy" alt=""></div>
          <div class="thumpnail"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/2.jpg" loading="lazy" alt=""></div> -->
          <ul class="piclist">
                <li class="thumpnail"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/<?php echo e($product->Thumpnail1)); ?>" alt=""></li>
                <li class="thumpnail"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/<?php echo e($product->Thumpnail2)); ?>" alt=""></li>
                <li class="thumpnail"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/<?php echo e($product->Thumpnail3)); ?>" alt=""></li>
                <li class="thumpnail"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/<?php echo e($product->Thumpnail4)); ?>" alt=""></li>
                <li class="thumpnail"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/<?php echo e($product->Thumpnail5)); ?>" alt=""></li>
                <li class="thumpnail"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/<?php echo e($product->Thumpnail6)); ?>" alt=""></li>
          </ul>
        </div>
        <div class="main-image-div">
            <div class="picZoomer">
                <!-- <img id="productImage" src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/0.jpg" height="320" width="320" alt=""> -->
                <img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/<?php echo e($product->MainImage)); ?>" loading="lazy" alt="" class="main-product-image" id="productImage">
            </div>
        </div>
      </div>
      <div id="w-node-4c38c6fd396e-0bc48b59" class="product-description-div">
        <h5 class="brand-text"><?php echo e($product->Brand); ?></h5>
        <h2 class="product-name-text"><?php echo e($product->product_name); ?> - <?php echo e($product->Product_id); ?> </h2>
        <div class="availability-div">
          <h6 class="availability-text">Availability</h6>
          <div class="button">
            <?php if( $product->unit_in_stock >0): ?>
              <h6 class="in-stock-text">in stock</h6>
            <?php else: ?>
              <h6 class="in-stock-text">Out of stock</h6>
            <?php endif; ?>
          </div>
        </div>
        <?php if(!empty($product->Available_variance)): ?>
        
        
        
        
        <div class="option-div">
          <h6>Choose an option</h6>

          <div class="option-listing-div">
          
            <?php $__currentLoopData = explode(',', $product->Available_variance); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="button-copy">
              <h6 class="heading-16"> <?php echo e($option); ?></h6>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            


          </div>
          <div class="option-listing-div">
          
            
            <div >
              <h6 class="heading-16"> <?php echo e($product->presentPrice()); ?></h6>
            </div>
            
            


          </div>

        </div>
        
        <?php endif; ?>
        <div class="cart-and-qty-div">
          <div class="html-embed-2 w-embed">
            <center><select name="quantity" autocomplete="off" id="quantity" tabindex="0" class="a-native-dropdown" style="width:70%; height:90%;margin-top:20px">
                      <option value="1" selected="">1
                      </option>
                      <option value="2">2
                      </option>
                      <option value="3">3
                      </option>
                      <option value="4">4
                      </option>
                      <option value="5">5
                      </option>
                      </select></center>
          </div>
          <input type="hidden" value = "<?php echo e($product->Product_id); ?>" id = "Product_id">
          <button class="addtocartbutton" id = "<?php echo e($product->Product_id); ?>"  onClick= "AddToCart(event)" ><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Shoplist-Ikea-rzk-version.svg" width="19" height="19" alt="" class="cart-img">
            <div class="addtocarttext">Add To Cart</div>
          </button>
          <button class="addtocartbutton" id = "<?php echo e('Favourite'.$product->Product_id); ?>"  onClick= "AddToFavourite(event)" ><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/002-love.svg" width="19" height="19" alt="" class="cart-img">
            <div class="addtocarttext">Add To Favourites</div>
          </button>
        </div>
      </div>
      <div id="w-node-8a288b908a16-0bc48b59" class="detailing-div">
        <div class="description-div">
          <h4 class="detailing-headings">DESCRIPTION</h4>
          <p class="paragraph-9"><?php echo e($product->long_description); ?></p>
        </div>
        <div class="specification-heading">
          <h4 class="detailing-headings">Specifications</h4>
        </div>
        <div class="w-layout-grid specification-list-grid">
          <div id="w-node-8a288b908a20-0bc48b59" class="greydiv">
            <h4 class="specifications-text">Itemcode</h4>
          </div>
          <div class="lightgreydiv">
            <h4 class="specifications-text"><?php echo e($product->Product_id); ?></h4>
          </div>
          <div id="w-node-8a288b908a26-0bc48b59" class="greydiv">
            <h4 class="specifications-text">Brand</h4>
          </div>
          <div class="lightgreydiv">
            <h4 class="specifications-text"><?php echo e($product->Brand); ?></h4>
          </div>
          <div id="w-node-8a288b908a2c-0bc48b59" class="greydiv">
            <h4 class="specifications-text">Size</h4>
          </div>
          <div class="lightgreydiv">
            <h4 class="specifications-text"><?php echo e($product->size); ?></h4>
          </div>
          <div id="w-node-8a288b908a32-0bc48b59" class="greydiv">
            <h4 class="specifications-text">Classification</h4>
          </div>
          <div class="lightgreydiv">
            <h4 class="specifications-text"><?php echo e($product->categories->Category_Name); ?> </h4>
          </div>
          <div id="w-node-8a288b908a38-0bc48b59" class="greydiv">
            <h4 class="specifications-text">Material</h4>
          </div>
          <div class="lightgreydiv">
            <h4 class="specifications-text"><?php echo e($product->material); ?></h4>
          </div>
          <div id="w-node-8a288b908a3e-0bc48b59" class="greydiv">
            <h4 class="specifications-text">Application</h4>
          </div>
          <div class="lightgreydiv">
            <h4 class="specifications-text"><?php echo e($product->Application); ?></h4>
          </div>
        </div>

      </div>


      <?php if(!empty($relatedProducts) && $relatedProducts->count()>1): ?>
      <?php
          
          
      ?>
      <div id="w-node-3e8504d58c73-0bc48b59" class="related-products">
        <div class="div-with-border">
          <h4 class="detailing-headings combo">Frequently brought together</h4>
          <div class="w-layout-grid related-product-div">
            <div class="product-image-div">
                  <a href="<?php echo e(route('Product.description', $product->Product_id)); ?>" style="text-decoration:none;">    
                  <center><img height="150" width="200" src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/<?php echo e($product->MainImage)); ?>" data-w-id="eb239b73-0b1a-d9bc-80fd-ff7845625415" alt="" class="product-image"></center>
                  </a>
                  <a href="<?php echo e(route('Product.description', $product->Product_id)); ?>" style="text-decoration:none;font-color:black;">
                  <h4 class="related-product-heading"><?php echo e($product->product_name); ?></h4>
                  </a>
            </div>
            <?php
                  $i=0;
                  
            ?>
            <?php $__currentLoopData = $relatedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $i++;
                 
                  
            ?>
              <div class="product-image-div">
                <input type="hidden" name="<?php echo e('rel'.$i); ?>"  id="<?php echo e('rel'.$i); ?>" value = "<?php echo e($item->Related_Product_id); ?>">
                  <a href="<?php echo e(route('Product.description', $item->Related_Product_id)); ?>" style="text-decoration:none;">    
                  <center><img height="150" width="200" src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/<?php echo e($item->MainImage)); ?>" data-w-id="eb239b73-0b1a-d9bc-80fd-ff7845625415" alt="" class="product-image"></center>
                  </a>
                  <a href="<?php echo e(route('Product.description', $item->Related_Product_id)); ?>" style="text-decoration:none;font-color:black;">
                  <h4 class="related-product-heading"><?php echo e($item->product_name); ?></h4>
                  </a>
              </div>
              
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
          </div>
          <div class="addtocartbutton" onClick="BuyTogetherItemsToCart('<?php echo e($product->Product_id); ?>',event)"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Shoplist-Ikea-rzk-version.svg" width="19" height="19" alt="" class="cart-img">
            <a href="#" style="text-decoration:none;">
                <div class="buy-together">Buy Together</div>
            </a>
          </div>
        </div>
      </div>
      <?php endif; ?>

    </div>

  <?php endif; ?>
    </form>
  </div>
  <?php echo $__env->make('Common.SimilarProducts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 




<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra-js'); ?>
  <script type="text/javascript">
    // <?php echo e(url('office/service/requirement/rule_delete/')); ?>

        function AddToCart(event){

          event.preventDefault();
          //event.stopPropagation();
          alert("HI");
          var Product_id = $("#Product_id").val();
          var url = "<?php echo e(route('Cart.Add')); ?>";
          alert(url);
           alert(Product_id);
           var _token = '<?php echo csrf_token() ?>';
           console.log(url);
           $.ajax(

                  {
                  type: "post",
                  url: url,
                  //alert(url);
                  
                  data: {  id: $("#Product_id").val(), Quantity: $("#quantity").val() },
                  success:function(result,e) {
                   // alert(result.message+"and"+ result.count+"and"+ result.success );
                    console.log(result);
                      console.log(result.data);
                    console.log(result.message);
                    console.log(result.count);
                    if(result.count > 0){
                      $("#cartCount").css('display','inline');
                      $("#cartCountText").text(result.count);
                    
                    }else{
                      $("#cartCount").css('display','none');
                    }
                    
                    
                    // e.preventDefault();
                    
                  },
                  error:function(result) {
                    alert('error');
                    console.log(result);

                  }
              });
           
        // var dltUrl = url+"/"+Product_id;
         //alert(dltUrl);
          
        
          // $(function(e) {
          //     alert("HI");
          //     e.preventDefault();
          //     alert("HI");
          //     $.ajax({
          //         type: "post",
          //         url: url,
          //         //alert(url);
          //         //console.log(url);
          //         data: { _token:_token, id: $("#Product_id").val(), Quantity: $("#quantity").val() },
          //         success:function(result) {
          //           alert('ok');
          //           console.log("success msg");
          //           console.log(result);
                    
          //         },
          //         error:function(result) {
          //           alert('error');
          //           console.log(result);

          //         }
          //     });
          // });
       }
        $(function() {
          var Product_id = $("#Product_id").val();
          var qty = $("#quantity").val();

          $.ajaxSetup({
                        headers: {
                          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                      });


        //   $(Product_id).click(function(event){
        //     alert("hi");
        //       event.preventDefault();

        //       var _token = '<?php echo csrf_token() ?>';
             

        //       $.ajax({
        //         url: "/AddToCart",
        //         type:"POST",
        //         data:{
        //           _token:_token, 
        //           id: Product_id, 
        //           Quantity:qty
                  
        //         },
        //         success:function(response){
        //           console.log(response);
        //           if(response) {
        //             $('.success').text(response.success);
        //            // $("#ajaxform")[0].reset();
        //           }
        //         },
        //         error:function(result) {
        //                     alert('error');
        //                     console.log(result);

        //                   }
        //        });
        // });



          // $($Product_id).on('click',function(e) {
          //    // e.preventDefault();
          //     alert("HI");
          //     $.ajax({
          //         type: "POST",
          //         url: "<?php echo e(url('cart')); ?>"+"/"+ $("#Product_id").val(),
          //         //alert(url);
          //         //console.log(url);
          //         data: { _token:_token, id: $("#Product_id").val(), Quantity: $("#quantity").val() },
          //         success:function(result) {
          //           alert('ok');
                    
          //         },
          //         error:function(result) {
          //           alert('error');

          //         }
          //     });
          //   });
          //alert("hi");
            // $('.picZoomer').picZoomer();
           // $('.picZoomer').picChanger();
        $('.thumpnail').on('click',function(event){
                var $pic = $(this).find('img');
                
                $('#productImage').attr('src',$pic.attr('src'));
            //    $('.picZoomer-pic').attr('src',$pic.attr('src'));
            });
        });
        function AddToFavourite(event){

          event.preventDefault();
          //event.stopPropagation();
          alert("HI");
          var Product_id = $("#Product_id").val();
          var url = "<?php echo e(route('Favourite.Add')); ?>";
          alert(url);
           alert(Product_id);
           var _token = '<?php echo csrf_token() ?>';
           console.log(url);
           $.ajax(

                  {
                  type: "post",
                  url: url,
                  //alert(url);
                  
                  data: {  id: $("#Product_id").val(), Quantity: $("#quantity").val() },
                  success:function(result,e) {
                   // alert(result.message+"and"+ result.count+"and"+ result.success );
                    console.log(result);
                      console.log(result.data);
                    console.log(result.message);
                    console.log(result.count);
                    // if(result.count > 0){
                    //   $("#cartCount").css('display','inline');
                    //   $("#cartCountText").text(result.count);
                    
                    // }else{
                    //   $("#cartCount").css('display','none');
                    // }
                    
                    
                    // e.preventDefault();
                    
                  },
                  error:function(result) {
                    alert('error');
                    console.log(result);

                  }
              });
           
       }
        function BuyTogetherItemsToCart(selectedProduct,event){

          event.preventDefault();
          //event.stopPropagation();
          alert("HI");
          alert(selectedProduct);
          var multipleItems = [];
          multipleItems.push(selectedProduct);
          if($("#rel1"). length){
              multipleItems.push($("#rel1").val());
          }
          if($("#rel2"). length){
              multipleItems.push($("#rel2").val());
          }
          var url = "<?php echo e(route('Cart.Add.Multiple')); ?>";
          var _token = '<?php echo csrf_token() ?>';
            console.log(url);
               $.ajax(

                  {
                  type: "post",
                  url: url,
                  data: {
                            multipleItems: multipleItems, 
                            Quantity: $("#quantity").val()
                        },
                  success:function(result,e) {
                   // alert(result.message+"and"+ result.count+"and"+ result.success );
                    console.log(result);
                    console.log(result.message);
                    console.log(result.count);
                    if(result.count > 0){
                      $("#cartCount").css('display','inline');
                      $("#cartCountText").text(result.count);
                    
                    }else{
                      $("#cartCount").css('display','none');
                    }
                    
                    
                    // e.preventDefault();
                    
                  },
                  error:function(result) {
                    alert('error');
                    console.log(result);

                  }
              });


         
        
         
       }

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\Projects\ABC3\ABC_hosted\resources\views\product\back up\Description1.blade.php ENDPATH**/ ?>