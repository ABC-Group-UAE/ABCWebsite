<div class="whatsappbox"><a href="https://api.whatsapp.com/send?phone=971564130262&amp;abid=971564130262" class="link-block-category w-inline-block"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/001-whatsapp.svg" width="35" height="35" alt="" class="whatsapp-icon"><h5 class="chat-with-us">Chat<br></h5></a></div>
<div class="footersection">
    <div class="footermenucontainer w-container">
      <div data-w-id="084592a8-06a0-e5a4-2527-7513cd9ec849" class="scrolltotoparrow"><a href="#email" class="w-inline-block"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/up-arrow.svg" width="27" height="30" alt="" class="image-15"></a></div>
      <div class="w-layout-grid footermenugrid">
        <div id="w-node-91a09e5fc710-9e5fc70b" class="footer-heading-div">
          <ul role="list" class="list w-list-unstyled">
            <li class="footerlist-item"><a href="#" class="footerlink">Company Profile</a></li>
            <li class="footerlist-item"><a href="#" class="footerlink">History</a></li>
            <li class="footerlist-item"><a href="team.html" class="footerlink">Team</a></li>
            <li class="footerlist-item"><a href="global-presence.html" class="footerlink">Global Presence</a></li>
          </ul>
          <div class="whitedividerdiv"></div>
        </div>
        <div class="footer-heading-div">
          <ul role="list" class="list w-list-unstyled">
            <li class="footerlist-item"><a href="dealers.html" class="footerlink">Dealers</a></li>
            <li class="footerlist-item"><a href="brands.html" class="footerlink">Brand</a></li>
            <li class="footerlist-item"><a href="exhibit.html" class="footerlink">Exhibits</a></li>
            <li class="footerlist-item"><a href="downloads.html" class="footerlink">Downloads</a></li>
          </ul>
          <div class="whitedividerdiv"></div>
        </div>
        <div class="footer-heading-div">
          <ul role="list" class="list w-list-unstyled">
            <li class="footerlist-item"><a href="#" class="footerlink">StoreLocator</a></li>
            <li class="footerlist-item"><a href="career.html" class="footerlink">Career</a></li>
            <li class="footerlist-item"><a href="#" class="footerlink">Privacy Policy</a></li>
            <li class="footerlist-item"><a href="#" class="footerlink">Cookies Policy</a></li>
          </ul>
          <div class="whitedividerdiv"></div>
        </div>
        <div class="footer-heading-div">
          <ul role="list" class="footerlastsectionlist w-list-unstyled">
            <li class="footerlist-item"><a href="#" class="footerlink">Terms and condition</a></li>
            <li class="footerlist-item"><a href="product-exploration.html" class="footerlink">Products</a></li>
          </ul>
          <div class="whitedividerdiv"></div>
        </div>
        <div id="w-node-91a09e5fc742-9e5fc70b" class="footer-newsletter-div">
          <div class="text-block-11">Get Our News Letter</div>
          <div class="form-block-3 w-form">
            <form id="email-form-3" name="email-form-3" data-name="Email Form 3" class="form-3">
              <div class="div-block-101"><input type="text" class="text-field-2 w-input" maxlength="256" name="Mailid-2" data-name="Mailid 2" placeholder="Enter your mail id" id="Mailid-2"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Asset-1-1_1.svg" loading="lazy" width="19" height="19" alt="" class="image-39"></div>
            </form>
            <div class="w-form-done">
              <div>Thank you! Your submission has been received!</div>
            </div>
            <div class="w-form-fail">
              <div>Oops! Something went wrong while submitting the form.</div>
            </div>
          </div>
        </div>
        <div id="w-node-91a09e5fc74f-9e5fc70b" class="footer-social-media-links">
          <div class="social-icons-white"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/002-facebook-white.svg" loading="lazy" width="20" id="w-node-634764a340f4-9e5fc70b" alt="" class="facebook-white"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/005-linkedin-white.svg" loading="lazy" width="20" id="w-node-634764a340f5-9e5fc70b" alt="" class="linkdin-white"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/003-twitter-white.svg" loading="lazy" width="20" id="w-node-634764a340f6-9e5fc70b" alt="" class="twitter-white"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/001-instagramwhite.svg" loading="lazy" width="20" id="w-node-634764a340f7-9e5fc70b" alt="" class="insta-white"></div>
        </div>
      </div>
      <div class="div-block-112">
        <div class="text-block-36">Copyright © 2020 ABC Group. All rights reserved.</div>
      </div>
    </div>
  </div><?php /**PATH C:\wamp\www\Projects\ABC3\ABC_hosted\resources\views\Common\Footer1.blade.php ENDPATH**/ ?>