
<?php $__env->startSection('extra-css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
		<?php
		use App\Category;
		?>
	
		<?php
		$SelectedCategory='ALL';
		$SelectedSubCategory='ALL';
		$SelectedSubSubCategory='ALL';
		$categorycolor ="black";
		if(!empty($selectedCatValue)){
			$SelectedCategory = $selectedCatValue;
		}
		if(!empty($selectedSubCatValue)){
			$SelectedSubCategory = $selectedSubCatValue;
		}
		if(!empty($selectedSubSubCatValue)){
			$SelectedSubSubCategory = $selectedSubSubCatValue;
		}

		?>
		<form action="<?php echo e(route('Explore')); ?>" method="" id="Explore">
	<?php echo e(csrf_field()); ?>

	<input type="hidden" id="selCategory" name="selCategory" value="<?php echo e($SelectedCategory); ?>">
	<input type="hidden" id="selSubCategory" name="selSubCategory" value="<?php echo e($SelectedSubCategory); ?>">
	<input type="hidden" id="selSubSubCategory" name="selSubSubCategory" value="<?php echo e($SelectedSubSubCategory); ?>">
	<input type="hidden" id="SelectedSUBCategories" name="SelectedSUBCategories" value="">
	<input type="hidden" id="SelectedBrands" name="SelectedBrands" value="">
	<input type="hidden" id="SelectedColours" name="SelectedColours" value="">
	<input type="hidden" id="min_price1" name="min_price1" value="0">
	<input type="hidden" id="max_price1" name="max_price1" value="6000">
  <div class="modal-wrapper-copy" id = "filtermodel">
  <div class="div-block-103">
        <h4 class="heading-31">Filter</h4>
        <a href="<?php echo e(route('Explore')); ?>" style="text-decoration:none;"><h4 class="heading-31">x</h4></a>
	</div>
    <div class="form-wrapper-copy">

      
	  <div style="overflow-y:auto;overflow-x:hidden">
	  <div class='snippet-body'  oncontextmenu='return false'>
				<div class="d-flex justify-content-center">
					<div class="wrapper center-block">
						<!-- <div class="filters-text">
							<span class="filter-span">Filters <small>(find product using filters below)</small></span>
							<span style="float:right;"><i class="fa fa-filter"></i></span>
						</div> -->
						<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
						<?php if( !($Categories->isEmpty())): ?>
						<?php
							$heading=0;
						?>
						<?php $__currentLoopData = $Categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php
							$heading++;
						?>
						<div class="panel panel-default">
								<div class="panel-heading" role="tab" id="heading<?php echo e($heading); ?>">
									<h4 class="panel-title"> <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse<?php echo e($heading); ?>" aria-expanded="false" aria-controls="collapse<?php echo e($heading); ?>"> <?php echo e($Category->Category_Name); ?> </a> </h4>
								</div>
								<div id="collapse<?php echo e($heading); ?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading<?php echo e($heading); ?>">
									<?php
										$subCategories = Category::find($Category->Category_ID)->SubCategories;
									?>
									<div class="panel-body">
										<?php if( !($subCategories->isEmpty())): ?> <!-- checking if sub category list empty -->
											<?php $__currentLoopData = $subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<div class="checkbox"> <label> <input type="checkbox" class="option-input checkbox" name="category1"   value="<?php echo e($subCategory->Category_ID); ?>-<?php echo e($subCategory->Sub_Category_ID); ?>" onChange="updateCategory()"/> <span class="ml-10"><?php echo e($subCategory->Sub_Category_Name); ?></span> </label> </div>
													<?php
													$subSubCategories = $subCategory->SubSubCategories($subCategory->Category_ID,$subCategory->Sub_Category_ID);
													?>
													<?php if( !($subSubCategories->isEmpty())): ?>  <!-- checking if sub sub category list empty -->
														<?php $__currentLoopData = $subSubCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subSubCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
															<div class="checkbox" style="margin-left: 10%"> <label> <input type="checkbox" class="option-input checkbox" name="category1"   value="<?php echo e($subSubCategory->Category_ID); ?>-<?php echo e($subSubCategory->Sub_Category_ID); ?>-<?php echo e($subSubCategory->Sub_Sub_Category_ID); ?>" onChange="updateCategory()"/> <span class="ml-10"><?php echo e($subSubCategory->Sub_Sub_Category_Name); ?></span> </label> </div>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													<?php endif; ?>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										<?php endif; ?>
									</div>
								</div>
						</div>
						    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						    <?php endif; ?>
						    <?php
							$heading++;
						    ?>
							<div class="panel panel-default">
								<div class="panel-heading" role="tab" id="heading<?php echo e($heading); ?>">
									<h4 class="panel-title"> <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse<?php echo e($heading); ?>" aria-expanded="false" aria-controls="collapse<?php echo e($heading); ?>"> Price </a> </h4>
								</div>
								<div id="collapse<?php echo e($heading); ?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading<?php echo e($heading); ?>">
									<div class="panel-body">
											<div class="filter-section-div"><h3 class="filter-main-heading">Price (AED)</h3></div><div class="pricechoosediv"><input type="number" name="min" id="min_price2" aria-label="min" class="text-field-4 w-input" value="0" onChange="updatePrice()"><span class="jsx-304923497 between">To</span><input type="number" name="max" id="max_price2" aria-label="max" class="text-field-4 w-input" value="6000" onChange="updatePrice()"></div>
										
									</div>
								</div>
							</div>
							<?php
							$heading++;
						    ?>
							<div class="panel panel-default">
								<div class="panel-heading" role="tab" id="heading<?php echo e($heading); ?>">
									<h4 class="panel-title"> <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse<?php echo e($heading); ?>" aria-expanded="false" aria-controls="collapse<?php echo e($heading); ?>"> Brand </a> </h4>
								</div>
								<div id="collapse<?php echo e($heading); ?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading<?php echo e($heading); ?>">
									<div class="panel-body">
									<?php if( (sizeof($Brands)>0)): ?>
									<?php $__currentLoopData = $Brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Branditem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<div class="checkbox"> <label> <input type="checkbox" class="option-input checkbox" name="Brands1" value="<?php echo e($Branditem->Brand_Name); ?>" onChange="updateBrand()" /> <span class="ml-10"><?php echo e($Branditem->Brand_Name); ?></span> </label> </div>
										
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
									
									</div>
								</div>
							</div>
							<?php
							$heading++;
						    ?>
							<div class="panel panel-default">
								<div class="panel-heading" role="tab" id="heading<?php echo e($heading); ?>">
									<h4 class="panel-title"> <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse<?php echo e($heading); ?>" aria-expanded="false" aria-controls="collapse<?php echo e($heading); ?>"> Colours </a> </h4>
								</div>
								<div id="collapse<?php echo e($heading); ?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading<?php echo e($heading); ?>">
									<div class="panel-body">
									<?php if( (sizeof($colours)>0)): ?> 
									<?php $__currentLoopData = $colours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $colouritem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<div class="checkbox"> <label> <input type="checkbox" class="option-input checkbox" name="colours1" value="<?php echo e($colouritem->colour); ?>" onChange="updateColour()" /> <span class="ml-10"><?php echo e($colouritem->colour); ?></span> </label> </div>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
									</div>
								</div>
							</div>
							
						</div>
						<!-- <form id="mobileForm">
					      <?php echo e(csrf_field()); ?>

						    <div class="text-right refine"> <button class="btn btn-out btn-primary btn-square" id="apply" onClick ="fetchDataBasedOnMobileFilter()">Apply</button> </div>
						    <div class="text-left refine"> <button class="btn btn-out btn-primary btn-square" id="resetButton" onClick ="reset()">Reset</button> </div>
						</form> -->
					</div>
				</div>

				</div>
	</div>
      
	</div>
	<form id="mobileForm" action = "<?php echo e(route('Explore')); ?>" method="get">
					      <?php echo e(csrf_field()); ?>

	<div class="div-block-102-copy"><a href="<?php echo e(route('Explore')); ?>"  id="resetButton" onClick ="reset()" class="reset w-button">Reset</a><a href="#" class="apply w-button" id="apply" onClick ="fetchDataBasedOnMobileFilter()" >Apply</a></div>
	</form>
</div>
  
  <div class="product-container w-container" >
  <!-- data-w-id="344d042e-70b4-3c36-1481-9ae020fdf117"  data-w-id="344d042e-70b4-3c36-1481-9ae020fdf117"-->
    <div class="div-block-104" data-w-id="344d042e-70b4-3c36-1481-9ae020fdf117" >
	  <div class="text-block-33">Filter</div>
	</div>
	
	
    <div class="mobile-filter-div" onClick="showmodel()">
	   <img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/16.jp" style="width:95%;height:150px;margin-bottom:20px;margin-top:10px;" />
      <div  class="html-embed-3 w-embed"><button type="button" class="btn btn-info" style="width:100%" onClick="showmodel()">Filter<img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/001-web3.svg" style="width:20px;height:25px;"/></button></div>
    </div>
    <div class="desktop-filter-div">
		<div class="filter-section-div">
					<h3 class="filter-main-heading">Products</h3>
					<a href="#" onClick="fetchData('ALL')" aria-current="page" class="category-link">All Products</a>

					<?php if( !($Categories->isEmpty())): ?>  <!-- all category listing div  checking categories exist-->

					<?php $__currentLoopData = $Categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><!-- category iterating loop   -->
					<div class="category-listing-div w-clearfix" >
						<a href="#"  onClick="fetchData('<?php echo e($Category->Category_ID); ?>')" aria-current="page" class="category-link" id="<?php echo e($Category->Category_ID); ?>"  <?php if(isset($SelectedCategory)) { 
            if(strcmp($SelectedCategory ,$Category->Category_ID) == 0) 
            { echo "style='color:#bb0303;font-weight:700'"; }}?> ><?php echo e($Category->Category_Name); ?></a>

						<?php if($SelectedCategory == $Category->Category_ID): ?><!-- checking if selected category === this category -->
						<?php
						$categorycolor ="red";
				// if($Selected == $Category->Category_ID){
						$subCategories = Category::find($Category->Category_ID)->SubCategories;
				// $subCategories = $Categories->SubCategories;
				//dd($subCategories);
				//style="font-style:{{($SelectedCategory == $Category->Category_ID) ? 'red' : '' }} "
						?>

						<?php if( !($subCategories->isEmpty())): ?> <!-- checking if sub category list empty -->


						<?php $__currentLoopData = $subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <!-- looping sub categories -->
						<?php
				// if($Selected == $Category->Category_ID){
						$subSubCategories = $subCategory->SubSubCategories($subCategory->Category_ID,$subCategory->Sub_Category_ID);
				// $subCategories = $Categories->SubCategories;
				//dd($subCategory->Category_ID);
				//dd ($subCategory->Sub_Category_ID); 
				//dd($subSubCategories);
						?>
						<?php if($SelectedCategory == $subCategory->Category_ID): ?>
						<div  style="margin-left: 10%;">
							<div style="display:flex"><input type="checkbox"  <?php if(isset($selectedSubCatValue)) { 
            if(strcmp($selectedSubCatValue ,$subCategory->Sub_Category_ID) == 0) 
            { echo "checked=checked"; }}?>  name="category"  id="<?php echo e($subCategory->Category_ID); ?>-<?php echo e($subCategory->Sub_Category_ID); ?>" value="<?php echo e($subCategory->Category_ID); ?>-<?php echo e($subCategory->Sub_Category_ID); ?>" onChange="fetchDataBasedOnFilter('checkbox')" ><a  aria-current="page" class="subcategory-link"><?php echo e($subCategory->Sub_Category_Name); ?></a></div>
							<!-- name="<?php echo e($subCategory->Category_ID); ?>-<?php echo e($subCategory->Sub_Category_ID); ?>" -->
							<!-- onClick="fetchDataCategory('<?php echo e($subCategory->Category_ID); ?>','<?php echo e($subCategory->Sub_Category_ID); ?>',<?php echo e($subCategories); ?>)" -->

							<?php if( !($subSubCategories->isEmpty())): ?>  <!-- checking if sub sub category list empty -->

							<div style="margin-left: 10%">
								<?php $__currentLoopData = $subSubCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subSubCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <!-- looping sub sub categories -->

								<div style="display:flex"><input type="checkbox" <?php if(isset($selectedSubSubCatValue) && isset($selectedSubCatValue)) { 
            if((strcmp($selectedSubSubCatValue ,$subSubCategory->Sub_Sub_Category_ID) == 0) && (strcmp($selectedSubCatValue ,$subCategory->Sub_Category_ID) == 0)) 
            { echo "checked=checked"; }}?> name="category" value="<?php echo e($subSubCategory->Category_ID); ?>-<?php echo e($subSubCategory->Sub_Category_ID); ?>-<?php echo e($subSubCategory->Sub_Sub_Category_ID); ?>" id="<?php echo e($subSubCategory->Category_ID); ?>-<?php echo e($subSubCategory->Sub_Category_ID); ?>-<?php echo e($subSubCategory->Sub_Sub_Category_ID); ?>" onChange="fetchDataBasedOnFilter('checkbox')" ><a  aria-current="page" class="subsubcategory-link"><?php echo e($subSubCategory->Sub_Sub_Category_Name); ?></a></div>
								<!-- name="<?php echo e($subSubCategory->Category_ID); ?>-<?php echo e($subSubCategory->Sub_Category_ID); ?>-<?php echo e($subSubCategory->Sub_Sub_Category_ID); ?>" -->
								<!--  onClick="fetchDataSubCategory('<?php echo e($subSubCategory->Category_ID); ?>','<?php echo e($subSubCategory->Sub_Category_ID); ?>','<?php echo e($subSubCategory->Sub_Sub_Category_ID); ?>',<?php echo e($subSubCategories); ?>)" --> 
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--end of  looping sub sub categories -->
							</div> 

							<?php endif; ?>  <!-- end of if sub sub category list empty -->
						</div>
						<?php endif; ?> 
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  <!-- end of looping sub categories -->
						<?php endif; ?>  <!--  close checking if sub category list empty -->

						<?php endif; ?> <!--  close of if selected category === this category -->

					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!-- end of vategory iterating loop -->
					<?php endif; ?>  <!-- all category listing div  close of category exist checking if -->

				</div>
				<div class="filter-section-div" style="display:none">
					<h3 class="filter-main-heading">Price Range</h3>
					<div>Select your Price Range:</div>
					<div id="slider-min" class="price-ranger" style="display:block">
						<!-- my price ranger code -->
						<div id="slider-range" class="price-filter-range" name="rangeInput">
						</div>  
						<input type="number" min=0 max="5900" oninput="validity.valid||(value='0');" id="min_price" class="price-range-field" />
						<span> To </span>
						<input type="number" min=0 max="6000" oninput="validity.valid||(value='6000');" id="max_price" class="price-range-field" />
						<br>
						<div class="rangesearch">
							<button class="price-range-search" id="price-range-submit" onClick="fetchDataBasedOnFilter('Button')">Search</button>
						</div>



						<div id="searchResults" class="search-results-block" ></div>

						<!-- end of price ranger code -->


					</div>

				</div>
				<div class="filter-section-div">
					<h3 class="filter-main-heading">Colour</h3>
					<!-- class="colour-filter-div" -->
					<?php
					$i=1;
					?>
					<div>
						<?php if( (sizeof($colours)>0)): ?> 
						
						<div class="colourlisting">
						<?php $__currentLoopData = $colours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $colouritem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					
							<div class="flexdiv"><input type="checkbox" name="colours" value="<?php echo e($colouritem->colour); ?>" onChange="fetchDataBasedOnFilter('checkbox')"><span class="headcategory-link"><?php echo e($colouritem->colour); ?></span> </div>

							

						
						
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
						<?php endif; ?>

					</div>
				</div>
				<div class="filter-section-div">
					<h3 class="filter-main-heading">Our Brands</h3>
					<?php if( (sizeof($Brands)>0)): ?>
					<?php $__currentLoopData = $Brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Branditem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="flexdiv"><input type="checkbox"  <?php if(isset($selectedBrand)) { 

            if((strcmp($selectedBrand ,strtolower($Branditem->Brand_Name)) == 0)) 
            { echo "checked=checked"; }}?> name="Brands" value="<?php echo e($Branditem->Brand_Name); ?>" onChange="fetchDataBasedOnFilter('checkbox')"><span class="headcategory-link"><?php echo e($Branditem->Brand_Name); ?></span></div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>

				</div>
	</div>
    <div>
    <?php if( !($products->isEmpty())): ?>
    <div class="w-layout-grid product-display-grid"  id ="productList">
	<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="product-display-div">
        <div class="productlink-holding-div">
          <a href="<?php echo e(route('Product.description', $product->Product_id)); ?>" class="combocolorandavoidunderline w-inline-block">
            <div class="product-image-div"><img height="235" width="400" src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/<?php echo e($product->MainImage); ?>" data-w-id="437c5c3e-61c4-24a8-550f-2bf0e3b35adc" alt="" class="product-image"></div>
            <div class="product-name combocolor"><?php echo e($product->product_name); ?></div>
          </a>
        </div>
        <div class="fav-cart">
          <div class="fav" onClick=" return wishListAddition('<?php echo e($product->Product_id); ?>',event)">
			  <svg 
			   <?php 
			   if($product->IsAddedAsFavourite()) { 
             echo "class='ico liked'"; }else{ echo "class='ico'";}
			?> 
			 width="17" height="17" viewBox="0 0 24 24" id="<?php echo e($product->Product_id); ?>"
			 >
           <path d="M12,21.35L10.55,20.03C5.4,15.36 2,12.27 2,8.5C2,5.41 4.42,3 7.5,3C9.24,3 10.91,3.81 12,5.08C13.09,3.81 14.76,3 16.5,3C19.58,3 22,5.41 22,8.5C22,12.27 18.6,15.36 13.45,20.03L12,21.35Z"></path>
          </svg>
          <!-- <img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/002-love.svg" width="22" height="22" alt="" class="ico">  -->
			<input type="hidden" name="<?php echo e($product->Product_id); ?>_text" id="<?php echo e($product->Product_id); ?>_text" <?php 
			   if($product->IsAddedAsFavourite()) { 
             echo "value='Unlike'"; }else{ echo "value='Like'";}
			?>" />
             <div class="like-text" id="<?php echo e($product->Product_id); ?>_div"> 
				 <?php 
			   if($product->IsAddedAsFavourite()) { 
             echo "Unlike"; }else{ echo "Like";}
			?> </div>
          </div>
		  <div class="addtocartbutton" onClick=" return CartAddition('<?php echo e($product->Product_id); ?>',event)">
		  <!-- src='https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Shoplist-Ikea-rzk-version_1.sv'  -->
		  <img
		  <?php 
			 if($product->IsItemAddedtoCart()) { 
             echo "src='https://abccontentbucket.s3.me-south-1.amazonaws.com/images/greentick.svg'"; } else { echo "src='https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Shoplist-Ikea-rzk-version_1.svg'";}
			?>"  width="19" height="19" alt="" class="cart-img" id="<?php echo e($product->Product_id); ?>cartimg">
            <h5 class="addtocarttext" id="<?php echo e($product->Product_id); ?>carttext"> <?php 
			   if($product->IsItemAddedtoCart()) { 
             echo "Added To Cart "; }else{ echo "Add To Cart";}
			?></h5>
          </div>
        </div>
	  </div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
	</div>
   
	<?php endif; ?>
    <div style="display:block" id="main">
	  <?php if( ($products->isEmpty())): ?>
		  <h1>No Products to display </h1>
	  <?php endif; ?>
	  </div>
  
    </div>
	
	
     
	
	
	
	
  </div>
  <div style="display:flex;align-items:center;justify-content:center" id="pagination-container"></div>
</form>
  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('extra-js'); ?>
  <script>
        $(function() {
            console.log("inside pagination function");
            var items = $(".product-display-grid .product-display-div");
			if(items != null && items.length >0){
				$('#pagination-container').show();
				var numItems = items.length;
                var perPage = 5;

                items.slice(perPage).hide();

                $('#pagination-container').pagination({
                    items: numItems,
                    itemsOnPage: perPage,
                    prevText: "&laquo;",
                    nextText: "&raquo;",
                    onPageClick: function (pageNumber) {
                        var showFrom = perPage * (pageNumber - 1);
                        var showTo = showFrom + perPage;
                        items.hide().slice(showFrom, showTo).show();
                    }
                });

			}else{
				$('#pagination-container').hide();
			}
               


        });

        function dynamicpagination(){
            console.log("inside pagination function");
            var items = $(".product-display-grid .product-display-div");
			if(items != null && items.length >0){
				$('#pagination-container').show();
				var numItems = items.length;
                var perPage = 5;

                items.slice(perPage).hide();

                $('#pagination-container').pagination({
                    items: numItems,
                    itemsOnPage: perPage,
                    prevText: "&laquo;",
                    nextText: "&raquo;",
                    onPageClick: function (pageNumber) {
                        var showFrom = perPage * (pageNumber - 1);
                        var showTo = showFrom + perPage;
                        items.hide().slice(showFrom, showTo).show();
                    }
                });
			}else{
				$('#pagination-container').hide();
			}
                
        }
		function checkboxchecking(checkboxname,value)
		{
			console.log("checkboxname = "+checkboxname);
			console.log("passed value = "+value);
			var values = value.split(",");
				console.log("values"+values);
				     	if(values.length > 1 ){
				     			var Checkboxes = document.getElementsByName(checkboxname);
				     			for(var cat in values){
									 console.log("length="+Checkboxes.length);
									 console.log("selected value ="+values[cat]);
				     					for (var i=0; i<Checkboxes.length; i++) {
				     						console.log("value"+Checkboxes[i].value);
				     						if (Checkboxes[i].value == values[cat]) {
												Checkboxes[i].checked = true;
												console.log("Marked as checked")
											 }
											//  else{
											// 			Checkboxes[i].checked = false;
											// 		 }
				     					}

				     			}


				     	}else if(values.length == 1 && values[0] != ""){
				     			var Checkboxes = document.getElementsByName(checkboxname);
				     			for(var cat in values){
				     					for (var i=0; i<Checkboxes.length; i++) {
				     								if (Checkboxes[i].value == values[cat]) {
														Checkboxes[i].checked = true;
													 }
													//  else{
													// 	Checkboxes[i].checked = false;
													//  }

				     					}

				     			}

				     	}
		}


		function fetchData(Selected){
			//alert($("#selCategory").val());
			if($("#selCategory").val() != "ALL"){
				var selCategory = $("#selCategory").val();
			}
			selCategory = selCategory
			$("#selCategory").val(Selected);
			//alert("Hi Inside Form submit function");
			
			//alert($("#selCategory").val());
			$("#Explore").submit();
		}
		
		
		function updatePrice(){
			var min_price = $('#min_price2').val();
			var max_price = $('#max_price2').val();

			$('#min_price1').val(min_price);
			$('#max_price1').val(max_price);
		}
		function fetchDataBasedOnFilter(type){


			event.preventDefault();
			//alert($("#selCategory").val());
			var selected = $("#selCategory").val();
			var checkboxes = document.getElementsByName("category");
			var categories = [];
			for (var i=0; i<checkboxes.length; i++) {
			     // And stick the checked ones onto an array...
			     if (checkboxes[i].checked) {
			     	//alert(checkboxes[i].value);
			     	categories.push(checkboxes[i].value);

			       // alert(checkboxes[i].value);
			   }
			}

			if(categories.length==0){
				categories.push("ALL");
			}
			 // alert(categories);
			 var colourcheckboxes = document.getElementsByName("colours");
			 var selColours = [];
			 for (var i=0; i<colourcheckboxes.length; i++) {
			     // And stick the checked ones onto an array...
			     if (colourcheckboxes[i].checked) {
			     	//alert(checkboxes[i].value);
			     	selColours.push(colourcheckboxes[i].value);

			       // alert(checkboxes[i].value);
			   }
			}
			  // if(selColours.length==0){
			  // 	selColours.push("ALL");
			  // }
			  var colourCount = selColours.length;
			 // alert(selColours.length);
			 // alert(selColours);
			 var brandcheckboxes = document.getElementsByName("Brands");
			 var selBrands = [];
			 for (var i=0; i<brandcheckboxes.length; i++) {
			     // And stick the checked ones onto an array...
			     if (brandcheckboxes[i].checked) {
			     	//alert(checkboxes[i].value);
			     	selBrands.push(brandcheckboxes[i].value);

			       // alert(checkboxes[i].value);
			   }
			}
			  // if(selBrands.length==0){
			  // 	selBrands.push("ALL");
			  // }
			  var brandCount = selBrands.length;
			 // alert(selBrands.length);
			 // alert(selBrands);
			 var min_price = $('#min_price').val();
			 var max_price = $('#max_price').val();

			 var url = "<?php echo e(route('Product.Fetch')); ?>";
			 var _token = '<?php echo csrf_token() ?>';
			 console.log(url);
			//alert(url);
			$.ajax(

			{
				type: "post",
				url: url,
				data: {   
					categories:categories,
					selectedCat : selected,
					selColours : selColours,
					selBrands  :selBrands,
					min_price:min_price,
					max_price:max_price,
					colourCount : colourCount,
					brandCount  : brandCount,
					_token  :_token
				},
				
				success:function(result,e) {
					console.log(result)


					console.log(url);

					console.log(result.products);
		      				// console.log(result.message);
		      				// console.log(result.Sub_Category_ID);
		      				// console.log(result.Category_ID);
                              console.log(result.html);
		      				var products =result.products;
							  console.log(products.length);
							  console.log(typeof(products));
							  product_display(products,event);

		      			},
		      			error:function(result) {
		      				alert('error');
		      				console.log(result);

		      			}
		      	});

		}
		
		
		function CartAddition(productId,e)
		{

			event.preventDefault();
			console.log(productId);
			var imageid = productId+"cartimg";
			var textid = productId+"carttext";
			var imageurl = "https://abccontentbucket.s3.me-south-1.amazonaws.com/images/greentick.svg";
			console.log('imageurl = '+imageurl);
			document.getElementById(imageid).src = imageurl;
			$("#"+textid).empty();
			$("#"+textid).append("Added to Cart")
          //alert(productId +" and "+fromValue);
          var url = "<?php echo e(route('Cart.Add')); ?>";
          var _token = '<?php echo csrf_token() ?>';
           // alert(url);
           // alert(_token);
           $.ajax({
           	type: "post",
           	url: url,
           	data: {   
           		id: productId,
           		Quantity: 1,
           		_token  :_token
           	},
           	success:function(result,e) {
                   // alert(result.message+"and"+ result.count+"and"+ result.success );
                   console.log(result);
                   console.log(result.data);
                   console.log(result.message);
                   console.log(result.count);
                    if(result.count > 0){ //checking cart is empty or not.. if not empty
					  //if not empty
					  if($("#cartCount").length){
						$("#cartCount").css('display','flex');
					    $("#cartCountText").text(result.count);
					  }
					  if($("#cartCount1").length){
						$("#cartCount1").css('display','flex');
					     $("#cartCountText1").text(result.count);
					  }

                      

                  }else{
                      // if cart is empty
					  $("#cartCount").css('display','none');
					  $("#cartCount1").css('display','none');
                  }

                    // e.preventDefault();
                    
                  },//end of success function
                  error:function(result) {
                  	alert('error');
                  	console.log(result);

                  }
              });

       }
	   function RemoveFromWishList(productid,e){
            e.preventDefault();
           // e.stopP
           console.log("Hi inside js function");
            var url = "<?php echo e(route('Favourite.Remove')); ?>";
            var _token = '<?php echo csrf_token() ?>';
            console.log(url);
            console.log(_token);
            $.ajax(

                  {
                  type: "post",
                  url: url,
                  data: {   
                               id: productid,
                         
                         _token  :_token
					   },
					   
                  success:function(result,e) {
                   // alert(result.message+"and"+ result.count+"and"+ result.success );
                    console.log(result);
                      console.log(result.data);
                    console.log(result.message);
                    console.log(result.count);
                    
                    
                   
                    // e.preventDefault();
                    
                  },
                  error:function(result) {
                    alert('error');
                    console.log(result);

                  }
              });

       }
	   function wishListAddition(productId,e)
	   {
		var likeBtn = document.getElementById(productId);

        //   likeBtn.addEventListener('click', function() {
			 likeBtn.classList.toggle('liked');
			 var idcontent = productId+"_text";
			 console.log(idcontent);
			 console.log(document.getElementById(idcontent).value);
			 if(document.getElementById(idcontent).value == "Like"){
				document.getElementById(idcontent).value = "Unlike";
				console.log(document.getElementById(idcontent).value);
				$html = $("<h5 class='like-text'>Unlike</h1>");
				var idvalue = productId+"_div";
				$("#"+idvalue).empty();
				$("#"+idvalue).append($html);
				// $("#"+).append($html);
			 }else{
				document.getElementById(idcontent).value = "Like";
				console.log(document.getElementById(idcontent).value);
				$html = $("<h5 class='like-text'>Like</h1>");
				var idvalue = productId+"_div";
				$("#"+idvalue).empty();
				$("#"+idvalue).append($html);
				
			 }
        //    });
					event.preventDefault();
					var url = "<?php echo e(route('Favourite.Add')); ?>";
					var _token = '<?php echo csrf_token() ?>';
					// alert(url);
					// alert(_token);
					$.ajax({
						type: "post",
						url: url,
						data: {   
							id: productId,
							Quantity: 1,
							_token  :_token
						},
						success:function(result,e) {
							// alert(result.message+"and"+ result.count+"and"+ result.success );
							console.log(result);
							console.log(result.data);
							console.log(result.message);
							console.log(result.count);
							if(result.AlreadyAdded){
								RemoveFromWishList(productId,event);
							}


							

								// e.preventDefault();
								
							},
							error:function(result) {
								// alert('error');
								console.log(error);
								console.log(result);

							}
						});

        }


	   function product_display(products,event)
	     {
			//  async:true;
			// event.preventDefault();
			 	console.log("type of produvts "+products);
				$("#productList").empty();
				$( "#main" ).empty();
				var $html="";
				if(products.length == 0){
					$html = $("<h1>No Products to display</h1><br>");
					$( "#main" ).append( $html);
					dynamicpagination();
				}else{
					for (var product in products) {
						console.log(typeof(products[product]));
						var url = "<?php echo e(route('Product.description', ':id')); ?>";
						url = url.replace(':id', products[product].Product_id);
						
						// var carturl = "https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Shoplist-Ikea-rzk-version_1.svg";
						var likeurl = "https://abccontentbucket.s3.me-south-1.amazonaws.com/images/002-love.svg";
						var producturl =  "https://abccontentbucket.s3.me-south-1.amazonaws.com/images/"+products[product].MainImage;
						// producturl = producturl.replace(':image', products[product].MainImage);
						var addedasfavourite = products[product].addedAsFavourite;
						var styleinfo ="ico";
						var textvalue="Like";
						if(addedasfavourite){
							styleinfo ="ico liked";
							textvalue = "Unlike";
						}
						console.log(products[product].addedToCart);
						var carttextvalue="Add to Cart";
						var isaddedToCart = products[product].addedToCart;
						console.log("isaddedToCart"+ products[product].product_name +" is "+isaddedToCart);
						if(isaddedToCart){
							var carturl = "https://abccontentbucket.s3.me-south-1.amazonaws.com/images/greentick.svg";
							carttextvalue = "Added to Cart";
						}else{
							var carturl = "https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Shoplist-Ikea-rzk-version_1.svg";
							
						}
						
                        
					    $html = $("<div class='product-display-div'><div class='productlink-holding-div'><a href='"+ url +"' class='combocolorandavoidunderline w-inline-block'><div class='product-image-div'><img src='"+producturl+"'  height='235' width='400' id='pro_pic"+products[product].Product_id+"'  data-w-id='929cb5a7-833d-a883-92ec-fe7a5c2c664a' alt='' class='product-image'></div><div class='product-name combocolor'>"+ products[product].product_name +"</div></a></div><div class='fav-cart'><div class='fav' onClick='wishListAddition(\""+ products[product].Product_id +"\",event)' ><svg class='"+styleinfo+"' width='17' height='17' viewBox='0 0 24 24' id='"+products[product].Product_id+"'><path d='M12,21.35L10.55,20.03C5.4,15.36 2,12.27 2,8.5C2,5.41 4.42,3 7.5,3C9.24,3 10.91,3.81 12,5.08C13.09,3.81 14.76,3 16.5,3C19.58,3 22,5.41 22,8.5C22,12.27 18.6,15.36 13.45,20.03L12,21.35Z'></path></svg><input type='hidden' name='"+products[product].Product_id+"_text' id='"+products[product].Product_id+"_text' value='"+textvalue+"' /><div class='like-text' id='"+products[product].Product_id+"_div'>Like</div></div><div class='addtocartbutton' onClick='CartAddition(\""+ products[product].Product_id +"\",event)'><img src='"+carturl+"' width='19' height='19' alt='' class='cart-img' id='"+products[product].Product_id+"cartimg'><h5 class='addtocarttext' id='"+products[product].Product_id+"carttext'>"+carttextvalue+"</h5></div></div></div>");
						$( "#productList" ).append( $html);
						dynamicpagination();
					}
					
				}
         }
       function updateCategory(){
       						if(document.getElementsByName("category1").length != 0){ 
       						var selectedValues = "";
       				    // if($("#SelectedSUBCategories").val()!=""){
       				    // 	selectedValues = $("#SelectedSUBCategories").val()+","; 
						   // }
						//    if($(this).prop("checked") == false){
						// 		$(this).prop('checked', true);
            			// 	}else{
						// 		$(this).prop('checked', false);
						// 	}
       				    var checkboxes = document.getElementsByName("category1");
       				    var categories = [];
       				    for (var i=0; i<checkboxes.length; i++) {
						     // And stick the checked ones onto an array...
						     if (checkboxes[i].checked) {
						     	//alert(checkboxes[i].value);
						     	categories.push(checkboxes[i].value);

						       // alert(checkboxes[i].value);
						   }
						}

						if(categories.length==0){
							categories.push("ALL");
						}
						// selectedValues += categories;
						$("#SelectedSUBCategories").val(categories);
						
						 console.log($("#SelectedSUBCategories").val());
						// console.log($("#SelectedColours").val());
						// console.log($("#SelectedBrands").val());
					}
				} 
				function updateBrand(){
					if(document.getElementsByName("Brands1").length != 0){ 
						console.log("Inside updateBrand function");
						var selectedValues = "";
						
       				    
       				    var brandcheckboxes = document.getElementsByName("Brands1");
       				    var brands = [];
       				    for (var i=0; i<brandcheckboxes.length; i++) {
						     // And stick the checked ones onto an array...
						     if (brandcheckboxes[i].checked) {
						     	//alert(checkboxes[i].value);
						     	brands.push(brandcheckboxes[i].value);

						       // alert(checkboxes[i].value);
						    }
						}

						$("#SelectedBrands").val('');
						$("#SelectedBrands").val(brands);
						
						console.log($("#SelectedBrands").val());
					}
				}	
				function updateColour(){
					if(document.getElementsByName("colours1").length != 0){ 
						var selectedValues = "";
						
       				    var colourcheckboxes = document.getElementsByName("colours1");
       				    var colours = [];
       				    for (var i=0; i<colourcheckboxes.length; i++) {
						    
						     if (colourcheckboxes[i].checked) {
						     	
						     	colours.push(colourcheckboxes[i].value);

						      
						   }
						}
						$("#SelectedColours").val(colours);
						// console.log($("#SelectedSUBCategories").val());
						 console.log($("#SelectedColours").val());
						// console.log($("#SelectedBrands").val());
					}
				}
			function fetchDataBasedOnMobileFilter()
			{
					event.preventDefault();
					console.log("Hi inside filter function");
					var selBrands =[];
					var selColours =[];
					var categories =[];
					var min_price = 0;
					var max_price =6000;
					var str = $("#SelectedSUBCategories").val();
					var branddd = $("#SelectedBrands").val();
					var colourrr = $("#SelectedColours").val();
				    categories = str.split(",");
					selBrands = branddd.split(",");
					selColours = colourrr.split(",");
					var categorycount = categories.length;
					var colourCount = selColours.length;
					var brandCount = selBrands.length;
					
					min_price = $('#min_price1').val();
					max_price = $('#max_price1').val();
					console.log($("#SelectedSUBCategories").val());
					console.log($("#SelectedColours").val());
					console.log($("#SelectedBrands").val());
					if(colourCount == 1 && selColours[0] == "" ){
						colourCount =0;
					}
					if(brandCount == 1 && selBrands[0] == "" ){
						brandCount =0;
					}
					if(categorycount == 1 && categories[0] == "" ){

						categories[0]="ALL";
					}
					console.log(selBrands);
					console.log(selColours);

					console.log(categories);
					console.log($('#min_price1').val());
					console.log($('#max_price1').val());
					console.log("colourcount"+colourCount);
					console.log("brandCount"+brandCount);

					var url = "<?php echo e(route('Product.Fetch')); ?>";
					var _token = '<?php echo csrf_token() ?>';
							//alert(url);
							$.ajax(

							{
								type: "post",
								url: url,
								data: {   
									categories : categories,
									selectedCat : 'selected',
									selColours : selColours,
									selBrands  : selBrands,
									min_price : min_price,
									max_price : max_price,
									colourCount : colourCount,
									brandCount  : brandCount,
									_token  :_token
								},
								success:function(result,e) {
									console.log(result)


									console.log(url);

									console.log(result.products);
						      				// console.log(result.message);
						      				// console.log(result.Sub_Category_ID);
						      				// console.log(result.Category_ID);
											  var products =result.products;
											  console.log(result);
						      				console.log(products);
                                              console.log(result.html);
						      				product_display(result.products, event);

						      			},
						      			error:function(result) {
						      				alert('error');
						      				console.log(result);

						      			}
						    });
							console.log("Successfully executed");
							$("#filtermodel").hide();
							// $("#apply").hide();
							// $("#resetButton").hide();


			}
		function reset(){
					console.log("Inside the reset function");
					$("#mobileForm").submit();
		}
		function showmodel(){
        console.log("Hi I am inside the model displaying");

        if($("#filtermodel").length){
             $("#filtermodel").css("display", "block");
             $('.modal-wrapper-copy').show();
             $('.modal-wrapper-copy').css("opacity", 100);
             console.log("HI");
		}
		// else{
        //   $('.modal-wrapper-copy').show();
        // }

      }	
</script>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\Projects\ABC3\ABC_hosted\resources\views\product\Explore.blade.php ENDPATH**/ ?>