<div class="max-w-sm mx-auto py-8">
    <form action="/productimages" method="post" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

        <input type="file" name="image" id="image">
        <button type="submit">Upload</button>
    </form>
</div>

<img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/HOtgM4DGlVnUTkZvHeP3iuzOwDp1R6Zp1hStr3rt.jpeg" /><?php /**PATH C:\wamp\www\Projects\ABC3\ABC_hosted\resources\views\imageUploadingPage.blade.php ENDPATH**/ ?>