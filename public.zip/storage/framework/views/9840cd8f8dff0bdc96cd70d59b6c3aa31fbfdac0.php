
<br>

Thank you For your subscription
<br>


** Email:** <?php echo e($newsletter->SubscriberMailid); ?>  <br>








<br>

Thank you <br>

Regards,<br>
Abc Website


<?php /**PATH C:\wamp\www\Projects\ABC3\ABC_hosted\resources\views\emails\newsletter.blade.php ENDPATH**/ ?>