
<?php $__env->startSection('content'); ?>
  <div data-w-id="2b1ccfe9-16e2-35fe-01f4-6f6fbf849d25" class="pro-description w-container">

  <form method="post"  action="<?php echo e(route('Product.description.option')); ?>" id="Description">
    
    <?php echo csrf_field(); ?>
          <?php if(session('message')): ?>
           <h3><?php echo e($message ?? ''); ?></h3>
          <?php endif; ?>
      
         
        <?php if(!empty($product)): ?>
        <input type="hidden" name="productID" id="productID" value="<?php echo e($product->Product_id); ?>">
        <div class="outlineSocialShare">
        <a  style="display:flex; justify-content:center; align-items:center; " href="https://twitter.com/share?url=http%3A%2F%2F192.168.1.196%3A8000%2FDescription%2F<?php echo e($product->Product_id); ?>"  title="Tweet this page on twitter!">
            <i class="fa fa-twitter"></i>
        </a>
        <a  style="display:flex; justify-content:center; align-items:center; " href="https://www.linkedin.com/shareArticle?mini=true&url=http%3A%2F%2F192.168.1.196%3A8000%2FDescription%2F<?php echo e($product->Product_id); ?>"  title="Share this page on Linkedin!">
            <i class="fa fa-linkedin"></i>
        </a>
            <a  style="display:flex; justify-content:center; align-items:center; " href="https://www.facebook.com/sharer.php?u=http%3A%2F%2F192.168.1.196%3A8000%2FDescription%2F<?php echo e($product->Product_id); ?>&amp;t=TITLE" title="Share this page on Facebook!">
              <i class="fa fa-facebook"></i></a>
        <a  style="display:flex; justify-content:center; align-items:center; " href="https://api.whatsapp.com/send?text=https://api.whatsapp.com/send?text=http%3A%2F%2F192.168.1.196%3A8000%2FDescription%2F<?php echo e($product->Product_id); ?>" title="Share On Whatsapp" >    
            <i class="fa fa-whatsapp"></i>
        </a>
        </div>
    <div class="w-layout-grid page-layout-grid">
      <div id="w-node-cda86d3e8214-5d33da88" class="image-gallery-div">
        <div data-animation="slide" data-duration="500" data-infinite="1" class="slider-2 w-slider">
          <div class="w-slider-mask">
          <?php if(isset($product->Thumpnail1)): ?>
          <div class="slide w-slide"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/<?php echo e($product->Thumpnail1); ?>" loading="lazy" alt="" class="image-54"></div>
          
          <?php endif; ?>
          <?php if(isset($product->Thumpnail2)): ?>
          <div class="w-slide"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/<?php echo e($product->Thumpnail2); ?>" loading="lazy" alt="" class="image-54"></div>
          
          <?php endif; ?>
          <?php if(isset($product->Thumpnail3)): ?>
          <div class="w-slide"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/<?php echo e($product->Thumpnail3); ?>" loading="lazy" alt="" class="image-54"></div>
          <?php endif; ?>
          <?php if(isset($product->Thumpnail4)): ?>
          <div class="w-slide"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/<?php echo e($product->Thumpnail4); ?>" loading="lazy" alt="" class="image-54"></div>
          
          <?php endif; ?>
          <?php if(isset($product->Thumpnail5)): ?>
          <div class="w-slide"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/<?php echo e($product->Thumpnail5); ?>" loading="lazy" alt="" class="image-54"></div>
          
          <?php endif; ?>
            
          </div>
          <div class="w-slider-arrow-left">
            <div class="w-icon-slider-left"></div>
          </div>
          <div class="w-slider-arrow-right">
            <div class="w-icon-slider-right"></div>
          </div>
          <div class="slide-nav-2 w-slider-nav w-round"></div>
        </div>
        <div class="thumpnail-holding-div" id="thumpwraper">
          <?php if(isset($product->Thumpnail1)): ?>
          <div class="thumpnail thumpactive" id = "thumpnail1"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/<?php echo e($product->Thumpnail1); ?>" loading="lazy" alt="" class="image-45"></div>
          <?php endif; ?>
          <?php if(isset($product->Thumpnail2)): ?>
          <div class="thumpnail" id = "thumpnail2"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/<?php echo e($product->Thumpnail2); ?>" loading="lazy" alt="" class="image-45"></div>
          <?php endif; ?>
          <?php if(isset($product->Thumpnail3)): ?>
          <div class="thumpnail" id = "thumpnail3"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/<?php echo e($product->Thumpnail3); ?>" loading="lazy" alt="" class="image-45"></div>
          <?php endif; ?>
          <?php if(isset($product->Thumpnail4)): ?>
          <div class="thumpnail" id = "thumpnail4"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/<?php echo e($product->Thumpnail4); ?>" loading="lazy" alt="" class="image-45"></div>
          <?php endif; ?>
          <?php if(isset($product->Thumpnail5)): ?>
          <div class="thumpnail" id = "thumpnail5"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/<?php echo e($product->Thumpnail5); ?>" loading="lazy" alt="" class="image-45"></div>
          <?php endif; ?>
          
        </div>
        <div class="main-image-div"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/<?php echo e($product->MainImage); ?>" loading="lazy" alt="" class="image-50" id="productImage"></div>
      </div>
      <div id="w-node-9f90e2661ba7-5d33da88" class="product-description-div">
        <h5 class="brand-text"><?php echo e($product->Brand); ?></h5>
        <h2 class="product-name-text"><?php echo e($product->product_name); ?> - <?php echo e($product->Product_id); ?></h2>
        <div class="availability-div">
          <h6 class="availability-text">Availability</h6>
          <?php if( $product->unit_in_stock >0): ?>
               <div class="button">
              <h6 class="in-stock-text">in stock</h6>
            </div>
            <?php else: ?>
               <div class="button" style="background-color: #bb0303">
              <h6 class="in-stock-text">Out of stock</h6>
            </div>
            <?php endif; ?>
          
        </div>
        <?php if(!empty($product->Available_sizes)): ?>
        <div class="option-div">
          <h6 class="heading-25">Choose an option</h6>
          <div class="option-listing-div">
                <input type="hidden" name="SelSize" id="SelSize" value="">
                
                <?php $__currentLoopData = explode(',', $product->Available_sizes); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $col = "white";
                $textcolor = "black";
                  $pcolour = strtoupper($product->size);
                  $ocolour = strtoupper($option);
                  if(strcmp($pcolour,$ocolour) == 0){
                      $col = "#bb0303"; 
                      $textcolor = "white";
                  }
                ?>
            <div class="button-copy" style="background-color:<?php echo e($col); ?> " onClick = "SelOption('<?php echo e($option); ?>','<?php echo e($product->Product_id); ?>','size')">
              <h6 class="heading-16" style="color:<?php echo e($textcolor); ?> "><?php echo e($option); ?></h6>
            </div>
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
        <?php endif; ?>
        <?php if(!empty($product->Available_sizes)): ?>
        <div class="option-div">
          <h6 class="heading-25">Available colours</h6>
          <div class="option-listing-div">
          <input type="hidden" name="SelColour" id="SelColour" value="">
            <?php $__currentLoopData = explode(',', $product->Available_colours); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
              $col1 = "white";
              $textcolor = "black";
              $pcolour = strtoupper($product->colour);
              $ocolour = strtoupper($option);
              if(strcmp($pcolour,$ocolour) == 0){
                   $col1 = "#bb0303"; 
                   $textcolor = "white";
               }
            ?>
            <div class="button-copy" style="margin-right: 5px;background-color:<?php echo e($col1); ?>" onClick = "SelOption('<?php echo e($option); ?>','<?php echo e($product->Product_id); ?>','colour')">
              <h6 class="heading-16" style="color:<?php echo e($textcolor); ?> "><?php echo e($option); ?></h6>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
        <?php endif; ?>
        <!-- <div class="option-listing-div">
          
            
            <div >
              <h3 class="heading-16"> <?php echo e($product->presentPrice()); ?></h3>
            </div>
        </div> -->
        <div class="cart-and-qty-div">
        <?php if( $product->unit_in_stock >0): ?>
        <div class="html-embed-2 w-embed">
            <center><select name="quantity" autocomplete="off" id="quantity" tabindex="0" class="a-native-dropdown" style="width:70%; height:90%;margin-top:20px">
                    <option value="1" selected="">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                    <option value="6">6</option>
                    <option value="7">7</option>
                    <option value="8">8</option>
                    <option value="9">9</option>
                    <option value="10">10</option>
                    <option value="11">11</option>
                    <option value="12">12</option>
                    </select>
            </center>
          </div>
          <?php endif; ?>
          <input type="hidden" value = "<?php echo e($product->Product_id); ?>" id = "Product_id">
          <div class="div-block-108">
            
            <?php if( $product->unit_in_stock >0): ?>
            <div class="addtocartbuttondescription" id = "<?php echo e($product->Product_id); ?>"  onClick= "AddToCart(event)">
            <img
		  <?php 
			 if($product->IsItemAddedtoCart()) { 
             echo "src='https://abccontentbucket.s3.me-south-1.amazonaws.com/images/greentick.svg'"; } else { echo "src='https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Shoplist-Ikea-rzk-version_1.svg'";}
			?>  width="19" height="19" alt="" class="cart-img" id="product<?php echo e($product->Product_id); ?>cartimg">
            <h5 class="addtocarttext" id="product<?php echo e($product->Product_id); ?>carttext"> 
            <?php 
			   if($product->IsItemAddedtoCart()) { 
             echo "Added To Cart "; }else{ echo "Add To Cart";}
			?></h5>
            </div>
            <?php endif; ?>
            <div class="fav-copy addtocartbutton" id = "<?php echo e('Favourite'.$product->Product_id); ?>"  onClick= "AddToFavourite(event)">
            <svg 
            <?php 
			   if($product->IsAddedAsFavourite()) { 
             echo "class='ico liked'"; }else{ echo "class='ico'";}
			   ?> 
             width="17" height="17" viewBox="0 0 24 24" id="product<?php echo e($product->Product_id); ?>">
          <path d="M12,21.35L10.55,20.03C5.4,15.36 2,12.27 2,8.5C2,5.41 4.42,3 7.5,3C9.24,3 10.91,3.81 12,5.08C13.09,3.81 14.76,3 16.5,3C19.58,3 22,5.41 22,8.5C22,12.27 18.6,15.36 13.45,20.03L12,21.35Z"></path>
          </svg>
         <input type="hidden" name="product_<?php echo e($product->Product_id); ?>_text" id="product_<?php echo e($product->Product_id); ?>_text" <?php 
			   if($product->IsAddedAsFavourite()) { 
             echo "value='Unlike'"; }else{ echo "value='Like'";}
			       ?>" />
             <div class="like-text" id="product_<?php echo e($product->Product_id); ?>_div"> 
				 <?php 
			   if($product->IsAddedAsFavourite()) { 
             echo "Unlike"; }else{ echo "Like";}
			    ?> </div>
              
            </div>
            <div class="favbuttondescription" id = "<?php echo e('Favourite1'.$product->Product_id); ?>"  onClick= "AddToFavourite(event)">
               <img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/002-love.svg" width="19" height="19" alt="" class="favimage">
              <div class="like-text-copy">Like</div>
            </div>
          </div>
        </div>
        <!-- onclick="window.open('whatsapp:\/\/send?text=' + encodeURIComponent(document.URL)); return false;" -->
        <!-- <a  class="div-block-122" href="https://api.whatsapp.com/send?text=https://api.whatsapp.com/send?text=http%3A%2F%2F192.168.1.196%3A8000%2FDescription%2F<?php echo e($product->Product_id); ?>" title="Share On Whatsapp" ><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/003-whatsapp.svg" loading="lazy" width="26" height="20"  alt="" class="image-67">
          <h6 class="heading-34">Share </h6>
         </a> -->
      </div>
      <div class="detailing-div">
        <div class="description-div">
          <h4 class="detailing-headings">DESCRIPTION</h4>
          <p class="paragraph-9"><?php echo e($product->long_description); ?></p>
        </div>
        <div class="specification-heading">
          <h4 class="detailing-headings">Specifications</h4>
        </div>
        <div class="w-layout-grid specification-list-grid">
          <div id="w-node-9f90e2661b83-5d33da88" class="greydiv">
            <h4 class="specifications-text">Itemcode</h4>
          </div>
          <div class="lightgreydiv">
            <h4 class="specifications-description"><?php echo e($product->Product_id); ?></h4>
          </div>
          <div id="w-node-9f90e2661b89-5d33da88" class="greydiv">
            <h4 class="specifications-text">Brand</h4>
          </div>
          <div class="lightgreydiv">
            <h4 class="specifications-description"><?php echo e($product->Brand); ?></h4>
          </div>
          <div id="w-node-9f90e2661b8f-5d33da88" class="greydiv">
            <h4 class="specifications-text">Size</h4>
          </div>
          <div class="lightgreydiv">
            <h4 class="specifications-description"><?php echo e($product->size); ?></h4>
          </div>
          <div id="w-node-9f90e2661b95-5d33da88" class="greydiv">
            <h4 class="specifications-text">Classification</h4>
          </div>
          <div class="lightgreydiv">
            <h4 class="specifications-description"><?php echo e($product->categories->Category_Name); ?></h4>
          </div>
          <div id="w-node-9f90e2661b9b-5d33da88" class="greydiv">
            <h4 class="specifications-text">Material</h4>
          </div>
          <div class="lightgreydiv">
            <h4 class="specifications-description"><?php echo e($product->material); ?></h4>
          </div>
          <div id="w-node-9b26c9b1bb4e-5d33da88" class="greydiv">
            <h4 class="specifications-text">colour</h4>
          </div>
          <div class="lightgreydiv">
            <h4 class="specifications-description"><?php echo e($product->colour); ?></h4>
          </div>
          <div id="w-node-9f90e2661ba1-5d33da88" class="greydiv">
            <h4 class="specifications-text">Space</h4>
          </div>
          <div class="lightgreydiv">
            <h4 class="specifications-description"><?php echo e($product->Application); ?></h4>
          </div>
        </div>
      </div>
      <?php if(!empty($relatedProducts) && $relatedProducts->count()>1): ?>
      <div id="w-node-9f90e2661bc6-5d33da88" class="related-products">
        <div class="div-with-border">
          <h4 class="detailing-headings combo">Frequently bought together</h4>
          <div class="w-layout-grid related-product-div">
            <div class="product-image-div"><!--  -->
              <a href="<?php echo e(route('Product.description', $product->Product_id)); ?>" >  
                  <img height="150" width="200" src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/<?php echo e($product->MainImage); ?>" data-w-id="043e5686-14b4-8749-315b-9f90e2661bcc" alt="" class="product-image">
                  <!-- <h4 class="related-product-heading"><?php echo e($product->product_name); ?></h4> -->
              </a>
              <a href="<?php echo e(route('Product.description', $product->Product_id)); ?>"  style="padding-left: 5px;padding-right: 5px;font-color: black;font-family: 'Sofiapro';font-size: 13px;" >
                   <h4 class="related-product-heading"><?php echo e($product->product_name); ?></h4>
              </a>

            </div>

            <?php
                  $i=0;
                  
            ?>
            <?php $__currentLoopData = $relatedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $i++;
                 
                  
            ?>

            <div class="product-image-div">
            <input type="hidden" name="<?php echo e('rel'.$i); ?>"  id="<?php echo e('rel'.$i); ?>" value = "<?php echo e($item->Related_Product_id); ?>">
              <a href="<?php echo e(route('Product.description', $item->Related_Product_id)); ?>" class="combocolorandavoidunderline w-inline-block">  
                  <img height="150" width="200" src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/<?php echo e($item->MainImage); ?>" data-w-id="043e5686-14b4-8749-315b-9f90e2661bcc" alt="" class="product-image">
                  <!-- <h4 class="related-product-heading"><?php echo e($item->product_name); ?></h4> -->
              </a>
              <a href="<?php echo e(route('Product.description', $item->Related_Product_id)); ?>"  style="padding-left: 5px;padding-right: 5px;font-color: black;font-family: 'Sofiapro';font-size: 13px;">
                   <h4 class="related-product-heading"><?php echo e($item->product_name); ?></h4>
              </a>

            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
          <div class="addtocartbutton" onClick="BuyTogetherItemsToCart('<?php echo e($product->Product_id); ?>',event)"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Shoplist-Ikea-rzk-version_1.svg" width="19" height="19" alt="" class="cart-img">
            <div class="buy-together">Buy Together</div>
          </div>
        </div>
      </div>
      <?php endif; ?>
    </div>
    <?php endif; ?>
    </form>
  </div>
  
  <?php echo $__env->make('Common.SimilarProducts_scroll_div', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
  <div class="whatsappbox"><a href="https://api.whatsapp.com/send?phone=971564130262&amp;abid=971564130262" class="link-block-category w-inline-block"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/001-whatsapp.svg" width="35" height="35" alt="" class="whatsapp-icon"><h5 class="chat-with-us">Chat<br>with Us</h5></a></div>
 <?php $__env->stopSection(); ?>
 <?php $__env->startSection('extra-js'); ?>
  <script type="text/javascript">
    // <?php echo e(url('office/service/requirement/rule_delete/')); ?>

        function AddToCart(event){

          event.preventDefault();
          //event.stopPropagation();
          
          console.log("HI");
          var Product_id = $("#Product_id").val();
          var url = "<?php echo e(route('Cart.Add')); ?>";
          console.log(url);
          console.log(Product_id);
          var imageid = "product"+Product_id+"cartimg";
			    var textid = "product"+Product_id+"carttext";
			    var imageurl = "https://abccontentbucket.s3.me-south-1.amazonaws.com/images/greentick.svg";
          console.log('imageurl = '+imageurl);
          document.getElementById(imageid).src = imageurl;
          $("#"+textid).empty();
          $("#"+textid).append("Added to Cart");
           var _token = '<?php echo csrf_token() ?>';
           console.log(url);
           $.ajax(

                  {
                  type: "post",
                  url: url,
                  //alert(url);
                  
                  data: {  id: $("#Product_id").val(), Quantity: $("#quantity").val() ,  _token:_token},
                  success:function(result,e) {
                   // alert(result.message+"and"+ result.count+"and"+ result.success );
                    console.log(result);
                      console.log(result.data);
                    console.log(result.message);
                    console.log(result.count);
                    if(result.count > 0){
                      if($("#cartCount").length){
                        $("#cartCount").css('display','flex');
                          $("#cartCountText").text(result.count);
                        }
                        if($("#cartCount1").length){
                        $("#cartCount1").css('display','flex');
                          $("#cartCountText1").text(result.count);
                        }
                    
                    }else{
                      $("#cartCount").css('display','none');
                      $("#cartCount1").css('display','none');
                    }
                    
                    
                    // e.preventDefault();
                    
                  },
                  error:function(result) {
                    alert('error');
                    console.log(result);

                  }
              });
           
        
       }


        $(function() { 
          $('[data-toggle="tooltip"]').tooltip();
          var Product_id = $("#Product_id").val();
          var qty = $("#quantity").val();

          $.ajaxSetup({
                        headers: {
                          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                          // 'Content-Security-Policy':$('meta[name="Content-Security-Policy"]').attr('upgrade-insecure-requests') 
                        }
                      });
          $(".thumpnail").on('click',function(event){
                
                $(".thumpnail").removeClass("thumpactive");
                $(this).addClass("thumpactive");
                var $pic = $(this).find('img');
                $('#productImage').attr('src',$pic.attr('src'));

               
            });
        });
        function AddToFavourite(event){

          event.preventDefault();
          //event.stopPropagation();
          var Product_id = $("#Product_id").val();
          var likeBtn = document.getElementById("product"+Product_id);

        //   likeBtn.addEventListener('click', function() {
			 likeBtn.classList.toggle('liked');
			 var idcontent = "product_"+Product_id+"_text";
			 console.log(idcontent);
			 console.log(document.getElementById(idcontent).value);
			 if(document.getElementById(idcontent).value == "Like"){
				document.getElementById(idcontent).value = "Unlike";
				console.log(document.getElementById(idcontent).value);
				$html = $("<h5 class='like-text'>Unlike</h1>");
				var idvalue = "product_"+Product_id+"_div";
				$("#"+idvalue).empty();
				$("#"+idvalue).append($html);
				// $("#"+).append($html);
			 }else{
				document.getElementById(idcontent).value = "Like";
				console.log(document.getElementById(idcontent).value);
				$html = $("<h5 class='like-text'>Like</h1>");
				var idvalue = "product_"+Product_id+"_div";
				$("#"+idvalue).empty();
				$("#"+idvalue).append($html);
				
			 }
          console.log("HI");
          // var Product_id = $("#Product_id").val();
          var url = "<?php echo e(route('Favourite.Add')); ?>";
          console.log(url);
          console.log(Product_id);
           var _token = '<?php echo csrf_token() ?>';
           console.log(url);
           $.ajax(

                  {
                  type: "post",
                  url: url,
                  //alert(url);
                  
                  data: {  id: $("#Product_id").val(), Quantity: $("#quantity").val() },
                  success:function(result,e) {
                   // alert(result.message+"and"+ result.count+"and"+ result.success );
                    console.log(result);
                      console.log(result.data);
                    console.log(result.message);
                    console.log(result.count);
                    // if(result.count > 0){
                    //   $("#cartCount").css('display','inline');
                    //   $("#cartCountText").text(result.count);
                    
                    // }else{
                    //   $("#cartCount").css('display','none');
                    // }
                    
                    
                    // e.preventDefault();
                    
                  },
                  error:function(result) {
                    alert('error');
                    console.log(result);

                  }
              });
           
       }
        function BuyTogetherItemsToCart(selectedProduct,event){

          event.preventDefault();
          //event.stopPropagation();
          console.log("HI");
          console.log(selectedProduct);
          var multipleItems = [];
          multipleItems.push(selectedProduct);
          if($("#rel1"). length){
              multipleItems.push($("#rel1").val());
          }
          if($("#rel2"). length){
              multipleItems.push($("#rel2").val());
          }
          var url = "<?php echo e(route('Cart.Add.Multiple')); ?>";
          var _token = '<?php echo csrf_token() ?>';
            console.log(url);
               $.ajax(

                  {
                  type: "post",
                  url: url,
                  data: {
                            multipleItems: multipleItems, 
                            Quantity: $("#quantity").val()
                        },
                  success:function(result,e) {
                   // alert(result.message+"and"+ result.count+"and"+ result.success );
                    console.log(result);
                    console.log(result.message);
                    console.log(result.count);
                    if(result.count > 0){
                      if($("#cartCount").length){
                                $("#cartCount").css('display','flex');
                                  $("#cartCountText").text(result.count);
                                }
                                if($("#cartCount1").length){
                                $("#cartCount1").css('display','flex');
                                  $("#cartCountText1").text(result.count);
                                }
                    
                    }else{
                      $("#cartCount").css('display','none');
                      $("#cartCount1").css('display','none');
                    }
                    
                    
                    // e.preventDefault();
                    
                  },
                  error:function(result) {
                    alert('error');
                    console.log(result);

                  }
              });


         
        
         
       }
       function SelOption(Option,productID,type){
          if(type == "size"){
              $("#SelSize").val(Option);
          }else{
              $("#SelColour").val(Option);
          }
          $("#Description").submit();
       }

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\Projects\ABC3\ABC_hosted\resources\views\product\Description.blade.php ENDPATH**/ ?>