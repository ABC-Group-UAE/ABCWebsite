


<?php $__env->startSection('content'); ?>


  <div class="map-div w-clearfix">
    <div class="map w-widget w-widget-map" id="map">
        
    </div>
    <div class="select-map">
      <div class="text-block-35">Select A COUNTRY</div>
      <div data-hover="" data-delay="0" class="w-dropdown">
        
          <select id="country">
              <option value="all"> All Countries</option>
              <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
              <option value=<?php echo e($country->country); ?>><?php echo e($country->country); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        
    </div>
  </div>
  </div>
  <div class="columns w-row" id="showrooms">
    
  </div>
  
  
  <script src="js/webflow.js" type="text/javascript"></script>
  <script src="https://polyfill.io/v3/polyfill.min.js?features=default"></script>
  <script type="text/javascript" src="js/jquery.min.1.7.js"></script>    
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBWAoTTxe-AP75PMSqu_-TpaEPG-Eo4mp4&callback=initMap&libraries=&v=weekly" defer></script>
  <script>
    "use strict";
    const iconbase='images/'
    let map;
    var marker;
    var infoWindow;
    //var locate="<?php echo json_encode($locations->toArray(), JSON_HEX_TAG); ?>";
    var locate=<?php echo json_encode($locations, 15, 512) ?>;
    var styles = [{
        "stylers": [{
            "saturation": -100
        }]
    }];

    
    function initMap() {
      //c
      map = new google.maps.Map(document.getElementById("map"), {
        center: {
            lat: 24.466667,
            lng: 54.366669,
          },
        zoom: 3,
        styles:styles,
        zoomControl: false,
      });
      marker = new google.maps.Marker({
       
        icon: "https://abccontentbucket.s3.me-south-1.amazonaws.com/images/location.svg",
          title:"ABC",  
          draggable: true,
          map: map
      });
    }
    
    $(document).ready(function(){
      //console.log(locate);
      // for(var local in locate){
      //     console.log(locate[local].street);
      // }
     
      var sel=$('#country').val();
      console.log(sel);
      if(sel=="all"){
        changecountry(locate,"all");
      }
 
      $('#country').on("change",function(){
      console.log("Clicked");
      var showrooms="";
      var lat=new Array();
      var long=new Array();
      var centerlat;
      var centerlon;
      var country_name = $(this).val();
      var contentstring;
      console.log(country_name);

      var url="<?php echo e(URL('/locationfilter')); ?>";
      if(country_name=="all"){
        changecountry(locate,"all");
      }else{
        $("#showrooms").empty();
      $.ajax({
        url: url,
        type:"GET",
        
        data:{
          country_name:country_name,
          
        },
        success:function(response){
          //console.log("success msg");
          //console.log(response.length);
          var location_info=response
          for(var info in location_info){
              //console.log(location_info[info].street);
              showrooms+="<div class='w-col w-col-3'><div class='text-block-36'>"+location_info[info].showroom+"</div><div>"+location_info[info].street+","+location_info[info].city+"</div>"+
              "<div>"+location_info[info].email+"</div><div>"+location_info[info].phone_no+"</div></div>";

          }

          changecountry(location_info,country_name);
          //contentstring="<div style='max-height:400px;'><b>ABC Group UAE</b><br>Alif International<br>King Faisal Street Sharjah<br>abc@gmail.com<br>+97165434460</div>";
          $("#showrooms").html(showrooms);
           }
        
       });
        
      }
    
              //   if(fval=="UAE"){
              //     contentstring="<div style='max-height:400px;'><b>ABC Group UAE</b><br>Alif International<br>King Faisal Street Sharjah<br>abc@gmail.com<br>+97165434460</div>";
              //      centerlat=25.324949;
              //      centerlon=55.401567;
              //      lat=[25.324949,25.341121];
              //     long=[55.401567,55.628494];
              //     changecountry(lat,long,centerlat,centerlon,contentstring);
                  
              //   }
              //   if(fval=="OMAN"){
              //     contentstring="<div style='max-height:400px;'><b>ABC Group OMAN</b><br>ABC ceramics LLc<br>Ruwai Oman<br><a href='#'>abc@gmail.com</a><br>+97165434460</div>";
              //     centerlat=23.585376;
              //     centerlon=58.545577;
              //     lat=[23.585376,23.660141];
              //     long=[ 58.545577,57.916105];
              //     changecountry(lat,long,centerlat,centerlon,contentstring);
              //   }
  });
  function changecountry(locationdetails,country_name)
              {
                
                        var i;
                        var newzoom;
                        var clicked = false;
                        var newlat;
                        var newlng;
                        infoWindow =null;
                        console.log(country_name);
                        //var image = 'https://developers.google.com/maps/documentation/javascript/examples/full/images/beachflag.png';
                        if(country_name=="UAE"){
                                 map.setCenter(new google.maps.LatLng(25.324949,55.401567));
                                 newzoom = 1 * 10;
                        }
                        if(country_name=="Oman"){
                                 map.setCenter(new google.maps.LatLng(23.585376,58.545577));
                                 newzoom = 1 * 10;
                        }
                        if(country_name=="Uganda"){
                                 map.setCenter(new google.maps.LatLng(0.347596, 32.582520));
                                 newzoom = 1 * 13;
                        }
                        if(country_name=="Rwanda"){
                                 map.setCenter(new google.maps.LatLng(-1.927650,30.061037));
                                 newzoom = 1 * 13;
                        }
                        if(country_name=="Qatar"){
                                 map.setCenter(new google.maps.LatLng(25.286106, 51.534817));
                                 newzoom = 1 * 11;
                        }
                        if(country_name=="Tanzania"){
                                 map.setCenter(new google.maps.LatLng(-6.802353, 39.279556));
                                 newzoom = 1 *13;
                        }
                        if(country_name=="all"){
                                 map.setCenter(new google.maps.LatLng(25.508742,0.120850));
                                 newzoom = 1*3;
                        }

                        infoWindow = new google.maps.InfoWindow();
                        
                       
                        for(var info in locationdetails){
                        
                         var contentstring;  
                         var closeInfoWindowWithTimeout;
                          console.log(locationdetails[info].latitude);
                          console.log(locationdetails[info].longitude);
                          
                              newlat = 1 * locationdetails[info].latitude,
                              newlng = 1 * locationdetails[info].longitude;
                              map.setZoom(newzoom);

                              marker = new google.maps.Marker({
                              position: new google.maps.LatLng(locationdetails[info].latitude,locationdetails[info].longitude),
                                    icon:  "https://abccontentbucket.s3.me-south-1.amazonaws.com/images/locations.png",
                                    // tool tip data
                                    title:"ABC",
                                    //position: {lat: la[i], lng: lo[i]},
                                    //label: {text: "ABC Group", color: "white"},
                                    draggable: false,
                                    map: map
                          });
                          //contentstring="<div  style='img{max-width: none;}'><b>"+locationdetails[info].showroom+"</b><br>"+locationdetails[info].street+","+locationdetails[info].city+"<br>"+locationdetails[info].country+"<br><a href = 'mailto: abc@example.com'>"+locationdetails[info].email+"</a><br>"+locationdetails[info].phone_no+"</div>";
                          contentstring="<b>"+locationdetails[info].showroom+"</b><br>"+locationdetails[info].street+","+locationdetails[info].city+"<br>"+locationdetails[info].country+"<br><a href = 'mailto: abc@example.com'>"+locationdetails[info].email+"</a><br>"+locationdetails[info].phone_no;
                          //contentstring="<div style='max-height:400px;'><b>ABC Group UAE</b><br>Alif International<br>King Faisal Street Sharjah<br>abc@gmail.com<br>+97165434460</div>";
                      google.maps.event.addListener(marker, 'mouseover', (function(marker,infoWindow,contentstring) {
                                    return function() {
                                      infoWindow.setContent(contentstring);
                                      
                                      infoWindow.open(map, marker);
                                      
                                    }
                                  })(marker,infoWindow,contentstring));
                                  
                                                        
                                  // google.maps.event.addListener(marker, 'mouseout', function() {
                                  //   if (!clicked) {
                                  //       infoWindow.close();
                                  //   }
                                  //   });
                        } 
                      
                 
              }

    });







//   function changecountry(newlat, newlng,centerla,centerlo,contentstring)
//               {
                 
//                         var la=newlat;
//                         var lo=newlng;
//                         var newzoom;
//                         var infoWindow = new google.maps.InfoWindow();
                        
//                         //var image = 'https://developers.google.com/maps/documentation/javascript/examples/full/images/beachflag.png';
//                         map.setCenter(new google.maps.LatLng(centerla,centerlo));
//                         for(var i=0;i<2;i++){
//                           console.log(la[i]);
//                           console.log(lo[i]);
//                           newzoom = 1 * 18,
//                               newlat = 1 * la[i],
//                               newlng = 1 * lo[i];
//                               //Remove zoom to get corrrect map
//                       //map.setZoom(newzoom);

//                       // 
//                       // marker.setPosition(new google.maps.LatLng(la[i],lo[i]));
//                       marker = new google.maps.Marker({
//                             position: new google.maps.LatLng(la[i], lo[i]),
//                                     icon:  "https://abccontentbucket.s3.me-south-1.amazonaws.com/images/location.png",
//                                     // tool tip data
//                                     title:"ABC",
//                                     //position: {lat: la[i], lng: lo[i]},
//                                     //label: {text: "ABC Group", color: "white"},
//                                     draggable: false,
//                                     map: map
//                           });
//                       google.maps.event.addListener(marker, 'click', (function(marker, i) {
//                                     return function() {
//                                       infoWindow.setContent(contentstring);
                                      
//                                       infoWindow.open(map, marker);
//                                     }
//                                   })(marker, i));

//                         } 
                      
                 
//               }

//     });

    

  </script>
  <!-- [if lte IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/placeholders/3.0.2/placeholders.min.js"></script><![endif] -->

  <?php $__env->stopSection(); ?>




<?php echo $__env->make('Layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\Projects\ABC3\ABC_hosted\resources\views\pages\locations1.blade.php ENDPATH**/ ?>