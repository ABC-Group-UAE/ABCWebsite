
<?php $__env->startSection('content'); ?>
<div class="all-page-image-section"></div>
  <div class="all-page-red-section w-clearfix">
    <div class="redsectioncontentdiv">
      <p class="paragraph-2">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat. Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc ut sem vitae risus tristique posuere.</p>
      <a href="#" class="know-more-link-block combotypocolour w-inline-block">
        <div class="buttonclass-knowmore combotypographycolor">
          <h3 class="know-more-heading">Know More</h3>
        </div>
      </a>
    </div>
  </div>
  <div id="team-div" class="herosection">
    <div class="regularcontainer w-container">
      <h1 class="headinginnerpages">Management Team</h1>
      <div class="w-layout-grid team-member-list">
        <div class="team-member-div"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/oman-2.png" loading="lazy" alt="" class="member-img">
          <div class="reddividerdiv"></div>
          <div>
            <h3 class="name-heading">Heading</h3>
            <p class="team-content-paragraph">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat. Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc ut sem vitae risus tristique posuere.</p>
          </div>
        </div>
        <div class="team-member-div"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/oman-2.png" loading="lazy" alt="" class="member-img">
          <div class="reddividerdiv"></div>
          <div>
            <h3 class="name-heading">Heading</h3>
            <p class="team-content-paragraph">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat. Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc ut sem vitae risus tristique posuere.</p>
          </div>
        </div>
        <div class="team-member-div"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/oman-2.png" loading="lazy" alt="" class="member-img">
          <div class="reddividerdiv"></div>
          <div>
            <h3 class="name-heading">Heading</h3>
            <p class="team-content-paragraph">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat. Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc ut sem vitae risus tristique posuere.</p>
          </div>
        </div>
        <div class="team-member-div"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/oman-2.png" loading="lazy" alt="" class="member-img">
          <div class="reddividerdiv"></div>
          <div>
            <h3 class="name-heading">Heading</h3>
            <p class="team-content-paragraph">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat. Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc ut sem vitae risus tristique posuere.</p>
          </div>
        </div>
        <div class="team-member-div"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/oman-2.png" loading="lazy" alt="" class="member-img">
          <div class="reddividerdiv"></div>
          <div>
            <h3 class="name-heading">Heading</h3>
            <p class="team-content-paragraph">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat. Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc ut sem vitae risus tristique posuere.</p>
          </div>
        </div>
        <div class="team-member-div"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/oman-2.png" loading="lazy" alt="" class="member-img">
          <div class="reddividerdiv"></div>
          <div>
            <h3 class="name-heading">Heading</h3>
            <p class="team-content-paragraph">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat. Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc ut sem vitae risus tristique posuere.</p>
          </div>
        </div>
        <div class="team-member-div"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/oman-2.png" loading="lazy" alt="" class="member-img">
          <div class="reddividerdiv"></div>
          <div>
            <h3 class="name-heading">Heading</h3>
            <p class="team-content-paragraph">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat. Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc ut sem vitae risus tristique posuere.</p>
          </div>
        </div>
        <div class="team-member-div"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/oman-2.png" loading="lazy" alt="" class="member-img">
          <div class="reddividerdiv"></div>
          <div>
            <h3 class="name-heading">Heading</h3>
            <p class="team-content-paragraph">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat. Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc ut sem vitae risus tristique posuere.</p>
          </div>
        </div>
        <div class="team-member-div"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/oman-2.png" loading="lazy" alt="" class="member-img">
          <div class="reddividerdiv"></div>
          <div>
            <h3 class="name-heading">Heading</h3>
            <p class="team-content-paragraph">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat. Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc ut sem vitae risus tristique posuere.</p>
          </div>
        </div>
      </div>
    </div>
  </div>
  <?php $__env->stopSection(); ?>
  
<?php echo $__env->make('Layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\Projects\ABC3\ABC_hosted\resources\views\Team.blade.php ENDPATH**/ ?>