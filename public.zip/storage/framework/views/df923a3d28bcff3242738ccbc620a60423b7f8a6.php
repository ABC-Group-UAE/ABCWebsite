




 <?php $__env->startSection('content'); ?>
  <div class="modal-wrapper">
    <div class="form-wrapper w-clearfix"><a href="<?php echo e(route('home')); ?>" aria-current="page" class="close w--current">X </a>
      <h2 class="heading-4 headinginnerpages">Have a chat with us</h2>
      <div class="w-form">
        <form id="email-form-4" name="email-form-4" data-name="Email Form 4" method="post" id="ContactForm" action="<?php echo e(route('Dealers.contactus')); ?>">
        <?php echo e(csrf_field()); ?>

          <input type="text" class="text-field-5 w-input" autofocus="true" maxlength="256" name="name" data-name="Name" placeholder="Enter Your name" id="name">
          <input type="email" class="text-field-6 w-input" autofocus="true" maxlength="256" name="email" data-name="Email" placeholder="Enter your mail id" id="email" required="">
          <input type="tel" class="text-field-7 w-input" autofocus="true" maxlength="256" name="PhNo" data-name="PhNo" placeholder="Enter Your mobile number" id="PhNo" required="">
          <input type="text" class="text-field-8 w-input" autofocus="true" maxlength="256" name="TypeofEnquiry" data-name="TypeofEnquiry" placeholder="Enter type of enquiry here" id="TypeofEnquiry" required="">
          <textarea data-name="message" maxlength="5000" id="message" name="message" placeholder="type any message here" autofocus="true" class="textarea w-input"></textarea>
          <input type="submit" value="Submit" data-wait="Please wait..." class="btnclass borderclass w-button" onclick="contactus()">
        </form>
        <div class="w-form-done">
          <div>Thank you! Your submission has been received!</div>
        </div>
        <div class="w-form-fail">
          <div>Oops! Something went wrong while submitting the form.</div>
        </div>
      </div>
    </div>
  </div>
  <div data-poster-url="https://abccontentbucket.s3.me-south-1.amazonaws.com/videos/111.jpg" data-video-urls="https://abccontentbucket.s3.me-south-1.amazonaws.com/videos/111.mp4" data-autoplay="true" data-loop="true" data-wf-ignore="true" class="background-video w-background-video w-background-video-atom"><video autoplay="" loop="" style="background-image:url(&quot;https://abccontentbucket.s3.me-south-1.amazonaws.com/videos/111.jpg&quot;)" muted="" playsinline="" data-wf-ignore="true" data-object-fit="cover"><source src="https://abccontentbucket.s3.me-south-1.amazonaws.com/videos/111.mp4" data-wf-ignore="true"><source src="https://abccontentbucket.s3.me-south-1.amazonaws.com/videos/111.mp4" data-wf-ignore="true"></video></div>
  <div data-poster-url="https://abccontentbucket.s3.me-south-1.amazonaws.com/videos/111.jpg" data-video-urls="https://abccontentbucket.s3.me-south-1.amazonaws.com/videos/111.mp4" data-autoplay="true" data-loop="true" data-wf-ignore="true" class="background-vdo-mobile w-background-video w-background-video-atom"><video autoplay="" loop="" style="background-image:url(&quot;https://abccontentbucket.s3.me-south-1.amazonaws.com/videos/111.jpg&quot;)" muted="" playsinline="" data-wf-ignore="true" data-object-fit="cover"><source src="https://abccontentbucket.s3.me-south-1.amazonaws.com/videos/111.mp4" data-wf-ignore="true"><source src="https://abccontentbucket.s3.me-south-1.amazonaws.com/videos/111.mp4" data-wf-ignore="true"></video></div>
  <div class="whatsappbox"><a href="https://api.whatsapp.com/send?phone=971564130262&amp;abid=971564130262" class="link-block-category w-inline-block"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/001-whatsapp.svg" width="35" height="35" alt="" class="whatsapp-icon"><h5 class="chat-with-us">Chat<br></h5></a></div>
  <form id="msectionform" action= "<?php echo e(route('Search.Home.filter')); ?>" method = "get">
  <input type="hidden" name="filterCat" id="filterCat"><input type="hidden" name="filter-value" id="filter-value">
  
  <div class="middle-section">
    <div class="red-category-overlapping-container w-container">
      <div class="rotated-heading-div" style="display:none;">
        <h2 class="heading-11 categoryheading">Explore</h2>
      </div>
      <div class="w-layout-grid category-grid">
        <a id="w-node-08908e697a84-f1b162d0" data-w-id="e77d112a-3ecf-9ff9-7559-08908e697a84" href="javascript:submitmiddleForm('S')" class="link-block-category w-inline-block">
          <div class="category-div"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/FweAiP1.svg" height="170" width="170" alt="" class="category-img">
            <h5 class="category-heading home-page">Sanitarywares</h5>
          </div>
          <div class="whitecolourdiv"></div>
        </a>
        <a data-w-id="62e76ea9-7097-820f-26e9-21f5d5e35bee" href="javascript:submitmiddleForm('C')" class="link-block-category w-inline-block">
          <div class="div-block-47"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Asset-41.svg" width="170" height="170" alt="" class="image-28">
            <h5 class="category-heading home-page">Ceramics</h5>
          </div>
          <div class="whitecolourdiv"></div>
        </a>
        <a data-w-id="d6bb6a00-715f-f8fb-23fa-f9810fdaf8c4" href="javascript:submitmiddleForm('M')" class="link-block-category w-inline-block">
          <div class="div-block-45"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/9NaSBr1.svg" width="170" height="170" alt="" class="image-29">
            <h5 class="category-heading compensation">Mixers</h5>
          </div>
          <div class="whitecolourdiv"></div>
        </a>
        <a data-w-id="4f0c0e7d-f7d9-6ac3-80d2-8d66ee83bd1b" href="javascript:submitmiddleForm('K')" class="link-block-category w-inline-block">
          <div class="div-block-48"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Asset-21.svg" width="230" height="170" alt="" class="image-30">
            <h5 class="category-heading home-page">Kitchen</h5>
          </div>
          <div class="whitecolourdiv"></div>
        </a>
        <a id="w-node-bd0f28d15ece-f1b162d0" data-w-id="4a79929f-049f-6daf-8f39-bd0f28d15ece" href="javascript:submitmiddleForm('Z')" class="link-block-category w-inline-block">
          <div class="div-block-49"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Asset-11.svg" width="217" height="170" alt="" class="image-36">
            <h5 class="category-heading home-page">Accessories</h5>
          </div>
          <div class="whitecolourdiv"></div>
        </a>
      </div>
    </div>
  </div>
  <div class="middle-section-mobileview">
    <div class="red-category-overlapping-container all-page-red-section w-container">
      <div class="rotated-heading-div">
        <h2 class="heading-11">Explore</h2>
      </div>
      <div class="w-layout-grid category-grid">
        <div id="w-node-ba469db9f95e-f1b162d0" onClick="submitmiddleForm('S')">
          <h5 class="category-heading combocolour">Sanitarywares</h5>
          <div class="whitecolourdiv"></div>
        </div>
        <div id="w-node-ba469db9f962-f1b162d0" onClick="submitmiddleForm('C')">
          <h5 class="category-heading combocolour">Ceramics</h5>
          <div class="whitecolourdiv"></div>
        </div>
        <div id="w-node-ba469db9f966-f1b162d0" onClick="submitmiddleForm('M')">
          <h5 class="category-heading combocolour">Mixers</h5>
          <div class="whitecolourdiv"></div>
        </div>
        <div id="w-node-ba469db9f96a-f1b162d0" onClick="submitmiddleForm('K')">
          <h5 class="category-heading combocolour">Kitchen</h5>
          <div class="whitecolourdiv"></div>
        </div>
        <div id="w-node-ba469db9f96e-f1b162d0" onClick="submitmiddleForm('Z')">
          <h5 class="category-heading combocolour">Accessories</h5>
          <div class="whitecolourdiv"></div>
        </div>
        <a data-w-id="d84fc8bb-e5d8-a2ee-ea6f-d40e377a82cf" href="#" class="link-block-category w-inline-block">
          <div class="category-div"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/FweAiP.svg" height="170" width="170" alt="" class="category-img">
            <h5 class="category-heading home-page">Sanitarywares</h5>
          </div>
          <div class="whitecolourdiv"></div>
        </a>
        <a data-w-id="2bf7c77f-4c8f-dc68-25c7-d1ad53721298" href="#" class="link-block-category w-inline-block">
          <div class="div-block-47"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Asset-4.svg" width="170" height="170" alt="" class="image-28">
            <h5 class="category-heading home-page">Ceramics</h5>
          </div>
          <div class="whitecolourdiv"></div>
        </a>
      </div>
    </div>
  </div>
  </form>
  <div class="homepage-herosection w-clearfix">
    <div class="coloureddivisionmain"></div>
    <div class="hero-section-container w-container">
      <div class="w-layout-grid msg-grid">
        <h3 id="w-node-47c6bbd8af41-f1b162d0" class="rotated-heading w-clearfix"><span class="text-span">Message from the<br> founder and Md</span></h3><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/madanikka.jpg" width="259" height="259" id="w-node-983056b0843a-f1b162d0" alt="" class="md-img">
        <div id="w-node-63299fef606d-f1b162d0" class="message-div">
          <p class="paragraph-11">Can a business simply strive on ‘Win-Win’ principle ?  <br>
This is the thought I had years ago.<br><br>
ABC began operation during the year 1998. Our dedication and
commitment to serve our customers with nothing but the best, has
made ABC the global phenomenon it is today. We had our lows; but
had strived and innovated ourselves every time. Today, we serve our
customers with a wide range of international and in-house brands both
nationally and internationally. I can proudly state that we have touched
a million lives globally by serving them the best and YES; a business
can solely survive on ‘Win-Win’ principle and achieve greatness.</p>
          <h4 class="heading-10">Muhammed Madani</h4>
        </div>
      </div>
      <div class="div-block-29">
        <h2 class="redheadings">Our Core Purpose</h2>
        <div class="mainfullcaptext">To Help People<br>Transform their World</div>
        <h2 class="redheadings">Our Values</h2>
      </div>
      <div class="core-value-grid">
        <div id="w-node-da8042520882-f1b162d0" class="corevaluedivblock">
          <div class="valuesign-and-heading"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Asset-6.svg" width="54" height="60" data-w-id="3cc64650-ca1f-0692-2b8a-72b6041b13ec" alt="" class="image-22">
            <h3 class="heading-2">Relationship for life</h3>
          </div>
          <div class="core-value-content">
            <p class="paragraph-5">ABC has a lifelong commitment to its customers, employees,stakeholders, vendors and well-wishers. We are committed to help them to lead a happier, longer and fulfilling life.</p>
          </div>
        </div>
        <div class="corevaluedivblock">
          <div class="valuesign-and-heading"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Asset-4_1.svg" width="54" height="60" data-w-id="127e808e-6120-b4db-5a48-5029b3f6c89e" alt="" class="image-22">
            <h3 class="heading-2">Customer Service and Satisfaction</h3>
          </div>
          <div class="core-value-content">
            <p class="paragraph-5-copy">ABC provides customer experience that is not just the best, but exceptional. We
relentlessly deliver innovative and enduring products and services that are on
par, thus ensuring absolute customer satisfaction.</p>
          </div>
        </div>
        <div id="w-node-93a689d5e93a-f1b162d0" class="corevaluedivblock">
          <div class="valuesign-and-heading"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Asset-3.svg" width="54" height="60" data-w-id="21b82785-e694-85d8-4ba8-0eef700ce7da" alt="" class="image-22">
            <h3 class="heading-2">Teamwork for Excellence</h3>
          </div>
          <div class="core-value-content">
            <p class="paragraph-5-copy">For us maintaining excellence is the norm. We are powered by a team that has
outgrown individual performance and has made achieving excellence a part
of their everyday activity.</p>
          </div>
        </div>
        <div class="corevaluedivblock">
          <div class="valuesign-and-heading"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Asset-5.svg" width="54" height="60" data-w-id="c8b4c608-aec3-9ccb-d0b2-3fd799d6311d" alt="" class="image-22">
            <h3 class="heading-2">Futuristic and Innovative</h3>
          </div>
          <div class="core-value-content">
            <p class="paragraph-5">ABC rises up to a fresh world of ideas and a new way of life. It proudly brings state-of-the-art designs &amp; products from expertise across the world and spread innovative ideas.</p>
          </div>
        </div>
        <div id="w-node-61bac19866d0-f1b162d0" class="corevaluedivblock">
          <div class="valuesign-and-heading"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Asset-2_1.svg" width="54" height="60" data-w-id="7703ca24-38e4-9d18-38bc-61bac19866d2" alt="" class="image-22">
            <h3 class="heading-2">Responsible &amp; Result Oriented</h3>
          </div>
          <div class="core-value-content">
            <p class="paragraph-5">We are committed to deliver result oriented products & services - we believe that, our
success is depended upon responsibility to the society</p>
          </div>
        </div>
        <div class="corevaluedivblock">
          <div class="valuesign-and-heading"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Asset-1_1.svg" width="54" height="60" data-w-id="e9b8b81a-dba1-e380-ec63-b1a26c4b7dd2" alt="" class="image-22">
            <h3 class="heading-2">Win-win Cooperation</h3>
          </div>
          <div class="core-value-content">
            <p class="paragraph-5">We always achieved success through its unique ‘Win - Win’ strategy. Our customers, employees, stakeholders and
vendors will reap the benefits of happiness and good life. ABC strives to provide its customers with exceptional service.</p>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="home-page-red-section w-container">
    <h1 class="red-section-main-heading fontfamily">Become a Trade Partner</h1>
    <p class="paragraph-10">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat. Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc ut sem vitae risus tristique posuere.</p>
    <div data-w-id="2e2e4fa3-211c-c57b-6c2d-8d76bc6c62da" class="buttonclass">
      <h3 class="know-more-heading">Contact us for Dealership</h3><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/arrow.png" loading="lazy" width="19" height="19" alt="" class="image-40"></div>
  </div>
  


<script>
   function contactus(){
       // ContactForm
       var name="";
       var mailid ="";
       var mobile = "";
       var TypeofEnquiry="";
       var message = "";
      if($("#name").val()==""){
        
      }else{
          name = $("#name").val();
      }
      if($("#email").val()==""){
        
      }else{
          mailid = $("#email").val();
      }
      if($("#PhNo").val()==""){
        
      }else{
          mobile = $("#PhNo").val();
      }
      if($("#TypeofEnquiry").val()==""){
        
      }else{
          TypeofEnquiry = $("#TypeofEnquiry").val();
      }
      if($("#message").val()==""){
        
      }else{
          message = $("#message").val();
      }
      $("#ContactForm").submit();


   }

   function submitmiddleForm(catValue){
    $("#filterCat").val("Category");
    $("#filter-value").val(catValue);
     $("#msectionform").submit();
   }

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\Projects\ABC3\ABC_hosted\resources\views/home.blade.php ENDPATH**/ ?>