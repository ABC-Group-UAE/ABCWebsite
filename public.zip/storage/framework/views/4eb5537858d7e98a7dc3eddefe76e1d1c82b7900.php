
<?php $__env->startSection('content'); ?>
<div class="modal-wrapper"  id="popup">
    <div class="form-wrapper w-clearfix"><a href="<?php echo e(route('Cart.View')); ?>" aria-current="page" class="close w--current">x </a>
      <h2 class="heading-4 headinginnerpages">Contact Details</h2>
      <div class="w-form">
        <form id="email-form-4" name="email-form-4" data-name="Email Form 4" method="post" id="ContactForm" action="<?php echo e(route('shoplist.enquire')); ?>">
          <?php echo e(csrf_field()); ?>

          <input type="text" class="w-input" autofocus="true" maxlength="256" name="name" data-name="Name" placeholder="Enter Your name" id="name">
          <input type="email" class="w-input" autofocus="true" maxlength="256" name="email" data-name="Email" placeholder="Enter your mail id" id="email" required="">
          <input type="tel" class="w-input" autofocus="true" maxlength="256" name="PhNo" data-name="PhNo" placeholder="Enter Your mobile number" id="PhNo" required="">
          <input type="submit" value="Submit" data-wait="Please wait..." class="btnclass borderclass w-button" onclick="contactus()">
        </form>
        <div class="w-form-done">
          <div>Thank you! Your submission has been received!</div>
        </div>
        <div class="w-form-fail">
          <div>Oops! Something went wrong while submitting the form.</div>
        </div>
      </div>
    </div>
  </div>

  <div class="main-container w-container" id ="ShopList">
  <div id ="CartContent">
  <?php     
    use App\Product;
    $SId = Session::get('id');
    if(\Cart::session($SId)->isEmpty()) {

        $message ="Cart is Empty... Please Continue shopping";
  ?>
      <h1 id = "message"> <?php echo e($message); ?></h1>

   <?php  }  else{    ?>
    <div class="heading-div" id ="CARTLIST">
      <div>
        <h1 class="heading-29">Shoplist</h1>
      </div>
      <div class="div-block-78">
        <div class="div-block-96">
          <h4 class="heading-27">Product Image</h4>
        </div>
        <div class="div-block-96">
          <h4 class="heading-27">Product Description</h4>
        </div>
        <h4 id="w-node-772a9433cff5-fa8c5f7d" class="heading-28">Quantity</h4>
        <div id="w-node-772a9433cff7-fa8c5f7d" class="div-block-98">
          <h4 class="heading-4"></h4>
        </div>
        <div>
          <h4 class="heading-4-copy"></h4>
        </div>
      </div>
    </div>
    <form id="cartUpdate" name="email-form" data-name="Email Form" class="form-4">
      <?php echo csrf_field(); ?>
    <div class="w-layout-grid cart-list-1">
          <?php 
                      if( !($cartContent->isEmpty())){
                          $row = 0;
                          $rowcount = $cartContent->count();
                          $subTotal = \Cart::session($SId)->getSubTotal();
                          $vat = 0.05* $subTotal;
                          $Total = $vat+$subTotal;

                  ?>
                          <input type="hidden" name="rowcount" id="rowcount" value=<?php echo e($rowcount); ?>>
                  <?php
                          foreach($cartContent as $item){
                            $row++;
                            $product = Product::find($item->id);
                            $summedPrice = \Cart::session($SId)->get($item->id)->getPriceSum();


                          
                  ?>
      <div class="rowid" id="<?php echo e('row'.$row); ?>">
        <div class="cartrow-grid-without-price">
          <div id="w-node-772a9433cfff-fa8c5f7d" class="procontentdiv">
            <div class="div-block-90">
              <a href="<?php echo e(route('Product.description',$product->Product_id)); ?>" class="link-block-2 w-inline-block">
                <div class="div-block-75"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/<?php echo e($product->MainImage)); ?>" loading="lazy" alt="" class="image-51" id = "<?php echo e('Productpic_'.$row); ?>"></div>
              </a>
            </div>
          </div>
          <a href="<?php echo e(route('Product.description',$product->Product_id)); ?>" class="link-block-2 w-inline-block">
            <div class="productname-2">
              <h5 class="heading-26"><?php echo e($product->product_name); ?></h5>
              <div class="text-block-35"><?php echo e($product->product_name); ?></div>
            </div>
          </a>
          <div id="w-node-772a9433d00a-fa8c5f7d" class="div-block-89">
            <div class="form-block-5 w-form">
                <input type="hidden" name="<?php echo e('productId_'.$row); ?>" id="<?php echo e('productId_'.$row); ?>" value="<?php echo e($product->Product_id); ?>">
                <input type="text" class="text-field-3 w-input" maxlength="256" name="<?php echo e('qtyText'.$row); ?>" id="<?php echo e('qtyText'.$row); ?>" data-name="Name" 
                  value= "<?php echo e($item->quantity); ?>"  onChange="UpdateCartQuantity(<?php echo e($row); ?>,event) ">
              
            </div>
          </div>
          <div id="w-node-772a9433d017-fa8c5f7d" class="deletebuttondiv">
            <div class="div-block-95" ><a id="<?php echo e('delete_'.$row); ?>" href="#" class="link-3" onClick="RemoveFromCart(<?php echo e($row); ?>,event)">Remove</a></div>
          </div>
        </div>
        <div>
          <div class="grey-divider-div"></div>
        </div>
      </div>
      <?php

              }
              ?>
    </div>
    <div class="button-div" id="purchaseButton" onclick="SendMail()"><a data-w-id="058c16d4-5fe2-d8eb-62df-fa46370ee06d" href="#" class="buttonclass-copy combostyle w-button">Proceed To Purchase</a></div>
    </form>
    <?php 
    }
   }

?>
  </div>  
    <div class="heading-div">
      <div>
        <h1 class="heading-29">Favourites</h1>
        <div class="div-block-78">
          <div class="div-block-96">
            <h4 class="heading-27">Product Image</h4>
          </div>
          <div class="div-block-96">
            <h4 class="heading-27">Product Description</h4>
          </div>
          <h4 id="w-node-e347bbebc6ac-fa8c5f7d" class="heading-28">Quantity</h4>
          <div id="w-node-e347bbebc6ae-fa8c5f7d" class="div-block-98">
            <h4 class="heading-4"></h4>
          </div>
          <div>
            <h4 class="heading-4-copy"></h4>
          </div>
        </div>
      </div>
    </div>
    <div class="w-layout-grid whishlist-1">
      <div class="rowid">
        <div class="wishlitrow-grid-without-price">
          <div class="procontentdiv">
            <div class="div-block-90">
              <a href="productdescription.html" class="link-block-2 w-inline-block">
                <div class="div-block-75 combo"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/0.jp" loading="lazy" alt="" class="image-52"></div>
              </a>
            </div>
          </div>
          <a href="productdescription.html" class="link-block-2 w-inline-block">
            <div class="productname-2">
              <h5 class="heading-26">Wooden Garden Light Garden CF19212</h5>
              <div class="text-block-35">This is some text inside of a div block.</div>
            </div>
          </a>
          <div id="w-node-772a9433d096-fa8c5f7d" class="div-block-89">
            <div class="form-block-5 w-form">
              <form id="email-form" name="email-form" data-name="Email Form" class="form-4"><input type="text" class="text-field-3 w-input" maxlength="256" name="name-7" data-name="Name 7" placeholder="3" id="name-7"></form>
              <div class="w-form-done">
                <div>Thank you! Your submission has been received!</div>
              </div>
              <div class="w-form-fail">
                <div>Oops! Something went wrong while submitting the form.</div>
              </div>
            </div>
          </div>
          <div id="w-node-772a9433d0a3-fa8c5f7d" class="div-block-106">
            <div class="shoplistcartaddingbutton"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Shoplist-Ikea-rzk-version_1.svg" width="19" height="19" alt="" class="cart-img">
              <div class="addtocarttext">Add To Cart</div>
            </div>
            <div class="div-block-95"><a href="#" class="link-3">Remove</a></div>
          </div>
        </div>
        <div>
          <div class="grey-divider-div"></div>
        </div>
      </div>
      
    </div>
  </div>
  
  
  <div class="whatsappbox"><a href="https://api.whatsapp.com/send?phone=971564130262&amp;abid=971564130262" class="link-block-category w-inline-block"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/001-whatsapp.svg" width="35" height="35" alt="" class="whatsapp-icon"><h5 class="chat-with-us">Chat<br>with Us</h5></a></div>
<?php $__env->stopSection(); ?> 

<?php echo $__env->make('Layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\Projects\ABC3\ABC_hosted\resources\views\cart\copy_cartpage.blade.php ENDPATH**/ ?>