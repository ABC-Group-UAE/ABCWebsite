<?php 
                                   $SId = Session::get('id');
?>
<div id="header" class="headersection">
    <div class="myheadercontainer w-container">
      <div class="mygreyheaderdiv">
        <div class="mailandsocialmedia-div">
          <div class="mail-div"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/001-email.svg" width="20" height="17" alt="" class="mail-img"><a href="mailto:info@abcgroupuae.com?subject=Enquiry" class="maillink">info@abcmercantile.ae</a></div>
          <div class="w-layout-grid socialmediagrid"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/002-facebook.svg" height="17" id="w-node-79be17756dd1-17756dc8" alt=""><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/004-linkedin.svg" height="17" id="w-node-79be17756dd2-17756dc8" alt=""><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/004-twitter.svg" height="17" id="w-node-79be17756dd3-17756dc8" alt=""><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/005-instagram.svg" width="20" height="17" id="w-node-79be17756dd4-17756dc8" alt=""></div>
          <div class="w-layout-grid mobileview-media-link-grid"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/002-facebook.svg" height="13" id="w-node-79be17756dd6-17756dc8" alt=""><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/004-linkedin.svg" height="13" id="w-node-79be17756dd7-17756dc8" alt=""><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/004-twitter.svg" height="13" id="w-node-79be17756dd8-17756dc8" alt=""><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/005-instagram.svg" width="20" height="13" id="w-node-79be17756dd9-17756dc8" alt=""></div>
        </div>
        <div class="greyheaderrightsection">
          <div class="tollfreeandlanguage">
            <a href="#" class="tollfreenumber w-inline-block">
              <div class="w-layout-grid grid-4 grid-5"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/001-phone-call.svg" width="19" height="19" id="w-node-79be17756dde-17756dc8" alt="" class="call-button-image">
                <div id="w-node-79be17756ddf-17756dc8" class="tollfree-text">800 ABCGROUP</div>
              </div>
            </a>
            <div class="language-div"><a href="mailto:info@abcgroupuae.com?subject=Enquiry" class="englanglink">Ar</a>
              <div class="text-block-6">I</div><a href="mailto:info@abcgroupuae.com?subject=Enquiry" class="englanglink">En</a></div>
          </div>
        </div>
      </div>
      <div data-collapse="medium" data-animation="over-right" data-duration="400" role="banner" class="navbar-5 w-nav">
        <div class="navbar-container w-container"><a href="<?php echo e(route('home')); ?>" aria-current="page" class="brand w-nav-brand w--current"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/ABC-logo.svg" height="50" width="48" alt="" class="abclogo"></a>
          <nav role="navigation" class="nav-menu-4 w-nav-menu">
            <div data-hover="" data-delay="0" id="OurStoryMenu" class="ourstorydropmenu w-dropdown">
              <div class="w-dropdown-toggle">
                <div class="w-icon-dropdown-toggle"></div>
                <div>Our Story</div>
              </div>
              <nav class="w-dropdown-list"><a href="#" class="w-dropdown-link">Company Profile</a><a href="#" class="w-dropdown-link">History</a><a href="<?php echo e(route('Team')); ?>" class="w-dropdown-link">Team</a><a href="<?php echo e(route('OurPresence')); ?>" class="w-dropdown-link">Global Presence</a><a href="<?php echo e(route('Dealers')); ?>" class="w-dropdown-link">Dealers</a></nav>
            </div><a href="#" data-w-id="2b43a45b-7bbc-395b-fb89-79be17756dfd" class="our-story w-nav-link">Our Story</a><a href="<?php echo e(route('Explore')); ?>" class="product w-nav-link">Product</a>
            <div data-hover="1" data-delay="0" id="OurStoryMenu" class="exploredropmenu w-dropdown">
              <div class="w-dropdown-toggle">
                <div class="w-icon-dropdown-toggle"></div>
                <div>Explore</div>
              </div>
              <nav class="w-dropdown-list"><a href="<?php echo e(route('Brands')); ?>" class="w-dropdown-link">Brands</a><a href="<?php echo e(route('Exhibits')); ?>" class="w-dropdown-link">Exhibits</a><a href="#" class="w-dropdown-link">Projects</a></nav>
            </div><a href="#" data-w-id="2b43a45b-7bbc-395b-fb89-79be17756e0d" class="explore w-nav-link">Explore</a><a href="<?php echo e(route('catalogue')); ?>" class="downloads w-nav-link">Downloads</a><a href="<?php echo e(route('location')); ?>" class="store-locator w-nav-link">Store Locator</a><a href="<?php echo e(route('careers')); ?>" class="career w-nav-link">Career</a>
            <div class="searchboxdiv">
              <div class="form-block w-form">
                <form id="wf-form-searchBlock" name="wf-form-searchBlock" data-name="searchBlock" class="searchform" action="<?php echo e(route('Search.filter')); ?>" method="get">
                  <?php echo e(csrf_field()); ?><input type="text" class="search-textbox w-input" maxlength="256" name="SearchProduct" data-name="Search Prosucts 2" placeholder="search products here" id="SearchProduct"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/002-loupe.svg" width="19" id="searchicon" alt="" class="searchicon" onClick="submitForm('wf-form-searchBlock')" ><input type="hidden" name="filtertype" id="filter-info"><input type="hidden" name="filter-values" id="filter-values"></form>
                <div class="w-form-done"></div>
                <div class="w-form-fail"></div>
              </div>
              <div class="autocompletediv" id="product-list" Style="display:none;">
                <ul role="list" class="w-list-unstyled" id="data" Style="display:none;">
                  
                </ul>
              </div>
            </div>
            <div class="favandshoplisticondiv">
              <div class="w-layout-grid grid-6"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/002-love.svg" width="29" height="23" id="w-node-79be17756e1e-17756dc8" alt="" class="image-12">
                <div class="cart-div"><a href="<?php echo e(route('Cart.View')); ?>" class="w-inline-block"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Shoplist-Ikea-rzk-version.svg" width="23" height="23" alt="" class="shoplist-icon"></a>
                  
                  <div class="colour-block notification" id = "cartCount" <?php if(\Cart::session($SId)->isEmpty()) { ?> style=" display:none; "<?php } ?> >
                    <div class="text-block-29" id="cartCountText">
                           <?php if(\Cart::session($SId)->isEmpty()): ?>
                              
                               0
                            <?php else: ?>
                                <?php 
                                   $SId = Session::get('id');
                                echo \Cart::session($SId)->getContent()->count() ;

                                ?>
                            <?php endif; ?>
                   </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="whatsappdiv">
              <div class="w-layout-grid whatsapp-grid"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/003-whatsapp.svg" width="19" height="19" alt="">
                <div id="w-node-79be17756e23-17756dc8">+971553322119</div>
                <div id="w-node-79be17756e25-17756dc8" class="text-block-34">ENGLISH</div><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/003-whatsapp.svg" width="19" height="19" alt="">
                <div id="w-node-79be17756e28-17756dc8">+971553322119</div>
                <div id="w-node-79be17756e2a-17756dc8">ARABIC</div>
              </div>
            </div>
          </nav>
          <div class="div-block-20">
            <div class="favandshoplisticondiv-hidden">
              <div class="w-layout-grid grid-6"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/002-love.svg" width="29" height="23" id="w-node-79be17756e1e-17756dc8" alt="" class="image-12">
                <div class="cart-div"><a href="<?php echo e(route('Cart.View')); ?>" class="w-inline-block"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/Shoplist-Ikea-rzk-version.svg" width="23" height="23" alt="" class="shoplist-icon"></a>
                  
                  <div class="colour-block notification" id = "cartCount1" <?php if(\Cart::session($SId)->isEmpty()) { ?> style=" display:none; "<?php } ?> >
                    <div class="text-block-29" id="cartCountText1">
                           <?php if(\Cart::session($SId)->isEmpty()): ?>
                              
                               0
                            <?php else: ?>
                                <?php 
                                   $SId = Session::get('id');
                                echo \Cart::session($SId)->getContent()->count() ;

                                ?>
                            <?php endif; ?>
                   </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="whatsappdiv-hidden">
              <div class="w-layout-grid whatsapp-grid"><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/003-whatsapp.svg" width="19" height="19" alt="">
                <div id="w-node-79be17756e34-17756dc8">+971553322119</div>
                <div id="w-node-79be17756e36-17756dc8">ENGLISH</div><img src="https://abccontentbucket.s3.me-south-1.amazonaws.com/images/003-whatsapp.svg" width="19" height="19" alt="">
                <div id="w-node-79be17756e39-17756dc8">+971553322119</div>
                <div id="w-node-79be17756e3b-17756dc8">ARABIC</div>
              </div>
            </div>
          </div>
          <div class="menu-button w-nav-button">
            <div class="icon w-icon-nav-menu"></div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="reddish-menu">
    <div class="red-menu-contaiiner w-container"><a href="#" class="red-section-nav-link">Company Profile</a><a href="#" class="red-section-nav-link">History</a><a href="<?php echo e(route('Team')); ?>" class="red-section-nav-link">Team</a><a href="<?php echo e(route('OurPresence')); ?>" class="red-section-nav-link">Global Presence</a><a href="<?php echo e(route('Dealers')); ?>" class="red-section-nav-link">Our Dealers<br>‍</a></div>
  </div>
  <div class="explore-reddish-menu">
    <div class="exploresubmenucontainer w-container"><a href="<?php echo e(route('Brands')); ?>" class="red-section-nav-link">Brands</a><a href="<?php echo e(route('Exhibits')); ?>" class="red-section-nav-link">Exhibits</a><a href="#" class="red-section-nav-link">Projects</a></div>
  </div>








  <script>
    $(function() {
            var count=0;
            var addProduct="";
            var code="";
            var categoryset=new Set();
            var subcategoryset=new Set();
            var subsubcategoryset=new Set();
            var productset=new Set();
            var brandset=new Set();
              $("#SearchProduct").keyup(function(){
                $("#product-list").empty();
                
                code=$(this).val();
                count = code.length;
                console.log(count);
                if(count==0){
                  $("#product-list").empty();
                }
               
                if(count>0){
                  url="<?php echo e(route('autocomplete')); ?>";
                  console.log(url);
                  console.log(code);
                  $.ajax({
                    url: url,
                    type:"GET",
                    
                    data:{
                      search:code,
                      
                    },
                    success:function(response){
                      $("#product-list").show();
                      $("#data").show();
                      //console.log("Success");
                      //console.log(response);
                      categoryset.clear();
                      subcategoryset.clear();
                      subsubcategoryset.clear();
                      productset.clear();
                      brandset.clear();
                     // $("#product-list").empty();
                      // $("#data").empty();
                      addProduct="";
                      list=response;
                      //console.log(typeof(code));  
                      var listcount=list.length;
                      for(var i=0;i<listcount;i++){
                        console.log(list[i]);
                        var newcode=code.toLowerCase();
                        var category=(list[i].Category_Name).toLowerCase()+"-"+(list[i].Category_ID);
                        var subcategory=(list[i].Sub_Category_Name).toLowerCase()+"-"+(list[i].Category_ID)+"-"+(list[i].Sub_Category_ID);
                        var subsubcategory=(list[i].Sub_Sub_Category_Name).toLowerCase()+"-"+(list[i].Category_ID)+"-"+(list[i].Sub_Category_ID)+"-"+(list[i].Sub_Sub_Category_ID);
                        var product=(list[i].product_name).toLowerCase();
                        var brand=(list[i].Brand).toLowerCase();
                        categoryset.add(category);
                        subcategoryset.add(subcategory);
                        subsubcategoryset.add(subsubcategory);
                        productset.add(product);
                        brandset.add(brand);
                        var catsearch=category.search(newcode);
                        var subcatsearch=subcategory.search(newcode);
                        var subsubcatsearch=subsubcategory.search(newcode);
                        var productsearch=product.search(newcode);
                        var brandsearch=brand.search(newcode);
                        console.log(catsearch);
                        console.log(subcatsearch);
                        console.log(subsubcatsearch);
                        console.log(productsearch);
                        console.log(brandsearch);
                        if(productsearch>=0){
                          addProduct+="<li   id='"+list[i].product_name+"' class='suggestionli' onClick=selectItem('"+list[i].product_name+"','description','"+list[i].Product_id+"')>"+list[i].product_name+"</li>"; 
                        }else if(catsearch>=0){
                          addProduct="";
                          for (let item of categoryset) {
                                var type="Category";
                                var catarray = item.split("-");
                              
                                addProduct+='<li class="suggestionli" id="'+catarray[0]+'" onClick="selectItem(\''+catarray[0]+'\',\''+type+'\',\''+item+'\');">'+catarray[0]+'</li>'; 
                              }
                        }
                        if(subcatsearch>=0){
                          addProduct="";
                          for (let item of subcategoryset) {
                                var type="Sub_Category";
                                var subcatarray = item.split("-");
                              
                                  addProduct+='<li class="suggestionli" id="'+subcatarray[0]+'" onClick="selectItem(\''+subcatarray[0]+'\',\''+type+'\',\''+item+'\');">'+subcatarray[0]+'</li>';
                              
                                
                              }
                         }
                        if(subsubcatsearch>=0){
                          addProduct="";
                          for (let item of subsubcategoryset) {
                                var type="Sub_Sub_Category";
                                var subsubcatarray = item.split("-");
                              
                                  addProduct+='<li class="suggestionli" id="'+subsubcatarray[0]+'" onClick="selectItem(\''+subsubcatarray[0]+'\',\''+type+'\',\''+item+'\');">'+subsubcatarray[0]+'</li>';
                              
                                
                              }
                        }
                        if(brandsearch>=0){
                          addProduct="";
                         
                            for (let item of brandset) {
                                var type="Brand";
                              
                                addProduct+='<li class="suggestionli" id="'+item+'" onClick="selectItem(\''+item+'\',\''+type+'\',\''+item+'\');">'+item+'</li>'; 
                              }
                          
                        }
                        
                        
                        //addProduct="<li id='"+list[i]+"' onClick=selectItem('"+list[i]+"')>"+list[i]+"</li>";
                        $('#product-list').html(addProduct);
                        //$('#data').html(addProduct);

                      }    
                    }
                  });
                 }
              });
              
             

        });
        function selectItem(listitem,description,redirectid){
                console.log("Clicked auto");
                console.log(description);
                $("#filter-info").val(description);
                $("#filter-values").val(redirectid);
                console.log(listitem);
                console.log(redirectid);
                $("#product-list").hide();

                $("#SearchProduct").val(listitem);
              }

      function submitForm(formid){
          console.log("inside form submit function");
          $("#wf-form-searchBlock").submit();
      }
  </script><?php /**PATH C:\wamp\www\Projects\ABC3\ABC_hosted\resources\views\Common\Header.blade.php ENDPATH**/ ?>